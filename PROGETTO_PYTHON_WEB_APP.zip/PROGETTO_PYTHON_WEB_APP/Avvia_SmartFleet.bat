@echo off
title Smart Fleet IoT - Avvio
cd /d "%~dp0"
echo ========================================
echo   Smart Fleet IoT - Gestione Flotta
echo   ITS Academy ICT Piemonte
echo   Product by Samuel Rivoiro
echo ========================================
echo.

REM 1. Attivazione virtual environment
if not exist ".venv\Scripts\activate.bat" (
    echo [1/3] Virtual environment non trovato. Creazione...
    python -m venv .venv
    call .venv\Scripts\activate.bat
    python -m pip install customtkinter pillow reportlab
) else (
    call .venv\Scripts\activate.bat
)
echo [1/3] Venv attivato.

REM 2. Setup del database
echo [2/3] Setup database...
python database\Setup_db.py

REM 3. Avvio interfaccia UI
echo [3/3] Avvio interfaccia...
python UI\Start_main_app.py

if errorlevel 1 (
    echo.
    echo [ERRORE] L'applicazione si e' chiusa con errori.
    pause
)