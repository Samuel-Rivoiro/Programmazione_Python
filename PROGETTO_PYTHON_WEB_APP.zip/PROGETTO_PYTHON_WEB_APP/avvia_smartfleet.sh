#!/usr/bin/env bash
# ==============================================================
#  Smart Fleet IoT - Avvio (GNU/Linux)
#  ITS Academy ICT Piemonte
# ==============================================================
# Script equivalente a Avvia_SmartFleet.bat, per l'esecuzione nativa sull'ambiente richiesto dalla consegna (GNU/Linux).
set -e
cd "$(dirname "$0")"

# Tkinter e' un pacchetto di sistema, non installabile via pip:
# su Debian/Ubuntu va installato a parte se manca.
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "[ERRORE] Modulo 'tkinter' non trovato."
    echo "Installalo con: sudo apt install python3-tk"
    exit 1
fi

echo "========================================"
echo "  Smart Fleet IoT - Gestione Flotta"
echo "  ITS Academy ICT Piemonte"
echo "========================================"
echo

# 1. Creazione/attivazione virtual environment
if [ ! -f ".venv_linux/bin/activate" ]; then
    echo "[1/3] Virtual environment non trovato. Creazione..."
    python3 -m venv .venv_linux
    source .venv_linux/bin/activate
    pip install --upgrade pip >/dev/null
    pip install customtkinter pillow reportlab
else
    source .venv_linux/bin/activate
fi
echo "[1/3] Venv attivato."

# 2. Setup del database
echo "[2/3] Setup database..."
python database/Setup_db.py

# 3. Avvio interfaccia UI
echo "[3/3] Avvio interfaccia..."
python UI/Start_main_app.py