"""
Modulo: db_manager.py
=====================
Accesso al database per l'applicazione Smart Fleet IoT.

Contiene la classe DatabaseManager, che incapsula tutte le query SQLite
usate dalle pagine dell'interfaccia (pattern Repository), separando la
logica di accesso ai dati dalla GUI.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import sqlite3
from datetime import datetime
from typing import Any, Optional


class DatabaseManager:
    """
    Gestore centralizzato per tutte le operazioni di database.

    Incapsula la logica di accesso ai dati, separandola dalla GUI.
    Utilizza il pattern Repository per fornire un'interfaccia pulita
    verso il database SQLite sottostante.

    Attributes:
        db_path (str): Percorso assoluto del file database.
    """

    def __init__(self, db_path: str) -> None:
        """
        Inizializza il gestore del database.

        Args:
            db_path: Percorso assoluto del file database SQLite.
        """
        self.db_path = db_path

    def _connetti(self) -> sqlite3.Connection:
        """
        Crea una nuova connessione al database.

        Returns:
            sqlite3.Connection: Connessione attiva al database.
        """
        return sqlite3.connect(self.db_path)

    # ── Autenticazione ───────────────────────────────────────────────────

    def accedi(self, username: str, password: str) -> Optional[tuple[int, str, str]]:
        """
        Verifica le credenziali di un utente.

        Args:
            username: Nome utente.
            password: Password in chiaro.

        Returns:
            Optional[tuple]: (id, role, username) se valido, None altrimenti.
        """
        conn = self._connetti()
        row = conn.execute(
            "SELECT id, role, username FROM utenti WHERE username=? AND password=?",
            (username, password),
        ).fetchone()
        conn.close()
        return row

    def registra(self, username: str, password: str) -> None:
        """
        Registra un nuovo utente con ruolo 'standard'.

        Args:
            username: Nome utente desiderato.
            password: Password in chiaro.

        Raises:
            sqlite3.IntegrityError: Se lo username è già in uso.
        """
        conn = self._connetti()
        conn.execute(
            "INSERT INTO utenti(username, password, role) VALUES(?, ?, 'standard')",
            (username, password),
        )
        conn.commit()
        conn.close()

    # ── Dashboard / KPI ──────────────────────────────────────────────────

    def ottieni_dati_kpi(self) -> dict[str, int]:
        """
        Recupera i dati KPI per la dashboard amministratore.

        Returns:
            dict: Dizionario con chiavi:
                - total_vehicles: int
                - available_vehicles: int
                - active_reservations: int
                - total_reviews: int
                - total_users: int
        """
        conn = self._connetti()
        data = {
            "total_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli"
            ).fetchone()[0],
            "available_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli WHERE status='disponibile'"
            ).fetchone()[0],
            "active_reservations": conn.execute(
                "SELECT COUNT(*) FROM prenotazioni WHERE status='attiva'"
            ).fetchone()[0],
            "total_reviews": conn.execute(
                "SELECT COUNT(*) FROM recensioni"
            ).fetchone()[0],
            "total_users": conn.execute(
                "SELECT COUNT(*) FROM utenti"
            ).fetchone()[0],
        }
        conn.close()
        return data

    def ottieni_dati_telemetria(self, limit: int = 6) -> list[tuple]:
        """
        Recupera i dati di telemetria dei veicoli.

        Args:
            limit: Numero massimo di veicoli da restituire.

        Returns:
            list[tuple]: Lista di tuple (model, plate, fuel_level, brake_wear, status).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, fuel_level, brake_wear, status "
            "FROM veicoli LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_avvisi_carburante(self, threshold: float = 30.0) -> list[tuple]:
        """
        Recupera i veicoli con carburante sotto soglia.

        Args:
            threshold: Soglia percentuale carburante.

        Returns:
            list[tuple]: Lista di (model, plate, fuel_level).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, fuel_level FROM veicoli WHERE fuel_level < ?",
            (threshold,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_avvisi_freni(self, threshold: float = 30.0) -> list[tuple]:
        """
        Recupera i veicoli con freni sotto soglia.

        Args:
            threshold: Soglia percentuale usura freni.

        Returns:
            list[tuple]: Lista di (model, plate, brake_wear).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, brake_wear FROM veicoli WHERE brake_wear < ?",
            (threshold,),
        ).fetchall()
        conn.close()
        return data

    # ── Prenotazioni ─────────────────────────────────────────────────────

    def ottieni_veicoli_disponibili(self) -> list[tuple]:
        """
        Recupera tutti i veicoli disponibili per la prenotazione.

        Returns:
            list[tuple]: Lista di (id, model, plate, fuel_level, brake_wear, photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT id, model, plate, fuel_level, brake_wear, photo_path "
            "FROM veicoli WHERE status='disponibile'"
        ).fetchall()
        conn.close()
        return data

    def prenota_veicolo(
        self, user_id: int, vehicle_id: int, start_date: str, end_date: str
    ) -> None:
        """
        Prenota un veicolo per un utente.

        Args:
            user_id: ID dell'utente che prenota.
            vehicle_id: ID del veicolo da prenotare.
            start_date: Data inizio prenotazione (formato GG-MM-AAAA).
            end_date: Data fine prenotazione (formato GG-MM-AAAA).
        """
        conn = self._connetti()
        conn.execute(
            "UPDATE veicoli SET status='occupato' WHERE id=?",
            (vehicle_id,),
        )
        conn.execute(
            "INSERT INTO prenotazioni(user_id, vehicle_id, start_date, end_date, status) "
            "VALUES(?, ?, ?, ?, 'attiva')",
            (user_id, vehicle_id, start_date, end_date),
        )
        conn.commit()
        conn.close()

    # ── Rilascio ─────────────────────────────────────────────────────────

    def ottieni_prenotazioni_attive(self, user_id: int) -> list[tuple]:
        """
        Recupera le prenotazioni attive di un utente.

        Args:
            user_id: ID dell'utente.

        Returns:
            list[tuple]: Lista di (reservation_id, model, plate, start_date,
                end_date, photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT r.id, v.model, v.plate, r.start_date, r.end_date, v.photo_path
               FROM prenotazioni r
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.user_id = ? AND r.status = 'attiva'""",
            (user_id,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_storico_prenotazioni(self, user_id: int, limit: int = 8) -> list[tuple]:
        """
        Recupera lo storico delle prenotazioni concluse di un utente.

        Esclude le prenotazioni ancora attive (mostrate a parte nella
        sezione "Prenotazioni attive"), così una stessa prenotazione non
        compare due volte nella pagina di rilascio.

        Args:
            user_id: ID dell'utente.
            limit: Numero massimo di risultati.

        Returns:
            list[tuple]: Lista di (model, plate, start_date, end_date, status,
                photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT v.model, v.plate, r.start_date, r.end_date, r.status, v.photo_path
               FROM prenotazioni r
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.user_id = ? AND r.status = 'conclusa'
               ORDER BY r.id DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutte_prenotazioni_attive(self) -> list[tuple]:
        """
        Recupera le prenotazioni attive di TUTTI gli utenti (vista
        amministratore), per poter vedere e rilasciare anche i veicoli
        occupati dai dipendenti.

        Returns:
            list[tuple]: Lista di (reservation_id, username, model, plate,
                start_date, end_date, photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT r.id, u.username, v.model, v.plate, r.start_date,
                      r.end_date, v.photo_path
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.status = 'attiva'
               ORDER BY r.id DESC""",
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutto_storico_prenotazioni(self, limit: int = 15) -> list[tuple]:
        """
        Recupera lo storico delle prenotazioni concluse di TUTTI gli utenti
        (vista amministratore).

        Args:
            limit: Numero massimo di risultati.

        Returns:
            list[tuple]: Lista di (username, model, plate, start_date,
                end_date, status, photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT u.username, v.model, v.plate, r.start_date, r.end_date,
                      r.status, v.photo_path
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.status = 'conclusa'
               ORDER BY r.id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    def rilascia_veicolo(self, reservation_id: int) -> None:
        """
        Rilascia un veicolo chiudendo la prenotazione.

        Args:
            reservation_id: ID della prenotazione da chiudere.
        """
        conn = self._connetti()
        vehicle_id = conn.execute(
            "SELECT vehicle_id FROM prenotazioni WHERE id=?",
            (reservation_id,),
        ).fetchone()[0]
        conn.execute(
            "UPDATE prenotazioni SET status='conclusa' WHERE id=?",
            (reservation_id,),
        )
        conn.execute(
            "UPDATE veicoli SET status='disponibile' WHERE id=?",
            (vehicle_id,),
        )
        conn.commit()
        conn.close()

    # ── Recensioni ───────────────────────────────────────────────────────

    def ottieni_elenco_veicoli(self) -> list[tuple]:
        """
        Recupera la lista completa dei veicoli (per dropdown recensioni).

        Returns:
            list[tuple]: Lista di (id, model, plate).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT id, model, plate FROM veicoli"
        ).fetchall()
        conn.close()
        return data

    def ottieni_id_veicolo_per_targa(self, plate: str) -> Optional[int]:
        """
        Recupera l'ID di un veicolo dalla targa.

        Args:
            plate: Targa del veicolo.

        Returns:
            Optional[int]: ID del veicolo o None se non trovato.
        """
        conn = self._connetti()
        row = conn.execute(
            "SELECT id FROM veicoli WHERE plate=?",
            (plate,),
        ).fetchone()
        conn.close()
        return row[0] if row else None

    def invia_recensione(
        self, user_id: int, vehicle_id: int, notes: str, score: int
    ) -> None:
        """
        Invia una recensione/segnalazione per un veicolo.

        Args:
            user_id: ID dell'utente che recensisce.
            vehicle_id: ID del veicolo recensito.
            notes: Testo della segnalazione.
            score: Punteggio da 1 a 5.
        """
        conn = self._connetti()
        conn.execute(
            "INSERT INTO recensioni(user_id, vehicle_id, notes, score, review_date) "
            "VALUES(?, ?, ?, ?, ?)",
            (user_id, vehicle_id, notes, score, datetime.now().strftime("%Y-%m-%d")),
        )
        conn.commit()
        conn.close()

    def ottieni_recensioni_utente(self, user_id: int, limit: int = 5) -> list[tuple]:
        """
        Recupera le ultime recensioni di un utente.

        Args:
            user_id: ID dell'utente.
            limit: Numero massimo di risultati.

        Returns:
            list[tuple]: Lista di (score, notes, review_date, model).
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT rev.score, rev.notes, rev.review_date, v.model
               FROM recensioni rev
               JOIN veicoli v ON rev.vehicle_id = v.id
               WHERE rev.user_id = ?
               ORDER BY rev.id DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutte_segnalazioni(self, limit: int = 200) -> list[tuple]:
        """
        Recupera tutte le segnalazioni/recensioni inviate dai dipendenti,
        con nome utente e veicolo associato (vista amministratore).

        Args:
            limit: Numero massimo di risultati.

        Returns:
            list[tuple]: Lista di (username, score, notes, review_date,
                model, plate), dalla più recente alla meno recente.
        """
        conn = self._connetti()
        data = conn.execute(
            """SELECT u.username, rev.score, rev.notes, rev.review_date,
                      v.model, v.plate
               FROM recensioni rev
               JOIN utenti u ON rev.user_id = u.id
               JOIN veicoli v ON rev.vehicle_id = v.id
               ORDER BY rev.id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    # ── Gestione Flotta ──────────────────────────────────────────────────

    def ottieni_tutti_veicoli(self) -> list[tuple]:
        """
        Recupera tutti i veicoli con dati completi.

        Returns:
            list[tuple]: Lista di tuple
                (id, model, plate, status, fuel_level, brake_wear,
                 last_maintenance, photo_path).
        """
        conn = self._connetti()
        data = conn.execute(
            "SELECT id, model, plate, status, fuel_level, brake_wear, "
            "last_maintenance, photo_path FROM veicoli"
        ).fetchall()
        conn.close()
        return data

    def aggiungi_veicolo(
        self,
        model: str,
        plate: str,
        fuel: float,
        brake: float,
        photo_path: str,
    ) -> None:
        """
        Aggiunge un nuovo veicolo alla flotta.

        Args:
            model: Modello del veicolo.
            plate: Targa (deve essere unica).
            fuel: Livello carburante percentuale.
            brake: Usura freni percentuale.
            photo_path: Percorso relativo della foto.

        Raises:
            sqlite3.IntegrityError: Se la targa è già presente.
        """
        conn = self._connetti()
        conn.execute(
            "INSERT INTO veicoli(model, plate, status, fuel_level, brake_wear, "
            "last_maintenance, photo_path) "
            "VALUES(?, ?, 'disponibile', ?, ?, ?, ?)",
            (model, plate, fuel, brake, datetime.now().strftime("%d-%m-%Y"), photo_path),
        )
        conn.commit()
        conn.close()

    def elimina_veicolo(self, vehicle_id: int) -> None:
        """
        Elimina un veicolo, le sue prenotazioni e le sue recensioni associate.

        Rimuove anche le recensioni oltre alle prenotazioni: senza questo
        passaggio restavano righe orfane in 'recensioni' che facevano
        sparire silenziosamente quella recensione dallo storico dell'utente
        (il JOIN con 'veicoli' non trovava più il veicolo cancellato).

        Args:
            vehicle_id: ID del veicolo da eliminare.
        """
        conn = self._connetti()
        conn.execute("DELETE FROM veicoli WHERE id=?", (vehicle_id,))
        conn.execute("DELETE FROM prenotazioni WHERE vehicle_id=?", (vehicle_id,))
        conn.execute("DELETE FROM recensioni WHERE vehicle_id=?", (vehicle_id,))
        conn.commit()
        conn.close()

    def ottieni_veicolo_per_id(self, vehicle_id: int) -> Optional[tuple]:
        """
        Recupera i dati di un singolo veicolo.

        Args:
            vehicle_id: ID del veicolo.

        Returns:
            Optional[tuple]: (model, plate, fuel_level, brake_wear) o None.
        """
        conn = self._connetti()
        row = conn.execute(
            "SELECT model, plate, fuel_level, brake_wear FROM veicoli WHERE id=?",
            (vehicle_id,),
        ).fetchone()
        conn.close()
        return row

    def aggiorna_livello_carburante(self, vehicle_id: int, level: float) -> None:
        """
        Aggiorna il livello carburante di un veicolo.

        Args:
            vehicle_id: ID del veicolo.
            level: Nuovo livello percentuale.
        """
        conn = self._connetti()
        conn.execute(
            "UPDATE veicoli SET fuel_level=? WHERE id=?",
            (level, vehicle_id),
        )
        conn.commit()
        conn.close()

    def aggiorna_manutenzione_freni(
        self, vehicle_id: int, level: float, notes: str
    ) -> None:
        """
        Registra un intervento di manutenzione freni.

        Args:
            vehicle_id: ID del veicolo.
            level: Nuovo livello usura freni percentuale.
            notes: Note sull'intervento.
        """
        conn = self._connetti()
        conn.execute(
            "UPDATE veicoli SET brake_wear=?, last_maintenance=?, maint_notes=? "
            "WHERE id=?",
            (level, datetime.now().strftime("%d-%m-%Y"), notes, vehicle_id),
        )
        conn.commit()
        conn.close()

    # ── Report ───────────────────────────────────────────────────────────

    def ottieni_dati_report(self) -> dict[str, Any]:
        """
        Recupera tutti i dati necessari per il report PDF.

        Returns:
            dict: Dizionario con chiavi:
                - stats: dict con total_vehicles, available_vehicles,
                  total_reservations, total_reviews, total_users
                - vehicles: list di tuple veicoli completi
                - reservations: list di tuple ultime prenotazioni
        """
        conn = self._connetti()

        stats = {
            "total_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli"
            ).fetchone()[0],
            "available_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli WHERE status='disponibile'"
            ).fetchone()[0],
            "total_reservations": conn.execute(
                "SELECT COUNT(*) FROM prenotazioni"
            ).fetchone()[0],
            "total_reviews": conn.execute(
                "SELECT COUNT(*) FROM recensioni"
            ).fetchone()[0],
            "total_users": conn.execute(
                "SELECT COUNT(*) FROM utenti"
            ).fetchone()[0],
        }

        vehicles = conn.execute(
            "SELECT model, plate, status, fuel_level, brake_wear, last_maintenance "
            "FROM veicoli"
        ).fetchall()

        reservations = conn.execute(
            """SELECT u.username, v.model, r.start_date, r.end_date, r.status
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               ORDER BY r.id DESC LIMIT 15"""
        ).fetchall()

        conn.close()
        return {
            "stats": stats,
            "vehicles": vehicles,
            "reservations": reservations,
        }