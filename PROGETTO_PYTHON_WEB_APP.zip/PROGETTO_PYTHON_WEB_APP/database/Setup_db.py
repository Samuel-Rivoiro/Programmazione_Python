"""
Modulo: Setup_db.py
====================
Responsabile della creazione e inizializzazione del database SQLite3
per il sistema Smart Fleet IoT.

Questo modulo definisce lo schema del database (tabelle: utenti, veicoli,
prenotazioni, recensioni) e popola i dati di default (utenti e veicoli).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2026
"""

import os
import sqlite3

# ── Costanti di configurazione del database ──────────────────────────────────

DB_DIR: str = os.path.dirname(os.path.abspath(__file__)) # Directory del file corrente, usata per posizionare il database
DB_NAME: str = os.path.join(DB_DIR, "fleet_iot.db") # Percorso completo del file database SQLite.

# ── Dati predefiniti ─────────────────────────────────────────────────────────

DEFAULT_USERS: list[tuple[str, str, str]] = [
    ("admin", "admin123", "admin"),
    ("utente1", "user123", "standard"),
    ("utente2", "user456", "standard"),
]
"""Lista di utenti di default: (username, password, role)."""

DEFAULT_VEHICLES: list[tuple[str, str, str, float, float, str, str]] = [
    ("Fiat Panda", "CM340MX", "disponibile", 98.0, 95.0, "01-06-2026", "documents/panda.png"),
    ("Fiat 500X", "FA123XY", "disponibile", 85.0, 28.0, "15-03-2026", "documents/500x.jpeg"),
    ("Jeep Renegade", "GH789AB", "disponibile", 72.0, 60.0, "20-05-2026", "documents/jeep_ranegade.jpg"),
    ("Toyota Yaris", "TY456CD", "disponibile", 100.0, 90.0, "10-06-2026", "documents/toyota_yaris.jpg"),
    ("Volkswagen Golf", "VW321EF", "disponibile", 91.0, 75.0, "05-05-2026", "documents/golf.jpg"),
    ("Ford Focus", "FD012GH", "disponibile", 65.0, 85.0, "22-04-2026", "documents/ford_focus.jpg"),
    ("BMW Serie 1", "BM345IJ", "disponibile", 88.0, 95.0, "30-06-2026", "documents/bmw_serie1.jpg"),
    ("Renault Clio", "RN678KL", "disponibile", 55.0, 40.0, "01-04-2026", "documents/clio.jpg"),
    ("Peugeot 208", "PG901MN", "disponibile", 79.0, 70.0, "15-06-2026", "documents/peugeot208.jpg"),
    ("Mercedes Classe A", "MB234OP", "disponibile", 93.0, 88.0, "25-06-2026", "documents/mercedes_classe_a.jpg"),
]
"""Lista di veicoli di default: (modello, targa, stato, carburante%, freni%, ultima_manutenzione, photo_path)."""


# ── Funzioni di setup ────────────────────────────────────────────────────────


def crea_tabelle(cursor: sqlite3.Cursor) -> None:
    """
    Crea tutte le tabelle del database se non esistono già.

    Tabelle create:
        - utenti: utenti del sistema (username, password, role).
        - veicoli: veicoli della flotta (modello, targa, stato, telemetria, foto).
        - prenotazioni: prenotazioni dei veicoli da parte degli utenti.
        - recensioni: recensioni e segnalazioni sui veicoli.

    Args:
        cursor: Cursore attivo su connessione SQLite.

    Returns:
        None
    """
    # ── 1. Tabella Utenti ────────────────────────────────────────────────
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS utenti (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role     TEXT NOT NULL CHECK(role IN ('standard', 'admin'))
        )
        """
    )

    # ── 2. Tabella Veicoli ───────────────────────────────────────────────
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS veicoli (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            model             TEXT    NOT NULL,
            plate             TEXT    UNIQUE NOT NULL,
            status            TEXT    NOT NULL DEFAULT 'disponibile',
            fuel_level        REAL    DEFAULT 100.0,
            brake_wear        REAL    DEFAULT 100.0,
            last_maintenance  TEXT    DEFAULT 'N/D',
            maint_notes       TEXT    DEFAULT '',
            photo_path        TEXT    DEFAULT ''
        )
        """
    )

    # ── 3. Tabella Prenotazioni ──────────────────────────────────────────
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS prenotazioni (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER,
            vehicle_id INTEGER,
            start_date TEXT,
            end_date   TEXT,
            status     TEXT DEFAULT 'attiva',
            FOREIGN KEY(user_id)    REFERENCES utenti(id),
            FOREIGN KEY(vehicle_id) REFERENCES veicoli(id)
        )
        """
    )

    # ── 4. Tabella Recensioni / Segnalazioni ─────────────────────────────
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS recensioni (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            vehicle_id  INTEGER,
            notes       TEXT,
            score       INTEGER,
            review_date TEXT,
            FOREIGN KEY(user_id)    REFERENCES utenti(id),
            FOREIGN KEY(vehicle_id) REFERENCES veicoli(id)
        )
        """
    )


def migra_colonne(cursor: sqlite3.Cursor) -> None:
    """
    Aggiunge colonne mancanti alla tabella veicoli in modo sicuro,
    senza errori se le colonne esistono già (migrazione incrementale).

    Questa funzione garantisce la retrocompatibilità con versioni
    precedenti del database che potrebbero non avere tutte le colonne.

    Args:
        cursor: Cursore attivo su connessione SQLite.

    Returns:
        None
    """
    # Mappa delle colonne da aggiungere con relativa definizione SQL
    columns_to_add = [
        ("last_maintenance", "TEXT DEFAULT 'N/D'"),
        ("maint_notes", "TEXT DEFAULT ''"),
        ("photo_path", "TEXT DEFAULT ''"),
    ]

    for col_name, col_definition in columns_to_add:
        try:
            cursor.execute(
                f"ALTER TABLE veicoli ADD COLUMN {col_name} {col_definition}"
            )
        except sqlite3.OperationalError:
            # La colonna esiste già — nessuna azione necessaria
            pass


def inserisci_utenti_default(cursor: sqlite3.Cursor) -> None:
    """
    Inserisce gli utenti predefiniti nel database, ignorando i duplicati.

    Utilizza INSERT indipendenti con gestione dell'eccezione IntegrityError
    per evitare errori in caso di esecuzioni multiple del setup.

    Args:
        cursor: Cursore attivo su connessione SQLite.

    Returns:
        None
    """
    for username, password, role in DEFAULT_USERS:
        try:
            cursor.execute(
                "INSERT INTO utenti (username, password, role) VALUES (?, ?, ?)",
                (username, password, role),
            )
            cursor.connection.commit()
        except sqlite3.IntegrityError:
            # Utente già presente nel database
            pass


def inserisci_veicoli_default(cursor: sqlite3.Cursor) -> None:
    """
    Inserisce i veicoli predefiniti nel database, ignorando i duplicati.

    Args:
        cursor: Cursore attivo su connessione SQLite.

    Returns:
        None
    """
    for model, plate, status, fuel, brake, maint, photo_path in DEFAULT_VEHICLES:
        try:
            cursor.execute(
                "INSERT INTO veicoli "
                "(model, plate, status, fuel_level, brake_wear, last_maintenance, photo_path) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (model, plate, status, fuel, brake, maint, photo_path),
            )
            cursor.connection.commit()
        except sqlite3.IntegrityError:
            # Veicolo già presente nel database
            pass


def inizializza_database() -> None:
    """
    Inizializza completamente il database Smart Fleet IoT.

    Procedura:
        1. Crea/aggiorna lo schema delle tabelle.
        2. Esegue migrazioni incrementali delle colonne.
        3. Popola utenti e veicoli di default.

    La funzione è idempotente: può essere eseguita più volte senza
    causare errori o duplicazioni.

    Returns:
        None
    """
    # Connessione al database SQLite (crea il file se non esiste)
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # Creazione delle tabelle
    crea_tabelle(cursor)

    # Migrazione colonne per retrocompatibilità
    migra_colonne(cursor)

    conn.commit()

    # Popolamento dati di default
    inserisci_utenti_default(cursor)
    inserisci_veicoli_default(cursor)

    conn.close()

    print(f"[DB] Setup completato. Database: {DB_NAME}")
    print("[MAIN] Applicazione pronta. In fase di avvio...")

# ── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Esecuzione diretta dello script: inizializza il database.
    inizializza_database()
