"""
Modulo: Start_main_app.py
==========================
Applicazione principale Smart Fleet IoT — Sistema di Gestione Flotta Aziendale.

Questo modulo implementa l'interfaccia grafica (GUI) basata su CustomTkinter
per la gestione completa di una flotta aziendale, offrendo funzionalità di:
    - Autenticazione utenti (accesso/registrazione)
    - Dashboard amministratore con KPI e telemetria IoT
    - Prenotazione e rilascio veicoli
    - Recensioni e segnalazioni
    - Gestione completa del parco veicoli (admin)
    - Generazione reportistica PDF

Architettura (modulare, un file per responsabilità):
    - paths.py: percorsi condivisi (PROJECT_ROOT, memoria ultima cartella foto)
    - theme.py: palette colori e font condivisi
    - database/db_manager.py: DatabaseManager, accesso al database (pattern
      Repository), accanto a database/Setup_db.py (schema e dati iniziali)
    - widgets_mixin.py: WidgetsMixin, helper GUI generici (bottoni, card, ecc.)
    - pages/: un Mixin per pagina (auth, navigation, dashboard, booking,
      release, review, fleet, report)
    - Start_main_app.py (questo file): compone App unendo tutti i Mixin e
      contiene l'entry point dell'applicazione.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os

import customtkinter as ctk

from paths import PROJECT_ROOT
from theme import BG
from database.Setup_db import inizializza_database, DB_NAME
from database.db_manager import DatabaseManager

from widgets_mixin import WidgetsMixin
from pages.authentication import AuthMixin
from pages.navigation import NavigationMixin
from pages.dashboard import DashboardMixin
from pages.booking import BookingMixin
from pages.release import ReleaseMixin
from pages.review import ReviewMixin
from pages.fleet import FleetMixin
from pages.report import ReportMixin


# ══════════════════════════════════════════════════════════════════════════════
# APPLICAZIONE PRINCIPALE
# ══════════════════════════════════════════════════════════════════════════════

class App(
    ctk.CTk,
    WidgetsMixin,
    AuthMixin,
    NavigationMixin,
    DashboardMixin,
    BookingMixin,
    ReleaseMixin,
    ReviewMixin,
    FleetMixin,
    ReportMixin,
):
    """
    Finestra principale dell'applicazione Smart Fleet IoT.

    Gestisce la navigazione tra le diverse schermate (accesso, dashboard,
    prenotazione, rilascio, recensioni, gestione flotta, report) e
    mantiene lo stato della sessione utente. Il comportamento di ogni
    pagina è definito nei rispettivi Mixin (vedi pages/), composti qui
    insieme agli helper grafici generici (WidgetsMixin).

    Attributes:
        uid (int | None): ID dell'utente autenticato.
        role (str | None): Ruolo dell'utente ('admin' o 'standard').
        uname (str | None): Username dell'utente autenticato.
        db (DatabaseManager): Gestore del database.
        content_frame (ctk.CTkScrollableFrame): Contenitore dei contenuti.
    """

    # Costante per la cartella documents
    DOCS: str = os.path.join(PROJECT_ROOT, "documents")

    # Soglie (larghezza minima in px, fattore scala) per il ridimensionamento
    # reattivo di font e widget in base alla larghezza corrente della finestra.
    _SCALE_BREAKPOINTS: tuple[tuple[int, float], ...] = (
        (0, 0.9), (1100, 1.0), (1500, 1.1),
    )

    def __init__(self) -> None:
        """Inizializza l'applicazione, il database e mostra la schermata di accesso."""
        super().__init__()
        self.title("Smart Fleet IoT — Gestione Flotta Aziendale")
        self.configure(fg_color=BG)
        self.geometry("1300x840+520+70")
        self.minsize(1080, 680)

        # Scaling reattivo: font e widget si adattano al ridimensionamento
        self._current_scale: float = 1.0
        self.bind("<Configure>", self._al_ridimensionamento_finestra)

        # Stato sessione utente
        self.uid = None
        self.role = None
        self.uname = None

        # Inizializzazione database e GUI
        inizializza_database()
        self.db = DatabaseManager(DB_NAME)
        self._carica_immagini()
        self.mostra_accesso()


# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Avvia l'applicazione Smart Fleet IoT.
    app = App()
    app.mainloop()