"""
Modulo: pages/report.py
=======================
Pagina di reportistica PDF (solo admin) di Smart Fleet IoT.

Contiene ReportMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.platypus import Table, TableStyle

from paths import PROJECT_ROOT
from theme import (
    ACCENT,
    BORDER,
    CARD,
    MUTED,
    OK,
    PURPLE,
    PURPLE_HOVER,
    SIDEBAR,
    TEXT,
    WARN,
    _hex_a_rgb,
)


class ReportMixin:
    """Pagina Reportistica PDF (solo admin)."""

    def pagina_report(self) -> None:
        """
        Mostra la pagina di reportistica con anteprima KPI e pulsante
        per generare il PDF completo della flotta.

        Il PDF generato (report_utilizzo_flotta.pdf) contiene:
            - Intestazione con titolo e data
            - Riepilogo statistiche
            - Tabella parco veicoli
            - Tabella ultime prenotazioni
            - Piè di pagina
        """
        self._pulisci_contenuto()
        self._intestazione(
            "📄",
            "Reportistica PDF",
            "Genera il report completo delle attività flotta",
            color=PURPLE,
        )

        # Recupero dati report
        report_data = self.db.ottieni_dati_report()
        stats = report_data["stats"]
        vehicles_data = report_data["vehicles"]
        reservations_data = report_data["reservations"]

        # ── Anteprima statistiche ────────────────────────────────────────
        preview_card = self._sezione(
            self.content_frame, "Anteprima Statistiche", icon="📊", color=PURPLE
        )

        self._riga_kpi(preview_card, [
            ("🚗", stats["total_vehicles"], "Veicoli", ACCENT),
            ("✅", stats["available_vehicles"], "Disponibili", OK),
            ("📅", stats["total_reservations"], "Prenotazioni", WARN),
            ("⭐", stats["total_reviews"], "Segnalazioni", PURPLE),
            ("👥", stats["total_users"], "Utenti", MUTED),
        ], padx=16, pady=10)

        msg_label = self._etichetta(preview_card, "", font=("Consolas", 10))
        msg_label.pack(pady=6)

        def _rgb01(hex_color: str) -> tuple[float, float, float]:
            """Converte un colore esadecimale in una tupla RGB 0-1 per ReportLab."""
            r, g, b = _hex_a_rgb(hex_color)
            return (r / 255, g / 255, b / 255)

        def _genera_pdf() -> None:
            """
            Genera il report PDF utilizzando ReportLab.

            Il PDF include:
                - Copertina con titolo
                - KPI riepilogativi
                - Tabella completa veicoli
                - Tabella ultime prenotazioni
                - Piè di pagina con data e copyright
            """
            # Percorso assoluto della cartella dedicata ai report.
            reports_dir = os.path.join(PROJECT_ROOT, "REPORT_STATISTICHE_FLOTTA")
            os.makedirs(reports_dir, exist_ok=True)
            filename = os.path.join(reports_dir, "report_utilizzo_flotta.pdf")
            cv = pdf_canvas.Canvas(filename, pagesize=A4)
            width, height = A4

            # ── Intestazione ─────────────────────────────────────────────
            # Barra superiore navy con filo accent indaco
            cv.setFillColorRGB(*_rgb01(SIDEBAR))
            cv.rect(0, height - 75, width, 75, fill=1, stroke=0)
            cv.setFillColorRGB(*_rgb01(ACCENT))
            cv.rect(0, height - 78, width, 3, fill=1, stroke=0)
            cv.setFillColorRGB(1, 1, 1)
            cv.setFont("Helvetica-Bold", 18)
            cv.drawString(36, height - 38, "SMART FLEET IoT — Report Statistiche Flotta")
            cv.setFillColorRGB(*_rgb01(MUTED))
            cv.setFont("Helvetica", 9)
            now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
            cv.drawString(
                36, height - 56,
                f"Generato il {now_str}  |  ITS Academy ICT Piemonte",
            )

            # ── KPI ──────────────────────────────────────────────────────
            y_pos = height - 100
            kpi_labels = [
                "Veicoli Totali", "Disponibili", "Prenotazioni",
                "Segnalazioni", "Utenti",
            ]
            kpi_values = [
                stats["total_vehicles"], stats["available_vehicles"],
                stats["total_reservations"], stats["total_reviews"],
                stats["total_users"],
            ]
            for i, (lbl, val) in enumerate(zip(kpi_labels, kpi_values)):
                x_offset = 36 + i * 100
                cv.setFillColorRGB(*_rgb01(ACCENT))
                cv.setFont("Helvetica-Bold", 14)
                cv.drawString(x_offset, y_pos, str(val))
                cv.setFillColorRGB(*_rgb01(MUTED))
                cv.setFont("Helvetica", 8)
                cv.drawString(x_offset, y_pos - 14, lbl)

            y_pos -= 40

            # ── Stile tabelle ────────────────────────────────────────────
            table_style = TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(SIDEBAR)),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 8),
                ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor(CARD)),
                ("TEXTCOLOR", (0, 1), (-1, -1), colors.HexColor(TEXT)),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 1), (-1, -1), 7),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor(BORDER)),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("PADDING", (0, 0), (-1, -1), 4),
            ])

            # ── Tabella Veicoli ──────────────────────────────────────────
            vehicle_table_data = [
                ["Modello", "Targa", "Stato", "Carb%", "Freni%", "Ult.Manut."],
                *[
                    [v[0], v[1], v[2].upper(), f"{v[3]:.0f}%", f"{v[4]:.0f}%", v[5] or "N/D"]
                    for v in vehicles_data
                ],
            ]

            # ── Tabella Prenotazioni ─────────────────────────────────────
            reservation_table_data = [
                ["Utente", "Veicolo", "Dal", "Al", "Stato"],
                *[[r[0], r[1], r[2], r[3], r[4].upper()] for r in reservations_data],
            ]

            # ── Rendering tabelle ────────────────────────────────────────
            sections = [
                ("PARCO VEICOLI", vehicle_table_data,
                 [4 * cm, 2.5 * cm, 2.8 * cm, 1.5 * cm, 1.5 * cm, 3 * cm]),
                ("ULTIME PRENOTAZIONI", reservation_table_data,
                 [3.5 * cm, 4 * cm, 3 * cm, 3 * cm, 3 * cm]),
            ]

            for title, data, col_widths in sections:
                # Nuova pagina se spazio insufficiente
                if y_pos < 120:
                    cv.showPage()
                    y_pos = height - 50

                # Titolo sezione
                cv.setFillColorRGB(*_rgb01(ACCENT))
                cv.setFont("Helvetica-Bold", 12)
                cv.drawString(36, y_pos, f"▶  {title}")
                y_pos -= 14

                # Tabella
                table = Table(data, colWidths=col_widths)
                table.setStyle(table_style)
                table.wrapOn(cv, width, height)
                _, table_height = table.wrap(0, 0)

                if y_pos - table_height < 60:
                    cv.showPage()
                    y_pos = height - 50

                table.drawOn(cv, 36, y_pos - table_height)
                y_pos -= table_height + 20

            # ── Piè di pagina ────────────────────────────────────────────
            cv.setFillColorRGB(*_rgb01(SIDEBAR))
            cv.rect(0, 0, width, 30, fill=1, stroke=0)
            cv.setFillColorRGB(*_rgb01(MUTED))
            cv.setFont("Helvetica-Oblique", 7)
            cv.drawString(36, 11, "Smart Fleet IoT — ITS Academy ICT Piemonte")
            cv.drawRightString(
                width - 36, 11, datetime.now().strftime("%d/%m/%Y")
            )

            cv.save()
            msg_label.configure(
                text=f"✓  PDF generato: {os.path.abspath(filename)}", font=("Consolas", 10), text_color=OK
            )

        self._pulsante(
            preview_card,
            "⬇  Genera Report PDF",
            _genera_pdf,
            fg_color=PURPLE,
            hover_color=PURPLE_HOVER,
            height=44,
            width=260,
            font=("Roboto", 13, "bold"),
        ).pack(pady=(4, 20))
