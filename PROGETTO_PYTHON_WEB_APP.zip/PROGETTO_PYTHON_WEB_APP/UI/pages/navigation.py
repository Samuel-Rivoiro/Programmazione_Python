"""
Modulo: pages/navigation.py
===========================
Shell principale (sidebar di navigazione + area contenuti) di Smart Fleet IoT.

Contiene NavigationMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from typing import Any, Callable

import customtkinter as ctk

from theme import (
    ACCENT,
    BG,
    BORDER,
    CARD_ALT,
    ERR,
    F_BODY,
    F_SM,
    FAINT,
    MUTED,
    OK,
    SIDEBAR,
    TEXT,
)


class NavigationMixin:
    """Sidebar di navigazione e shell principale dell'app (dopo l'accesso)."""

    def mostra_menu(self) -> None:
        """
        Costruisce l'interfaccia principale con sidebar di navigazione
        e area contenuti scrollabile. La sidebar include:
            - Logo e nome app
            - Menu principale (Dashboard solo admin; Prenotazione e
              Recensione solo utente standard; Rilascio per tutti)
            - Menu amministrazione (solo per admin)
            - Box utente con logout
        """
        self._pulisci_tutto()

        # ── Sidebar ──────────────────────────────────────────────────────
        sidebar = ctk.CTkFrame(
            self, width=258, fg_color=SIDEBAR, corner_radius=0
        )
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = ctk.CTkFrame(sidebar, fg_color="transparent")
        brand.pack(pady=(22, 10), fill="x")
        if self.iLogoSm:
            self._etichetta(brand, "", image=self.iLogoSm).pack()
        self._etichetta(brand, "Smart Fleet", font=("Roboto", 17, "bold")).pack(pady=(6, 0))
        self._etichetta(brand, "IoT Fleet Manager", font=F_SM, color=MUTED).pack(
            pady=(1, 0)
        )
        self._separatore(sidebar)

        # ── Sistema di navigazione con indicatore attivo a barra laterale ─
        self._nav_entries: list[dict[str, Any]] = []

        def _attiva(entry: dict[str, Any]) -> None:
            """
            Evidenzia la voce di navigazione selezionata e richiama la
            relativa pagina.

            Args:
                entry: Dizionario che descrive il pulsante di navigazione
                    (bottone, indicatore laterale, comando pagina).
            """
            for e in self._nav_entries:
                active = e is entry
                e["btn"].configure(
                    fg_color=self._tinta(ACCENT, 0.22) if active else "transparent",
                    text_color=TEXT if active else MUTED,
                )
                e["indicator"].configure(fg_color=ACCENT if active else "transparent")
            entry["command"]()

        def _pulsante_nav(icon: str, label: str, command: Callable[[], None]) -> dict[str, Any]:
            """
            Crea un pulsante di navigazione nella sidebar, con icona,
            etichetta e indicatore di stato attivo a barra laterale.

            Args:
                icon: Emoji icona.
                label: Testo del pulsante.
                command: Funzione da eseguire al click (naviga alla pagina).

            Returns:
                dict: Riferimenti del pulsante creato (per gestirne lo stato).
            """
            row = ctk.CTkFrame(sidebar, fg_color="transparent")
            row.pack(fill="x", padx=(12, 12), pady=2)

            indicator = ctk.CTkFrame(
                row, width=3, height=1, corner_radius=2, fg_color="transparent"
            )
            indicator.pack(side="left", fill="y", padx=(0, 6))

            btn = ctk.CTkButton(
                row,
                text=f"  {icon}   {label}",
                anchor="w",
                height=42,
                corner_radius=10,
                fg_color="transparent",
                hover_color=CARD_ALT,
                text_color=MUTED,
                font=F_BODY,
                command=lambda: _attiva(entry),
            )
            btn.pack(side="left", fill="both", expand=True)

            entry = {"row": row, "btn": btn, "indicator": indicator, "command": command}
            self._nav_entries.append(entry)
            return entry

        # Pulsanti menu principale
        self._etichetta(
            sidebar, "MENU PRINCIPALE", font=("Roboto", 9, "bold"), color=FAINT
        ).pack(anchor="w", padx=22, pady=(10, 2))

        dash_entry = None
        if self.role == "admin":
            dash_entry = _pulsante_nav("📊", "Dashboard", self.pagina_dashboard)

        # La Prenotazione è riservata agli utenti standard: l'amministratore
        # gestisce la flotta (vedi menu Amministrazione) e non prenota veicoli.
        book_entry = None
        if self.role != "admin":
            book_entry = _pulsante_nav("📅", "Prenotazione", self.pagina_prenotazione)
        _pulsante_nav("🔄", "Rilascio Veicolo", self.pagina_rilascio)

        # Anche la Recensione è un'azione da utente standard (chi ha usato
        # il veicolo): l'amministratore non prenota, quindi non recensisce.
        if self.role != "admin":
            _pulsante_nav("⭐", "Recensione", self.pagina_recensioni)

        # Pulsanti amministrazione (solo admin)
        if self.role == "admin":
            self._separatore(sidebar)
            self._etichetta(
                sidebar,
                "AMMINISTRAZIONE",
                font=("Roboto", 9, "bold"),
                color=FAINT,
            ).pack(anchor="w", padx=22, pady=(4, 2))
            _pulsante_nav("🚗", "Gestione Flotta", self.pagina_flotta)
            _pulsante_nav("📋", "Segnalazioni", self.pagina_segnalazioni_admin)
            _pulsante_nav("📄", "Reportistica PDF", self.pagina_report)

        # ── Box utente in fondo alla sidebar ─────────────────────────────
        ctk.CTkFrame(sidebar, height=1, fg_color=BORDER).pack(
            fill="x", padx=16, pady=8, side="bottom"
        )

        user_box = self._scheda(sidebar)
        user_box.pack(side="bottom", fill="x", padx=12, pady=10)

        user_row = ctk.CTkFrame(user_box, fg_color="transparent")
        user_row.pack(fill="x", padx=12, pady=(12, 6))

        profile_img = (
            self.iLogoAdmin if self.role == "admin" else self.iLogoStd
        ) or self.iAv
        self._etichetta(user_row, "", image=profile_img).pack(side="left", padx=(0, 10))

        user_info = ctk.CTkFrame(user_row, fg_color="transparent")
        user_info.pack(side="left", fill="x", expand=True)
        self._etichetta(user_info, self.uname or "", font=("Roboto", 13, "bold")).pack(
            anchor="w"
        )
        role_color = ACCENT if self.role == "admin" else OK
        self._pillola(user_info, (self.role or "").upper(), role_color).pack(
            anchor="w", pady=(4, 0)
        )

        self._pulsante(
            user_box,
            "⎋  Disconnetti",
            self.mostra_accesso,
            fg_color="transparent",
            hover_color=self._tinta(ERR, 0.22),
            text_color=MUTED,
            height=32,
            width=200,
            font=F_SM,
            border_width=1,
            border_color=BORDER,
        ).pack(padx=12, pady=(4, 12))

        # ── Area contenuti scrollabile ───────────────────────────────────
        self.content_frame = ctk.CTkScrollableFrame(
            self, fg_color=BG, scrollbar_button_color=BORDER
        )
        self.content_frame.pack(side="right", fill="both", expand=True)

        # Naviga alla prima pagina in base al ruolo, evidenziando la voce
        if self.role == "admin" and dash_entry is not None:
            _attiva(dash_entry)
        else:
            _attiva(book_entry)
