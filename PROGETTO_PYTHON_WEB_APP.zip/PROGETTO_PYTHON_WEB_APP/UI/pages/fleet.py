"""
Modulo: pages/fleet.py
======================
Pagina di gestione parco veicoli (solo admin) di Smart Fleet IoT.

Contiene FleetMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os
import sqlite3
from tkinter import filedialog

import customtkinter as ctk

from paths import ottieni_ultima_cartella_foto, imposta_ultima_cartella_foto
from theme import (
    ACCENT,
    BG_ALT,
    BORDER,
    CARD,
    CARD_ALT,
    ERR,
    F_HEAD,
    F_SM,
    FAINT,
    MUTED,
    OK,
    OK_HOVER,
    WARN,
    WARN_HOVER,
)


class FleetMixin:
    """Pagina Gestione Flotta (solo admin)."""

    def pagina_flotta(self) -> None:
        """
        Mostra la pagina di gestione parco veicoli (solo admin) con:
            - Tabella completa della flotta (foto, ID, modello, targa, stato, etc.)
            - Azioni rapide: rifornimento, manutenzione, elimina
            - Form aggiunta nuovo veicolo con upload foto
        """
        self._pulisci_contenuto()
        self._intestazione(
            "🚗",
            "Gestione Parco Veicoli",
            "Aggiungi, rimuovi, rifornisci e manutieni i mezzi",
            color=ACCENT,
        )

        all_vehicles = self.db.ottieni_tutti_veicoli()

        # ── Tabella flotta ───────────────────────────────────────────────
        table_card = self._sezione(
            self.content_frame, "Flotta Completa", icon="🚗", color=ACCENT
        )

        # Intestazione e righe sono celle di un'unica griglia (grid) condivisa:
        # ogni colonna assume la larghezza della cella più larga in quella
        # colonna, su tutte le righe.
        columns = ["Foto", "ID", "Modello", "Targa", "Stato", "Carb%", "Freni%", "Manutenzione", "Azioni"]
        n_cols = len(columns)

        table_grid = ctk.CTkFrame(table_card, fg_color="transparent")
        table_grid.pack(fill="x", padx=12, pady=(0, 6))
        for col_idx in range(n_cols):
            table_grid.grid_columnconfigure(col_idx, weight=0)

        # Riga di intestazione (riga 0): frame decorativo senza figli che
        # riempie (sticky='nsew') lo spazio della riga come fascia di sfondo.
        ctk.CTkFrame(table_grid, width=1, height=1, fg_color=BG_ALT, corner_radius=8).grid(
            row=0, column=0, columnspan=n_cols, sticky="nsew"
        )
        for col_idx, col_name in enumerate(columns):
            self._etichetta(
                table_grid, col_name, font=("Roboto", 10, "bold"), color=FAINT,
            ).grid(row=0, column=col_idx, sticky="w", padx=8, pady=9)

        # Righe veicoli
        for row_num, vehicle in enumerate(all_vehicles, start=1):
            # row_num è un indice progressivo per la UI (1, 2, 3...);
            # l'id reale del database (vid) è usato per le azioni
            # (rifornimento/manutenzione/elimina).
            vid, model, plate, status, fuel, brake, maint, photo_path = vehicle
            status_color = OK if status == "disponibile" else ERR
            fuel_color = OK if fuel > 30 else ERR
            brake_color = OK if brake > 30 else WARN
            grid_row = row_num  # la riga 0 della griglia è l'intestazione

            if row_num % 2 == 0:
                ctk.CTkFrame(table_grid, width=1, height=1, fg_color=BG_ALT, corner_radius=8).grid(
                    row=grid_row, column=0, columnspan=n_cols, sticky="nsew"
                )

            # Foto thumbnail
            self._miniatura_veicolo(
                table_grid, photo_path, 42, 32, img_w=40, img_h=30,
                corner_radius=8, fg_color=CARD_ALT, fallback_font_size=12,
            ).grid(row=grid_row, column=0, sticky="w", padx=8, pady=5)

            self._etichetta(table_grid, f"#{row_num}", font=F_SM, color=MUTED).grid(
                row=grid_row, column=1, sticky="w", padx=8
            )
            self._etichetta(table_grid, model, font=F_SM).grid(
                row=grid_row, column=2, sticky="w", padx=8
            )
            self._badge_targa(table_grid, plate).grid(
                row=grid_row, column=3, sticky="w", padx=8
            )
            self._pillola(table_grid, status.upper(), status_color).grid(
                row=grid_row, column=4, sticky="w", padx=8
            )
            self._etichetta(table_grid, f"{fuel:.0f}%", color=fuel_color, font=F_SM).grid(
                row=grid_row, column=5, sticky="w", padx=8
            )
            self._etichetta(table_grid, f"{brake:.0f}%", color=brake_color, font=F_SM).grid(
                row=grid_row, column=6, sticky="w", padx=8
            )
            self._etichetta(table_grid, str(maint or "N/D"), color=MUTED, font=F_SM).grid(
                row=grid_row, column=7, sticky="w", padx=8
            )

            # Pulsanti azione
            action_frame = ctk.CTkFrame(table_grid, fg_color="transparent")
            action_frame.grid(row=grid_row, column=8, sticky="w", padx=6, pady=5)

            actions = [
                ("⛽", "rifornimento", OK),
                ("🔧", "manutenzione", WARN),
                ("🗑", "elimina", ERR),
            ]
            for icon, mode, color in actions:
                if mode == "elimina":
                    cmd = lambda v=vid: self._elimina_veicolo(v)
                else:
                    cmd = lambda m=mode, v=vid: self._finestra_azione(v, m)

                ctk.CTkButton(
                    action_frame,
                    text=icon,
                    width=32,
                    height=32,
                    corner_radius=16,
                    font=("Roboto", 13),
                    fg_color=self._tinta(color, 0.22),
                    hover_color=self._tinta(color, 0.42),
                    text_color=color,
                    anchor="center",
                    command=cmd,
                ).pack(side="left", padx=2)

        # ── Form aggiunta veicolo ────────────────────────────────────────
        add_card = self._sezione(
            self.content_frame, "Aggiungi Nuovo Veicolo", icon="➕", color=OK, pady=(14, 24)
        )

        fields_grid = ctk.CTkFrame(add_card, fg_color="transparent")
        fields_grid.pack(fill="x", padx=16, pady=(6, 4))
        fields_grid.grid_columnconfigure((0, 1, 2, 3), weight=1, uniform="add_field")

        field_labels = ["Modello", "Targa", "Carburante %", "Usura Freni %"]
        for col_idx, lbl in enumerate(field_labels):
            self._etichetta(fields_grid, lbl, color=MUTED, font=F_SM).grid(
                row=0, column=col_idx, sticky="w", padx=6, pady=(0, 4)
            )

        entry_model = self._campo(fields_grid, "es. Fiat Tipo", width=140)
        entry_model.grid(row=1, column=0, sticky="ew", padx=6)
        entry_plate = self._campo(fields_grid, "es. AB123CD", width=140)
        entry_plate.grid(row=1, column=1, sticky="ew", padx=6)
        entry_fuel = self._campo(fields_grid, "0-100", width=140)
        entry_fuel.grid(row=1, column=2, sticky="ew", padx=6)
        entry_brake = self._campo(fields_grid, "0-100", width=140)
        entry_brake.grid(row=1, column=3, sticky="ew", padx=6)

        # Riga inferiore: selezione foto a sinistra, conferma a destra
        action_row = ctk.CTkFrame(add_card, fg_color="transparent")
        action_row.pack(fill="x", padx=16, pady=(18, 4))

        photo_group = ctk.CTkFrame(action_row, fg_color="transparent")
        photo_group.pack(side="left")
        self._etichetta(photo_group, "Foto veicolo", color=MUTED, font=F_SM).pack(
            anchor="w", pady=(0, 4)
        )
        photo_inner = ctk.CTkFrame(photo_group, fg_color="transparent")
        photo_inner.pack(anchor="w")

        self._photo_path_var = ctk.StringVar(value="")
        photo_status_label = self._etichetta(
            photo_inner, "Nessuna foto selezionata", color=MUTED, font=F_SM
        )

        add_msg = self._etichetta(add_card, "", font=F_SM)

        def _scegli_foto() -> None:
            """
            Apre il dialogo di selezione file per la foto del veicolo.

            Il dialogo si apre nell'ultima cartella usata (vedi
            ottieni_ultima_cartella_foto/imposta_ultima_cartella_foto),
            invece che sempre nella cartella di default.
            """
            path = filedialog.askopenfilename(
                title="Seleziona foto del veicolo",
                initialdir=ottieni_ultima_cartella_foto(),
                filetypes=[
                    ("Immagini", "*.png *.jpg *.jpeg *.gif *.bmp"),
                    ("Tutti i file", "*.*"),
                ],
            )
            if path:
                self._photo_path_var.set(path)
                photo_status_label.configure(
                    text=os.path.basename(path), text_color=OK
                )
                # Ricorda la cartella per la prossima apertura del dialogo
                imposta_ultima_cartella_foto(os.path.dirname(path))
            else:
                self._photo_path_var.set("")
                photo_status_label.configure(
                    text="Nessuna foto selezionata", text_color=MUTED
                )

        # Guardia anti doppio-invio: se il pulsante "Aggiungi Veicolo" viene
        # attivato due volte (doppio click) prima che la pagina si aggiorni,
        # senza questa guardia la foto verrebbe copiata due volte (creando
        # una seconda copia tipo 'nome_1.jpg') prima ancora di sapere se il
        # veicolo verrà salvato una sola volta.
        _salvataggio_in_corso = {"attivo": False}

        def _aggiungi_veicolo() -> None:
            """Valida i campi e aggiunge il veicolo al database (una sola volta)."""
            if _salvataggio_in_corso["attivo"]:
                return

            model = entry_model.get().strip()
            plate = entry_plate.get().strip().upper()

            # Validazione campi numerici
            try:
                fuel_val = float(entry_fuel.get() or 100)
                brake_val = float(entry_brake.get() or 100)
            except ValueError:
                add_msg.configure(
                    text="Carburante % e Usura Freni % devono essere numeri!", text_color=ERR
                )
                return

            if not model or not plate:
                add_msg.configure(
                    text="Modello e Targa obbligatori!", text_color=ERR
                )
                return

            # Targa già presente: esce subito, senza copiare la foto a vuoto
            if self.db.ottieni_id_veicolo_per_targa(plate) is not None:
                add_msg.configure(text="Targa già presente!", text_color=ERR)
                return

            # Da qui in poi il salvataggio è "in corso": eventuali click
            # aggiuntivi sul pulsante vengono ignorati finché la pagina non
            # si aggiorna (o finché non falliamo, vedi except sotto).
            _salvataggio_in_corso["attivo"] = True
            add_btn.configure(state="disabled")

            # Copia la foto nella cartella documents/ mantenendo il nome originale
            photo_rel = self._copia_foto(self._photo_path_var.get())

            try:
                self.db.aggiungi_veicolo(model, plate, fuel_val, brake_val, photo_rel)
                self.after(400, self.pagina_flotta)
            except sqlite3.IntegrityError:
                add_msg.configure(
                    text="Targa già presente!", text_color=ERR
                )
                # Salvataggio fallito: si può ritentare, quindi sblocchiamo il pulsante.
                _salvataggio_in_corso["attivo"] = False
                add_btn.configure(state="normal")

        self._pulsante(
            photo_inner,
            "📷  Sfoglia",
            _scegli_foto,
            fg_color=CARD_ALT,
            hover_color=BORDER,
            height=32,
            width=110,
            font=F_SM,
            border_width=1,
            border_color=BORDER,
        ).pack(side="left", padx=(0, 10))
        photo_status_label.pack(side="left")

        add_btn = self._pulsante(
            action_row,
            "+  Aggiungi Veicolo",
            _aggiungi_veicolo,
            fg_color=OK,
            hover_color=OK_HOVER,
            height=38,
            width=190,
        )
        add_btn.pack(side="right")

        add_msg.pack(padx=16, pady=(6, 14), anchor="w")

    def _elimina_veicolo(self, vehicle_id: int) -> None:
        """
        Elimina un veicolo dal database e aggiorna la pagina.

        Args:
            vehicle_id: ID del veicolo da eliminare.
        """
        self.db.elimina_veicolo(vehicle_id)
        self.pagina_flotta()

    def _finestra_azione(self, vehicle_id: int, mode: str) -> None:
        """
        Apre una finestra di dialogo per rifornimento o manutenzione.

        Args:
            vehicle_id: ID del veicolo interessato.
            mode: 'rifornimento' o 'manutenzione'.
        """
        dialog = ctk.CTkToplevel(self)
        dialog.title("Rifornimento" if mode == "rifornimento" else "Manutenzione")
        dialog.geometry("420x360")
        dialog.configure(fg_color=CARD)
        dialog.grab_set()

        vehicle = self.db.ottieni_veicolo_per_id(vehicle_id)
        if not vehicle:
            dialog.destroy()
            return

        model, plate, fuel_level, brake_level = vehicle

        accent_color = OK if mode == "rifornimento" else WARN
        accent_hover = OK_HOVER if mode == "rifornimento" else WARN_HOVER
        icon = "⛽" if mode == "rifornimento" else "🔧"

        self._riquadro_icona(dialog, icon, accent_color, size=54, radius=16, font_size=23).pack(
            pady=(26, 10)
        )
        self._etichetta(
            dialog,
            "Rifornimento" if mode == "rifornimento" else "Manutenzione",
            font=F_HEAD,
        ).pack()

        plate_row = ctk.CTkFrame(dialog, fg_color="transparent")
        plate_row.pack(pady=(6, 6))
        self._etichetta(plate_row, model, font=F_SM, color=MUTED).pack(side="left", padx=(0, 8))
        self._badge_targa(plate_row, plate).pack(side="left")
        self._separatore(dialog)

        # Valore iniziale dello slider
        initial_value = fuel_level if mode == "rifornimento" else brake_level

        slider_var = ctk.DoubleVar(value=initial_value)
        value_label = self._etichetta(
            dialog,
            f"{initial_value:.0f}%",
            font=("Roboto", 26, "bold"),
            color=accent_color,
        )
        value_label.pack(pady=(8, 4))

        slider = ctk.CTkSlider(
            dialog,
            from_=0,
            to=100,
            variable=slider_var,
            width=300,
            progress_color=accent_color,
            button_color=accent_color,
            button_hover_color=accent_hover,
            command=lambda v: value_label.configure(text=f"{float(v):.0f}%"),
        )
        slider.pack(pady=8)

        # Campo note (solo per manutenzione)
        notes_entry = None
        if mode == "manutenzione":
            notes_entry = self._campo(dialog, "Note intervento...", width=300)
            notes_entry.pack(pady=6)

        def _salva() -> None:
            """Salva le modifiche e chiude il dialogo."""
            if mode == "rifornimento":
                self.db.aggiorna_livello_carburante(vehicle_id, slider_var.get())
            else:
                notes_text = notes_entry.get() if notes_entry else ""
                self.db.aggiorna_manutenzione_freni(
                    vehicle_id, slider_var.get(), notes_text
                )
            dialog.destroy()
            self.pagina_flotta()

        self._pulsante(
            dialog, "✓  Salva Modifiche", _salva,
            fg_color=accent_color, hover_color=accent_hover, height=42, width=220,
        ).pack(pady=(18, 14))
