"""
Modulo: pages/auth.py
=====================
Schermate di autenticazione (accesso e registrazione) di Smart Fleet IoT.

Contiene AuthMixin, composto nella classe App insieme agli altri Mixin
(vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import sqlite3

import customtkinter as ctk

from theme import ACCENT, BG, CARD_ALT, ERR, F_SM, MUTED, OK, OK_HOVER, SIDEBAR, TEXT


class AuthMixin:
    """Schermate di accesso e registrazione."""

    def mostra_accesso(self) -> None:
        """
        Mostra la schermata di accesso con pannello di branding a tinta unita
        a sinistra e form di accesso a destra.
        """
        self._pulisci_tutto()

        # ── Pannello sinistro: branding ───────────────────────────────────
        left = ctk.CTkFrame(self, fg_color=SIDEBAR, width=480)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        box = ctk.CTkFrame(left, fg_color="transparent")
        box.place(relx=0.5, rely=0.46, anchor="center")

        if self.iLogo:
            self._etichetta(box, "", image=self.iLogo).pack(pady=(0, 16))
        self._etichetta(box, "Smart Fleet IoT", font=("Roboto", 30, "bold")).pack()
        self._etichetta(box, "Gestione Flotta Aziendale Connessa", color=MUTED).pack(
            pady=(4, 0)
        )
        ctk.CTkFrame(box, height=3, width=64, fg_color=ACCENT, corner_radius=2).pack(
            pady=18
        )

        # Feature list
        features = [
            ("📅", "Prenotazione veicoli in tempo reale"),
            ("🔄", "Rilascio e riconsegna guidata"),
            ("📊", "Dashboard IoT e telemetria"),
            ("📄", "Reportistica PDF professionale"),
        ]
        for icon, desc in features:
            row_frame = ctk.CTkFrame(box, fg_color="transparent")
            row_frame.pack(anchor="w", pady=5)
            self._riquadro_icona(row_frame, icon, ACCENT, size=30, radius=9, font_size=13).pack(
                side="left", padx=(0, 10)
            )
            self._etichetta(row_frame, desc, color=TEXT, font=F_SM).pack(side="left")

        self._etichetta(
            left,
            "ITS Academy ICT Piemonte  •  2025/2026",
            font=F_SM,
            color=MUTED,
        ).place(relx=0.5, rely=0.97, anchor="center")

        # ── Pannello destro: form di accesso ──────────────────────────────
        right = ctk.CTkFrame(self, fg_color=BG)
        right.pack(side="right", fill="both", expand=True)

        form_frame = self._scheda(right)
        form_frame.place(relx=0.5, rely=0.5, anchor="center")

        self._riquadro_icona(form_frame, "🔐", ACCENT, size=48, radius=14, font_size=21).pack(
            pady=(34, 10)
        )
        self._etichetta(
            form_frame, "Accedi al Sistema", font=("Roboto", 21, "bold")
        ).pack(padx=60)
        self._etichetta(
            form_frame, "Inserisci le tue credenziali aziendali", color=MUTED, font=F_SM
        ).pack(pady=(4, 22))

        wrap_user, entry_user = self._campo_con_icona(form_frame, "👤", "Username", width=300)
        wrap_user.pack(padx=36, pady=6)

        wrap_pass, entry_pass = self._campo_con_icona(
            form_frame, "🔒", "Password", show="•", width=300
        )
        wrap_pass.pack(padx=36, pady=6)

        # Il tasto Invio sul campo password attiva l'accesso
        entry_pass.bind(
            "<Return>",
            lambda e: self._esegui_accesso(entry_user, entry_pass, error_label),
        )

        error_label = self._etichetta(form_frame, "", color=ERR, font=F_SM)
        error_label.pack(pady=(6, 2))

        self._pulsante(
            form_frame,
            "Accedi  →",
            lambda: self._esegui_accesso(entry_user, entry_pass, error_label),
            height=44,
            width=300,
            font=("Roboto", 13, "bold"),
        ).pack(padx=36, pady=8)

        self._pulsante(
            form_frame,
            "Nuovo dipendente? Registrati qui",
            self.mostra_registrazione,
            fg_color="transparent",
            hover_color=CARD_ALT,
            text_color=MUTED,
            width=300,
        ).pack(pady=(0, 30))

    def _esegui_accesso(
        self,
        entry_user: ctk.CTkEntry,
        entry_pass: ctk.CTkEntry,
        error_label: ctk.CTkLabel,
    ) -> None:
        """
        Esegue l'autenticazione verificando le credenziali sul database.

        Args:
            entry_user: Campo input username.
            entry_pass: Campo input password.
            error_label: Label per messaggi di errore.
        """
        username = entry_user.get().strip()
        password = entry_pass.get().strip()

        result = self.db.accedi(username, password)

        if result:
            self.uid, self.role, self.uname = result
            self.mostra_menu()
        else:
            error_label.configure(text="⚠  Credenziali non valide. Riprova.")

    # ══════════════════════════════════════════════════════════════════════
    # REGISTRAZIONE
    # ══════════════════════════════════════════════════════════════════════

    def mostra_registrazione(self) -> None:
        """
        Mostra la schermata di registrazione per nuovi utenti, con lo stesso
        pannello di branding a tinta unita dell'accesso per coerenza visiva.
        Il ruolo predefinito è 'standard'.
        """
        self._pulisci_tutto()

        left = ctk.CTkFrame(self, fg_color=SIDEBAR, width=480)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        box = ctk.CTkFrame(left, fg_color="transparent")
        box.place(relx=0.5, rely=0.5, anchor="center")

        if self.iLogo:
            self._etichetta(box, "", image=self.iLogo).pack(pady=(0, 16))
        self._etichetta(box, "Smart Fleet IoT", font=("Roboto", 30, "bold")).pack()
        self._etichetta(box, "Unisciti alla flotta connessa", color=MUTED).pack(
            pady=(4, 0)
        )
        ctk.CTkFrame(box, height=3, width=64, fg_color=OK, corner_radius=2).pack(
            pady=18
        )

        outer = ctk.CTkFrame(self, fg_color=BG)
        outer.pack(side="right", fill="both", expand=True)

        form_frame = self._scheda(outer)
        form_frame.place(relx=0.5, rely=0.5, anchor="center")

        self._riquadro_icona(form_frame, "🧾", OK, size=48, radius=14, font_size=21).pack(
            pady=(34, 10)
        )
        self._etichetta(
            form_frame, "Crea il tuo Account", font=("Roboto", 21, "bold")
        ).pack(padx=60)
        self._pillola(form_frame, "PROFILO STANDARD", OK).pack(pady=(8, 18))

        wrap_user, entry_user = self._campo_con_icona(form_frame, "👤", "Username", width=300)
        wrap_user.pack(padx=36, pady=6)

        wrap_pass, entry_pass = self._campo_con_icona(
            form_frame, "🔒", "Password", show="•", width=300
        )
        wrap_pass.pack(padx=36, pady=6)

        msg_label = self._etichetta(form_frame, "", font=F_SM)
        msg_label.pack(pady=6)

        def _registra() -> None:
            """Gestisce la logica di registrazione."""
            username = entry_user.get().strip()
            password = entry_pass.get().strip()

            if not username or not password:
                msg_label.configure(
                    text="Tutti i campi obbligatori!", text_color=ERR
                )
                return

            try:
                self.db.registra(username, password)
                msg_label.configure(
                    text="✓  Registrazione completata!", text_color=OK
                )
                # Dopo 1.4 secondi, torna alla schermata di accesso
                self.after(1400, self.mostra_accesso)
            except sqlite3.IntegrityError:
                msg_label.configure(
                    text="Username già in uso!", text_color=ERR
                )

        self._pulsante(
            form_frame,
            "Crea Account",
            _registra,
            fg_color=OK,
            hover_color=OK_HOVER,
            height=44,
            width=300,
            font=("Roboto", 13, "bold"),
        ).pack(padx=36, pady=8)

        self._pulsante(
            form_frame,
            "Torna al Login",
            self.mostra_accesso,
            fg_color="transparent",
            hover_color=CARD_ALT,
            text_color=MUTED,
            width=300,
        ).pack(pady=(0, 30))
