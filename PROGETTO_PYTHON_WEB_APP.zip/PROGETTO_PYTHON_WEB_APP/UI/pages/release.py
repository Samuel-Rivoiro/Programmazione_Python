"""
Modulo: pages/release.py
========================
Pagina di rilascio veicoli di Smart Fleet IoT.

Contiene ReleaseMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import customtkinter as ctk

from theme import ACCENT, BG_ALT, F_HEAD, F_SM, MUTED, OK, OK_HOVER, WARN


class ReleaseMixin:
    """Pagina Rilascio Veicolo."""

    def pagina_rilascio(self) -> None:
        """
        Mostra la pagina di rilascio veicoli con:
            - Elenco prenotazioni attive (con pulsante Rilascia)
            - Storico ultime prenotazioni

        Per l'amministratore la vista è estesa a TUTTI i dipendenti (con
        nome utente su ogni pratica), non solo alle proprie prenotazioni:
        l'admin non prenota mai veicoli, quindi altrimenti la pagina
        risulterebbe sempre vuota anche con veicoli occupati dagli
        utenti standard.
        """
        self._pulisci_contenuto()
        self._intestazione(
            "🔄", "Rilascio Veicolo", "Riconsegna la vettura e chiudi la pratica", color=WARN
        )

        is_admin = self.role == "admin"
        if is_admin:
            active = self.db.ottieni_tutte_prenotazioni_attive()
            history = self.db.ottieni_tutto_storico_prenotazioni()
        else:
            active = self.db.ottieni_prenotazioni_attive(self.uid or 0)
            history = self.db.ottieni_storico_prenotazioni(self.uid or 0)

        # ── Prenotazioni attive ──────────────────────────────────────────
        if not active:
            self._stato_vuoto(
                self.content_frame, "Nessuna prenotazione attiva",
                icon="✅", color=OK, pady=12, text_pady=26,
            )

        for reservation in active:
            if is_admin:
                res_id, username, model, plate, start, end, photo_path = reservation
            else:
                res_id, model, plate, start, end, photo_path = reservation
            card = self._scheda(self.content_frame)
            card.pack(fill="x", padx=30, pady=8)

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="x", padx=16, pady=(14, 4))
            self._miniatura_veicolo(
                inner, photo_path, 40, 40, corner_radius=12,
                fg_color=self._tinta(WARN, 0.18),
                fallback_color=WARN, fallback_font_size=17,
            ).pack(side="left", padx=(0, 12))

            text_frame = ctk.CTkFrame(inner, fg_color="transparent")
            text_frame.pack(side="left", fill="x", expand=True)
            title_row = ctk.CTkFrame(text_frame, fg_color="transparent")
            title_row.pack(anchor="w")
            self._etichetta(
                title_row, f"Pratica #{res_id}  —  {model}", font=F_HEAD
            ).pack(side="left", padx=(0, 8))
            self._badge_targa(title_row, plate).pack(side="left")
            if is_admin:
                self._pillola(title_row, f"👤 {username}", ACCENT).pack(
                    side="left", padx=(8, 0)
                )
            self._etichetta(
                text_frame, f"📆  Dal {start}   →   {end}", color=MUTED, font=F_SM
            ).pack(anchor="w", pady=(4, 0))

            # Closure per catturare res_id
            def _rilascia(rid: int = res_id) -> None:
                """Rilascia il veicolo e aggiorna la pagina."""
                self.db.rilascia_veicolo(rid)
                self.after(400, self.pagina_rilascio)

            self._pulsante(
                card,
                "✓  Rilascia e Chiudi",
                _rilascia,
                fg_color=OK,
                hover_color=OK_HOVER,
                height=36,
                width=200,
            ).pack(anchor="e", padx=16, pady=(4, 14))

        # ── Storico ──────────────────────────────────────────────────────
        if history:
            self._etichetta(
                self.content_frame,
                "Storico Prenotazioni",
                color=MUTED,
                font=F_HEAD,
            ).pack(anchor="w", padx=30, pady=(18, 8))

            hist_card = self._scheda(self.content_frame)
            hist_card.pack(fill="x", padx=30, pady=(0, 20))

            for idx, entry in enumerate(history):
                if is_admin:
                    username, model, plate, start, end, status, photo_path = entry
                else:
                    model, plate, start, end, status, photo_path = entry
                status_color = OK if status == "conclusa" else WARN
                row_bg = BG_ALT if idx % 2 == 0 else "transparent"

                row_frame = ctk.CTkFrame(hist_card, fg_color=row_bg, corner_radius=8)
                row_frame.pack(fill="x", padx=8, pady=2)

                left_row = ctk.CTkFrame(row_frame, fg_color="transparent")
                left_row.pack(side="left", padx=6, pady=7)

                # Miniatura del veicolo (foto reale, con fallback a icona)
                self._miniatura_veicolo(
                    left_row, photo_path, 32, 32, corner_radius=8,
                    fg_color=self._tinta(status_color, 0.18),
                    fallback_color=status_color, fallback_font_size=14,
                ).pack(side="left", padx=(4, 8))

                if is_admin:
                    self._etichetta(
                        left_row, f"👤 {username}", font=F_SM, color=ACCENT
                    ).pack(side="left", padx=(0, 8))
                self._etichetta(left_row, model, font=F_SM).pack(side="left", padx=(0, 8))
                self._badge_targa(left_row, plate).pack(side="left", padx=(0, 10))
                self._etichetta(
                    left_row, f"{start}  →  {end}", color=MUTED, font=F_SM
                ).pack(side="left")

                self._pillola(row_frame, status.upper(), status_color).pack(
                    side="right", padx=10, pady=4
                )
