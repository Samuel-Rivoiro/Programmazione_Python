"""
Modulo: pages/dashboard.py
==========================
Dashboard amministratore di Smart Fleet IoT (KPI, telemetria, alert).

Contiene DashboardMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import customtkinter as ctk

from theme import ACCENT, BG_ALT, ERR, F_SM, MUTED, OK, PURPLE, WARN


class DashboardMixin:
    """Pagina Dashboard (solo admin)."""

    def pagina_dashboard(self) -> None:
        """
        Mostra la dashboard amministratore con:
            - Banner hero
            - 6 KPI (veicoli, disponibili, occupati, prenotazioni, segnalazioni, utenti)
            - Griglia con telemetria e alert predittivi
        """
        self._pulisci_contenuto()
        self._intestazione(
            "📊", "Dashboard Amministratore", "Panoramica flotta e telemetria IoT", color=ACCENT
        )

        # Banner hero
        if self.iHero:
            hero_wrap = self._scheda(self.content_frame)
            hero_wrap.pack(padx=30, pady=(0, 14))
            self._etichetta(hero_wrap, "", image=self.iHero, corner_radius=14).pack(
                padx=4, pady=4
            )

        # Recupero dati dal database
        kpi = self.db.ottieni_dati_kpi()
        telemetry = self.db.ottieni_dati_telemetria()
        fuel_alerts = self.db.ottieni_avvisi_carburante()
        brake_alerts = self.db.ottieni_avvisi_freni()

        # ── Riga KPI ─────────────────────────────────────────────────────
        occupied = kpi["total_vehicles"] - kpi["available_vehicles"]

        self._riga_kpi(self.content_frame, [
            ("🚗", kpi["total_vehicles"], "Veicoli", ACCENT),
            ("✅", kpi["available_vehicles"], "Disponibili", OK),
            ("🔴", occupied, "Occupati", ERR),
            ("📅", kpi["active_reservations"], "Prenotazioni", WARN),
            ("⭐", kpi["total_reviews"], "Segnalazioni", PURPLE),
            ("👥", kpi["total_users"], "Utenti", MUTED),
        ])

        # ── Griglia: Telemetria + Alert ──────────────────────────────────
        grid = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        grid.pack(fill="both", padx=30, pady=10)
        grid.columnconfigure((0, 1), weight=1)

        # --- Telemetria (colonna sinistra) ---
        tel_card = self._scheda(grid)
        tel_card.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=4)
        self._intestazione_scheda(tel_card, "Telemetria", icon="🔬", color=ACCENT)

        for vehicle in telemetry:
            model, plate, fuel, brake, status = vehicle
            status_color = OK if status == "disponibile" else ERR
            fuel_color = OK if fuel > 30 else ERR
            brake_color = ACCENT if brake > 30 else WARN

            # Riga veicolo
            row_frame = ctk.CTkFrame(
                tel_card, fg_color="transparent"
            )
            row_frame.pack(fill="x", padx=14, pady=(4, 1))
            self._etichetta(
                row_frame, "●", color=status_color, font=("Roboto", 14)
            ).pack(side="left", padx=(0, 6))
            self._etichetta(row_frame, f"{model} ({plate})", font=F_SM).pack(side="left")

            # Barra carburante
            fuel_bar = ctk.CTkProgressBar(
                tel_card, height=6, corner_radius=3, progress_color=fuel_color, fg_color=BG_ALT
            )
            fuel_bar.pack(fill="x", padx=24, pady=(3, 1))
            fuel_bar.set(fuel / 100)

            # Barra freni
            brake_bar = ctk.CTkProgressBar(
                tel_card, height=6, corner_radius=3, progress_color=brake_color, fg_color=BG_ALT
            )
            brake_bar.pack(fill="x", padx=24, pady=(1, 8))
            brake_bar.set(brake / 100)

        # --- Alert Predittivi (colonna destra) ---
        alert_card = self._scheda(grid)
        alert_card.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=4)
        self._intestazione_scheda(alert_card, "Alert Predittivi", icon="⚠️", color=WARN)

        # Nessun alert → messaggio verde
        if not fuel_alerts and not brake_alerts:
            ok_frame = ctk.CTkFrame(
                alert_card, fg_color=self._tinta(OK, 0.16), corner_radius=10
            )
            ok_frame.pack(fill="x", padx=14, pady=8)
            self._etichetta(
                ok_frame,
                "✅  Nessuna anomalia — tutti i veicoli OK",
                color=OK,
            ).pack(padx=12, pady=14)

        # Alert carburante
        for veh in fuel_alerts:
            model, plate, fuel = veh
            alert_frame = ctk.CTkFrame(
                alert_card, fg_color=self._tinta(WARN, 0.16), corner_radius=10
            )
            alert_frame.pack(fill="x", padx=14, pady=4)
            self._etichetta(
                alert_frame,
                f"⛽  {model} ({plate}) — Carburante: {fuel:.0f}%",
                color=WARN,
            ).pack(padx=12, pady=10)

        # Alert freni
        for veh in brake_alerts:
            model, plate, brake = veh
            alert_frame = ctk.CTkFrame(
                alert_card, fg_color=self._tinta(ERR, 0.16), corner_radius=10
            )
            alert_frame.pack(fill="x", padx=14, pady=4)
            self._etichetta(
                alert_frame,
                f"🔧  {model} ({plate}) — Freni critici: {brake:.0f}%",
                color=ERR,
            ).pack(padx=12, pady=10)

        ctk.CTkFrame(alert_card, fg_color="transparent", width=1, height=6).pack(fill="x")
