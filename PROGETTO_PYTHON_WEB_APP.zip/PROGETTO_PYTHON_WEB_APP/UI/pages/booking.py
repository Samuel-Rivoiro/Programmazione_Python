"""
Modulo: pages/booking.py
========================
Pagina di prenotazione veicoli di Smart Fleet IoT.

Contiene BookingMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import customtkinter as ctk

from theme import (
    ACCENT,
    ACCENT_HOVER,
    BG_ALT,
    BORDER,
    CARD,
    ERR,
    F_HEAD,
    F_SM,
    MUTED,
    OK,
    OK_HOVER,
    WARN,
)


class BookingMixin:
    """Pagina Prenotazione Veicolo."""

    def pagina_prenotazione(self) -> None:
        """
        Mostra la pagina di prenotazione veicoli con:
            - Card "veicolo del mese" in evidenza (caso di test dello studio
              di fattibilità), prima dell'elenco veicoli
            - Griglia di card veicoli disponibili selezionabili (con foto,
              targa in stile reale, indicatori carburante/freni)
            - Form date inizio/fine
            - Pulsante di conferma
        """
        self._pulisci_contenuto()
        self._intestazione(
            "📅",
            "Prenotazione Veicolo",
            "Seleziona un mezzo e inserisci le date della tua prenotazione.",
            color=OK,
        )

        # Recupero veicoli disponibili
        available = self.db.ottieni_veicoli_disponibili()

        # Veicolo del mese — caso di test dello studio di fattibilità
        # (Fiat Panda, targa CM 340 MX: monitoraggio usura pastiglie freni),
        # mostrato prima dell'elenco per metterlo in evidenza agli utenti.
        # Visibile solo se il veicolo è ancora disponibile: se è già stato
        # prenotato, non deve comparire finché non viene rilasciato.
        veicolo_del_mese_disponibile = any(v[2] == "CM340MX" for v in available)
        if self.iCar and veicolo_del_mese_disponibile:
            car_card = self._scheda(self.content_frame, hover=True)
            car_card.pack(fill="x", padx=30, pady=(0, 18))
            inner_row = ctk.CTkFrame(car_card, fg_color="transparent")
            inner_row.pack(fill="x", padx=18, pady=16)

            img_wrap = ctk.CTkFrame(inner_row, fg_color=BG_ALT, corner_radius=12)
            img_wrap.pack(side="left", padx=(0, 18))
            self._etichetta(img_wrap, "", image=self.iCar).pack(padx=8, pady=8)

            text_frame = ctk.CTkFrame(inner_row, fg_color="transparent")
            text_frame.pack(side="left", fill="x", expand=True)
            self._pillola(text_frame, "⭐ VEICOLO DEL MESE", WARN).pack(anchor="w", pady=(0, 8))
            title_row = ctk.CTkFrame(text_frame, fg_color="transparent")
            title_row.pack(anchor="w")
            self._etichetta(title_row, "Fiat Panda", font=F_HEAD).pack(side="left", padx=(0, 10))
            self._badge_targa(title_row, "CM340MX").pack(side="left")
            self._etichetta(
                text_frame,
                "Efficienza ottima  •  Monitoraggio IoT pastiglie freni attivo",
                color=MUTED,
                font=F_SM,
            ).pack(anchor="w", pady=(8, 0))

        if not available:
            self._stato_vuoto(
                self.content_frame, "Nessun veicolo disponibile al momento", icon="🚧"
            )
            return

        self._etichetta(
            self.content_frame,
            f"Veicoli Disponibili  ·  {len(available)}",
            color=MUTED,
            font=F_HEAD,
        ).pack(anchor="w", padx=30, pady=(0, 8))

        # Griglia veicoli (4 colonne)
        grid = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        grid.pack(fill="x", padx=22, pady=4)
        grid.columnconfigure((0, 1, 2, 3), weight=1)

        self._selected_vehicle_id = ctk.IntVar(value=available[0][0])
        card_refs: list[tuple[ctk.CTkFrame, int]] = []

        def _seleziona(vid: int) -> None:
            """
            Seleziona la card veicolo indicata ed evidenzia il bordo,
            deselezionando visivamente le altre.

            Args:
                vid: ID del veicolo selezionato.
            """
            self._selected_vehicle_id.set(vid)
            for c, cvid in card_refs:
                active = cvid == vid
                c.configure(
                    border_color=ACCENT if active else BORDER,
                    border_width=2 if active else 1,
                    fg_color=self._tinta(ACCENT, 0.10) if active else CARD,
                )

        for i, vehicle in enumerate(available):
            vid, model, plate, fuel, brake, photo_path = vehicle
            fuel_color = OK if fuel > 40 else (WARN if fuel > 20 else ERR)
            brake_color = OK if brake > 40 else (WARN if brake > 20 else ERR)

            card = self._scheda(grid)
            card.grid(row=i // 4, column=i % 4, padx=6, pady=6, sticky="nsew")
            card.bind("<Button-1>", lambda e, v=vid: _seleziona(v))

            # Foto veicolo con letterbox coordinato
            self._miniatura_veicolo(
                card, photo_path, 190, 112, corner_radius=10, fallback_font_size=30,
            ).pack(fill="x", padx=10, pady=(10, 8))

            self._etichetta(card, model, font=("Roboto", 13, "bold")).pack(padx=10)
            self._badge_targa(card, plate).pack(pady=6)

            stats_row = ctk.CTkFrame(card, fg_color="transparent")
            stats_row.pack(pady=(0, 8))
            self._pillola(stats_row, f"⛽ {fuel:.0f}%", fuel_color).pack(side="left", padx=3)
            self._pillola(stats_row, f"🔧 {brake:.0f}%", brake_color).pack(side="left", padx=3)

            # Selettore veicolo
            ctk.CTkRadioButton(
                card,
                variable=self._selected_vehicle_id,
                value=vid,
                fg_color=ACCENT,
                hover_color=ACCENT_HOVER,
                border_color=BORDER,
                text="Seleziona questo veicolo",
                font=F_SM,
                command=lambda v=vid: _seleziona(v),
            ).pack(pady=(0, 14))

            card_refs.append((card, vid))

        _seleziona(available[0][0])

        # ── Form date ────────────────────────────────────────────────────
        date_card = self._sezione(
            self.content_frame, "Dettagli Prenotazione", icon="📅", color=OK, pady=14
        )

        date_row = ctk.CTkFrame(date_card, fg_color="transparent")
        date_row.pack(fill="x", padx=16, pady=10)

        self._etichetta(date_row, "Dal:", color=MUTED).pack(side="left", padx=(0, 6))
        entry_start = self._campo(date_row, "GG-MM-AAAA", width=150)
        entry_start.pack(side="left", padx=(0, 20))

        self._etichetta(date_row, "Al:", color=MUTED).pack(side="left", padx=(0, 6))
        entry_end = self._campo(date_row, "GG-MM-AAAA", width=150)
        entry_end.pack(side="left")

        msg_label = self._etichetta(date_card, "", font=F_SM)
        msg_label.pack(pady=2)

        def _conferma_prenotazione() -> None:
            """Valida le date e conferma la prenotazione."""
            start = entry_start.get().strip()
            end = entry_end.get().strip()

            if not start or not end:
                msg_label.configure(
                    text="Inserire entrambe le date!", text_color=ERR
                )
                return

            self.db.prenota_veicolo(
                self.uid or 0,
                self._selected_vehicle_id.get(),
                start,
                end,
            )
            msg_label.configure(
                text="✓  Prenotazione confermata!", text_color=OK
            )
            # Aggiorna la pagina dopo 1.4 secondi
            self.after(1400, self.pagina_prenotazione)

        self._pulsante(
            date_card, "✓  Conferma Prenotazione", _conferma_prenotazione,
            fg_color=OK, hover_color=OK_HOVER, height=42, width=260,
        ).pack(pady=(4, 18))
