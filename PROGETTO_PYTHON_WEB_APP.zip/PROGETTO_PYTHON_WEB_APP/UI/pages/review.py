"""
Modulo: pages/review.py
=======================
Pagina di recensioni e segnalazioni di Smart Fleet IoT.

Contiene ReviewMixin, composto nella classe App insieme agli altri
Mixin (vedi Start_main_app.py).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import customtkinter as ctk

from theme import (
    ACCENT,
    ACCENT_HOVER,
    BORDER,
    BORDER_LIGHT,
    CARD_ALT,
    F_HEAD,
    F_SM,
    FAINT,
    MUTED,
    OK,
    PURPLE,
    PURPLE_HOVER,
    TEXT,
    WARN,
)


class ReviewMixin:
    """Pagina Recensione e Segnalazioni."""

    def pagina_recensioni(self) -> None:
        """
        Mostra la pagina di recensioni con:
            - Form nuova segnalazione (dropdown veicolo, stelle, note)
            - Storico ultime recensioni dell'utente
        """
        self._pulisci_contenuto()
        self._intestazione(
            "📋",
            "Recensione e Segnalazioni",
            "Feedback e anomalie sull'utilizzo del veicolo",
            color=PURPLE,
        )

        vehicles = self.db.ottieni_elenco_veicoli()
        if not vehicles:
            return

        # ── Form nuova segnalazione ──────────────────────────────────────
        form_card = self._sezione(
            self.content_frame, "Nuova Segnalazione", icon="📋", color=PURPLE
        )

        # Dropdown veicolo
        self._etichetta(form_card, "Veicolo", color=MUTED, font=F_SM).pack(
            anchor="w", padx=16, pady=(6, 2)
        )
        vehicle_names = [f"{v[1]} ({v[2]})" for v in vehicles]
        combo_vehicle = ctk.CTkComboBox(
            form_card,
            values=vehicle_names,
            width=320,
            height=38,
            corner_radius=10,
            fg_color=CARD_ALT,
            border_color=BORDER,
            button_color=ACCENT,
            button_hover_color=ACCENT_HOVER,
        )
        combo_vehicle.pack(anchor="w", padx=16, pady=(0, 12))

        # Stelle di valutazione
        self._etichetta(form_card, "Valutazione", color=MUTED, font=F_SM).pack(
            anchor="w", padx=16, pady=(4, 2)
        )
        stars_row = ctk.CTkFrame(form_card, fg_color="transparent")
        stars_row.pack(anchor="w", padx=16, pady=(0, 12))

        self._rating_value = ctk.IntVar(value=5)
        star_buttons = []

        def _imposta_stelle(n: int) -> None:
            """
            Imposta il rating a n stelle e aggiorna i colori.

            Args:
                n: Numero di stelle (1-5).
            """
            self._rating_value.set(n)
            for idx, btn in enumerate(star_buttons):
                btn.configure(text_color=WARN if idx < n else FAINT)

        for i in range(1, 6):
            star_btn = self._etichetta(
                stars_row, "★", font=("Roboto", 26), color=WARN
            )
            star_btn.pack(side="left", padx=2)
            star_btn.bind("<Button-1>", lambda e, n=i: _imposta_stelle(n))
            star_buttons.append(star_btn)

        # Campo note
        self._etichetta(form_card, "Note", color=MUTED, font=F_SM).pack(anchor="w", padx=16)
        text_notes = ctk.CTkTextbox(
            form_card,
            width=480,
            height=90,
            corner_radius=10,
            fg_color=CARD_ALT,
            border_color=BORDER,
            border_width=1,
            text_color=TEXT,
        )
        text_notes.pack(anchor="w", padx=16, pady=(2, 12))

        msg_label = self._etichetta(form_card, "", font=F_SM)
        msg_label.pack(pady=2)

        def _invia_recensione() -> None:
            """Invia la segnalazione al database."""
            selected = combo_vehicle.get()
            plate = selected.split("(")[1].replace(")", "").strip()
            vehicle_id = self.db.ottieni_id_veicolo_per_targa(plate)

            if vehicle_id is None:
                return

            notes = text_notes.get("0.0", "end").strip()
            self.db.invia_recensione(
                self.uid or 0, vehicle_id, notes, self._rating_value.get()
            )
            msg_label.configure(text="✓  Segnalazione inviata!", text_color=OK)
            text_notes.delete("0.0", "end")
            _imposta_stelle(5)

        self._pulsante(
            form_card, "📨  Invia Segnalazione", _invia_recensione,
            fg_color=PURPLE, hover_color=PURPLE_HOVER, height=40, width=220,
        ).pack(anchor="w", padx=16, pady=(0, 18))

        # ── Storico recensioni ───────────────────────────────────────────
        reviews = self.db.ottieni_recensioni_utente(self.uid or 0)
        if reviews:
            self._etichetta(
                self.content_frame,
                "Ultime Segnalazioni",
                color=MUTED,
                font=F_HEAD,
            ).pack(anchor="w", padx=30, pady=(16, 8))

            for review in reviews:
                score, notes, review_date, model = review
                review_card = self._scheda(self.content_frame, hover=True)
                review_card.pack(fill="x", padx=30, pady=5)

                review_row = ctk.CTkFrame(
                    review_card, fg_color="transparent"
                )
                review_row.pack(fill="x", padx=16, pady=(12, 4 if notes else 12))

                # Stelle piene + vuote
                stars_str = "★" * score + "☆" * (5 - score)
                self._etichetta(
                    review_row, stars_str, color=WARN, font=("Roboto", 16)
                ).pack(side="left", padx=(0, 10))
                self._etichetta(review_row, model, font=("Roboto", 13, "bold")).pack(
                    side="left", padx=(0, 8)
                )
                self._etichetta(review_row, review_date, color=MUTED, font=F_SM).pack(
                    side="left"
                )

                if notes:
                    quote = ctk.CTkFrame(review_card, fg_color="transparent")
                    quote.pack(fill="x", padx=16, pady=(0, 12))
                    ctk.CTkFrame(
                        quote, width=3, height=1, fg_color=BORDER_LIGHT, corner_radius=2
                    ).pack(side="left", fill="y", padx=(0, 10))
                    self._etichetta(
                        quote,
                        notes,
                        color=MUTED,
                        font=F_SM,
                        wraplength=540,
                        justify="left",
                    ).pack(side="left", fill="x", expand=True)

    def pagina_segnalazioni_admin(self) -> None:
        """
        Mostra la pagina Segnalazioni (solo admin) con lo storico completo
        delle segnalazioni inviate da tutti i dipendenti: nome del
        dipendente, veicolo, valutazione, data e note.
        """
        self._pulisci_contenuto()
        self._intestazione(
            "📋",
            "Segnalazioni Dipendenti",
            "Storico delle segnalazioni inviate da tutti i dipendenti",
            color=PURPLE,
        )

        reports = self.db.ottieni_tutte_segnalazioni()

        if not reports:
            self._stato_vuoto(
                self.content_frame,
                "Nessuna segnalazione inviata dai dipendenti",
                icon="📋",
                color=MUTED,
            )
            return

        list_card = self._sezione(
            self.content_frame,
            f"Tutte le Segnalazioni ({len(reports)})",
            icon="📋",
            color=PURPLE,
        )

        for username, score, notes, review_date, model, plate in reports:
            entry = ctk.CTkFrame(list_card, fg_color=CARD_ALT, corner_radius=12)
            entry.pack(fill="x", padx=16, pady=5)

            header_row = ctk.CTkFrame(entry, fg_color="transparent")
            header_row.pack(fill="x", padx=14, pady=(10, 2))

            # Nome del dipendente che ha inviato la segnalazione
            self._etichetta(
                header_row, f"👤 {username}", font=("Roboto", 13, "bold")
            ).pack(side="left")
            self._etichetta(
                header_row, f"{model} ({plate})", color=MUTED, font=F_SM
            ).pack(side="left", padx=(10, 0))
            self._etichetta(
                header_row, review_date, color=FAINT, font=F_SM
            ).pack(side="right")

            stars_str = "★" * score + "☆" * (5 - score)
            self._etichetta(
                entry, stars_str, color=WARN, font=("Roboto", 15)
            ).pack(anchor="w", padx=14, pady=(0, 4 if notes else 10))

            if notes:
                quote = ctk.CTkFrame(entry, fg_color="transparent")
                quote.pack(fill="x", padx=14, pady=(0, 10))
                ctk.CTkFrame(
                    quote, width=3, height=1, fg_color=BORDER_LIGHT, corner_radius=2
                ).pack(side="left", fill="y", padx=(0, 10))
                self._etichetta(
                    quote,
                    notes,
                    color=MUTED,
                    font=F_SM,
                    wraplength=540,
                    justify="left",
                ).pack(side="left", fill="x", expand=True)
