"""
Modulo: paths.py
================
Percorsi condivisi dell'applicazione Smart Fleet IoT.

Centralizza il calcolo della cartella radice del progetto (PROJECT_ROOT) e
la memorizzazione dell'ultima cartella usata per importare una foto veicolo,
così ogni altro modulo (db_manager, widgets_mixin, pagine) può importarli
senza duplicare la logica.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os
import sys

# PROJECT_ROOT: cartella radice del progetto (un livello sopra UI/).
# Funziona indipendentemente da dove viene avviato lo script perché si basa
# sulla posizione di QUESTO file (che vive sempre direttamente dentro UI/).
PROJECT_ROOT: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Aggiunge la root al path di ricerca moduli Python (serve per poter fare
# `from database.Setup_db import ...` da qualunque modulo).
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# File di testo che ricorda l'ultima cartella usata con il tasto "Sfoglia"
# per importare la foto di un veicolo, così il dialogo riparte da lì la
# volta successiva invece di aprirsi sempre nella cartella di default.
LAST_DIR_FILE: str = os.path.join(PROJECT_ROOT, "database", "last_photo_dir.txt")


def ottieni_ultima_cartella_foto() -> str:
    """
    Legge da file l'ultima cartella usata per selezionare una foto veicolo.

    Returns:
        str: Percorso della cartella salvata, oppure PROJECT_ROOT se non
             è ancora stata salvata nessuna cartella (o non esiste più).
    """
    if os.path.exists(LAST_DIR_FILE):
        with open(LAST_DIR_FILE, "r", encoding="utf-8") as f:
            saved_dir = f.read().strip()
        if saved_dir and os.path.isdir(saved_dir):
            return saved_dir
    return PROJECT_ROOT


def imposta_ultima_cartella_foto(folder: str) -> None:
    """
    Salva su file la cartella indicata, per riproporla al prossimo utilizzo
    del tasto "Sfoglia".

    Args:
        folder: Percorso della cartella da ricordare.
    """
    os.makedirs(os.path.dirname(LAST_DIR_FILE), exist_ok=True)
    with open(LAST_DIR_FILE, "w", encoding="utf-8") as f:
        f.write(folder)