"""
Modulo: theme.py
================
Tema e palette colori dell'applicazione Smart Fleet IoT.

Definisce la palette scura "Fleet Navy" e i font condivisi dall'interfaccia.

Importato con `from theme import *` dai moduli che compongono la GUI
(widgets_mixin e le pagine in pages/), così tutti condividono la stessa
identità visiva senza dover ridefinire colori e font in ogni file.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import customtkinter as ctk

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

BG: str = "#0A0E1A"        # Sfondo principale (quasi nero-blu)
BG_ALT: str = "#10162A"    # Sfondo secondario (zebrature tabelle, letterbox foto)
SIDEBAR: str = "#0D1220"   # Sfondo sidebar / pannelli branding
CARD: str = "#131A2C"      # Sfondo card
CARD_ALT: str = "#1A2338"  # Superficie più chiara (input, hover, thumbnail)
BORDER: str = "#232C42"    # Bordi standard
BORDER_LIGHT: str = "#323C58"  # Bordi in evidenza / citazioni
TEXT: str = "#EEF2F8"      # Testo principale
MUTED: str = "#8A93AC"     # Testo secondario
FAINT: str = "#5B6480"     # Testo terziario / placeholder

ACCENT: str = "#4F7CFF"        # Accent principale (indaco/blu, coerente col logo)
ACCENT_HOVER: str = "#6D93FF"
OK: str = "#22C55E"            # Successo / disponibile
OK_HOVER: str = "#16A34A"
WARN: str = "#F5A524"          # Attenzione
WARN_HOVER: str = "#D97706"
ERR: str = "#F4415C"           # Errore / critico
ERR_HOVER: str = "#DC2626"
PURPLE: str = "#A78BFA"        # Viola (recensioni/report)
PURPLE_HOVER: str = "#7C3AED"

# Tipografia
F_TITLE: tuple[str, int, str] = ("Roboto", 23, "bold")
F_HEAD: tuple[str, int, str] = ("Roboto", 15, "bold")
F_BODY: tuple[str, int] = ("Roboto", 13)
F_SM: tuple[str, int] = ("Roboto", 11)
F_XS: tuple[str, int] = ("Roboto", 10)


def _hex_a_rgb(value: str) -> tuple[int, int, int]:
    """
    Converte un colore esadecimale (#RRGGBB) in una tupla RGB (0-255).

    Args:
        value: Colore in formato esadecimale (es. '#4F7CFF').

    Returns:
        tuple[int, int, int]: Componenti (R, G, B) da 0 a 255.
    """
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]