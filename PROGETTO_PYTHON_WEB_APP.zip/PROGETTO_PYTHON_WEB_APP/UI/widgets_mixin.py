"""
Modulo: widgets_mixin.py
========================
Helper GUI generici dell'applicazione Smart Fleet IoT.

Contiene WidgetsMixin: un Mixin (nessuno stato proprio, solo metodi) con
tutti i "mattoncini" grafici riutilizzati dalle pagine — bottoni, card,
icon-chip, badge, KPI, intestazioni — più il caricamento/ridimensionamento
delle immagini dei veicoli. La classe App compone questo Mixin insieme a
quelli delle pagine (vedi pages/) per formare l'app completa.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os
import re
import shutil
import uuid
from typing import Any, Callable, Optional

import customtkinter as ctk
from PIL import Image, ImageDraw

from paths import PROJECT_ROOT
from theme import (
    ACCENT,
    ACCENT_HOVER,
    BG_ALT,
    BORDER,
    CARD,
    CARD_ALT,
    F_BODY,
    F_HEAD,
    F_SM,
    F_TITLE,
    F_XS,
    FAINT,
    MUTED,
    TEXT,
    WARN,
    _hex_a_rgb,
)


class WidgetsMixin:
    """Helper GUI generici condivisi da tutte le pagine dell'app."""

    # ── Caricamento Immagini ─────────────────────────────────────────────

    def _carica_immagini(self) -> None:
        """
        Carica e ridimensiona tutte le immagini utilizzate nell'interfaccia.

        I percorsi sono risolti sempre a partire da PROJECT_ROOT tramite
        _adatta_immagine, indipendentemente dalla cartella da cui viene avviato lo
        script, e ridimensionati mantenendo le proporzioni originali
        (aspect-ratio). Le foto veicolo vivono in documents/, mentre gli
        asset di branding (logo, avatar utente, banner) vivono in
        UI/images/.
        """
        # Caricamento icone e immagini principali (branding, in UI/images/)
        self.iLogo = self._adatta_immagine("UI/images/logo.png", 170, 210)
        self.iLogoSm = self._adatta_immagine("UI/images/logo.png", 108, 108)
        self.iHero = (
            self._adatta_immagine("UI/images/banner.png", 900, 220)
            or self._adatta_immagine("UI/images/banner.jpg", 1200, 300)
        )
        self.iCar = self._adatta_immagine("documents/panda.png", 190, 124)
        self.iLogoStd = self._adatta_immagine("UI/images/Logo_Utente.png", 42, 42)
        self.iLogoAdmin = self._adatta_immagine("UI/images/Logo_Utente.png", 42, 42)

        # Avatar di default (cerchio blu, fallback se Logo_Utente non caricabile)
        avatar = Image.new("RGBA", (42, 42), (0, 0, 0, 0))
        ImageDraw.Draw(avatar).ellipse((0, 0, 41, 41), fill=_hex_a_rgb(ACCENT) + (255,))
        self.iAv = ctk.CTkImage(
            light_image=avatar, dark_image=avatar, size=(42, 42)
        )

    # ── Helper per immagini veicoli ──────────────────────────────────────

    def _adatta_immagine(
        self, rel_path: str, max_w: int, max_h: int
    ) -> Optional[ctk.CTkImage]:
        """
        Carica un'immagine veicolo dalla cartella documents/ con ridimensionamento.

        Args:
            rel_path: Percorso relativo (es. 'documents/panda.png').
            max_w: Larghezza massima.
            max_h: Altezza massima.

        Returns:
            Optional[ctk.CTkImage]: Immagine ridimensionata o None.
        """
        full = (
            os.path.join(PROJECT_ROOT, rel_path)
            if not os.path.isabs(rel_path)
            else rel_path
        )
        if not os.path.exists(full):
            return None
        img = Image.open(full).convert("RGBA")
        w, h = img.size
        ratio = min(max_w / w, max_h / h)
        img = img.resize(
            (int(w * ratio), int(h * ratio)), Image.Resampling.LANCZOS
        )
        return ctk.CTkImage(
            light_image=img, dark_image=img, size=(int(w * ratio), int(h * ratio))
        )

    def _miniatura_veicolo(
        self,
        parent: ctk.CTkFrame,
        photo_path: Optional[str],
        width: int,
        height: int,
        img_w: Optional[int] = None,
        img_h: Optional[int] = None,
        corner_radius: int = 10,
        fg_color: str = BG_ALT,
        fallback_icon: str = "🚗",
        fallback_color: str = MUTED,
        fallback_font_size: int = 20,
    ) -> ctk.CTkFrame:
        """
        Crea un riquadro con la foto del veicolo, centrata e ridimensionata,
        con fallback su un'icona generica se il veicolo non ha una foto
        associata. Centralizza il pattern "foto con letterbox + fallback"
        usato in più pagine (prenotazione, rilascio, gestione flotta),
        evitando di duplicarlo ad ogni chiamata.

        Args:
            parent: Widget genitore.
            photo_path: Percorso relativo della foto (es. 'documents/x.jpg'),
                oppure None/stringa vuota se il veicolo non ne ha una.
            width: Larghezza del riquadro.
            height: Altezza del riquadro.
            img_w: Larghezza massima dell'immagine (default: width).
            img_h: Altezza massima dell'immagine (default: height).
            corner_radius: Raggio degli angoli del riquadro.
            fg_color: Colore di sfondo del riquadro.
            fallback_icon: Emoji mostrata se la foto non è disponibile.
            fallback_color: Colore dell'icona/testo di fallback.
            fallback_font_size: Dimensione del font di fallback.

        Returns:
            ctk.CTkFrame: Il riquadro creato (da impacchettare dal chiamante).
        """
        wrap = ctk.CTkFrame(
            parent, width=width, height=height,
            fg_color=fg_color, corner_radius=corner_radius,
        )
        wrap.pack_propagate(False)
        vehicle_img = (
            self._adatta_immagine(photo_path, img_w or width, img_h or height)
            if photo_path else None
        )
        if vehicle_img:
            self._etichetta(wrap, "", image=vehicle_img).pack(expand=True)
        else:
            self._etichetta(
                wrap, fallback_icon, font=("Segoe UI Emoji", fallback_font_size),
                color=fallback_color,
            ).pack(expand=True)
        return wrap

    def _copia_foto(self, src_path: str, desired_name: Optional[str] = None) -> str:
        """
        Copia una foto selezionata nella cartella documents/ usando il nome del file
        selezionato tramite il pulsante Sfoglia, mantenendo l'estensione originale.

        Args:
            src_path: Percorso del file sorgente.
            desired_name: Nome file desiderato opzionale. Se non fornito, usa il nome
                del file selezionato nel desktop.

        Returns:
            str: Percorso relativo del file copiato (es. 'documents/abarth.jpg').
                 Stringa vuota se src_path non è valido.
        """
        if not src_path or not os.path.exists(src_path):
            return ""

        if desired_name:
            base = os.path.basename(desired_name)
            base = os.path.splitext(base)[0]
            base = re.sub(r"[^A-Za-z0-9_\-]", "_", base)
            if not base:
                base = f"vehicle_{uuid.uuid4().hex[:8]}"
            ext = os.path.splitext(src_path)[1].lower() or ".jpg"
            filename = f"{base}{ext}"
        else:
            filename = os.path.basename(src_path)
            if not os.path.splitext(filename)[1]:
                filename = f"{filename}.jpg"

        documents_dir = os.path.join(PROJECT_ROOT, "documents")
        os.makedirs(documents_dir, exist_ok=True)
        dest = os.path.join(documents_dir, filename)

        if os.path.exists(dest):
            name_only, extension = os.path.splitext(filename)
            i = 1
            while True:
                new_name = f"{name_only}_{i}{extension}"
                new_dest = os.path.join(documents_dir, new_name)
                if not os.path.exists(new_dest):
                    dest = new_dest
                    break
                i += 1

        shutil.copy2(src_path, dest)
        return f"documents/{os.path.basename(dest)}"

    # ── Helper GUI generici ──────────────────────────────────────────────

    def _al_ridimensionamento_finestra(self, event: Any) -> None:
        """
        Adatta dinamicamente la scala di font e widget in base alla
        larghezza corrente della finestra (interfaccia reattiva).

        Args:
            event: Evento <Configure> generato da Tkinter al resize.
        """
        if event.widget is not self:
            return
        scale = self._SCALE_BREAKPOINTS[0][1]
        for min_width, factor in self._SCALE_BREAKPOINTS:
            if event.width >= min_width:
                scale = factor
        if scale != self._current_scale:
            self._current_scale = scale
            ctk.set_widget_scaling(scale)

    def _pulisci_tutto(self) -> None:
        """Rimuove tutti i widget dalla finestra principale."""
        for w in self.winfo_children():
            w.destroy()

    def _pulisci_contenuto(self) -> None:
        """Rimuove tutti i widget dal frame dei contenuti."""
        for w in self.content_frame.winfo_children():
            w.destroy()

    def _tinta(self, hex_color: str, alpha: float = 0.16, base: str = CARD) -> str:
        """
        Calcola una variante "tenue" (tinta) di un colore, miscelandolo con
        uno sfondo di riferimento. Usata per badge, pillole e riquadri icona,
        così ogni colore semantico (successo, errore, ecc.) ottiene
        automaticamente uno sfondo coordinato senza dover definire a mano
        decine di costanti colore.

        Args:
            hex_color: Colore sorgente in formato '#RRGGBB'.
            alpha: Intensità della miscela (0 = solo sfondo, 1 = colore puro).
            base: Colore di sfondo di riferimento.

        Returns:
            str: Colore risultante in formato '#RRGGBB'.
        """
        c, b = _hex_a_rgb(hex_color), _hex_a_rgb(base)
        mixed = tuple(round(b[i] + (c[i] - b[i]) * alpha) for i in range(3))
        return "#%02X%02X%02X" % mixed

    def _etichetta(
        self,
        parent: ctk.CTkFrame,
        text: str = "",
        font: tuple = F_BODY,
        color: str = TEXT,
        **kwargs: Any,
    ) -> ctk.CTkLabel:
        """
        Crea un widget CTkLabel con parametri predefiniti.

        Args:
            parent: Widget genitore.
            text: Testo dell'etichetta.
            font: Font (famiglia, dimensione, [stile]).
            color: Colore del testo.
            **kwargs: Attributi aggiuntivi per CTkLabel.

        Returns:
            ctk.CTkLabel: L'etichetta creata.
        """
        return ctk.CTkLabel(parent, text=text, font=font, text_color=color, **kwargs)

    def _pulsante(
        self,
        parent: ctk.CTkFrame,
        text: str,
        command: Callable[[], None],
        fg_color: str = ACCENT,
        hover_color: str = ACCENT_HOVER,
        height: int = 40,
        width: int = 200,
        **kwargs: Any,
    ) -> ctk.CTkButton:
        """
        Crea un pulsante CTkButton con parametri predefiniti.

        Args:
            parent: Widget genitore.
            text: Testo del pulsante.
            command: Funzione da eseguire al click.
            fg_color: Colore di sfondo.
            hover_color: Colore al passaggio del mouse.
            height: Altezza in pixel.
            width: Larghezza in pixel.
            **kwargs: Attributi aggiuntivi.

        Returns:
            ctk.CTkButton: Il pulsante creato.
        """
        font = kwargs.pop("font", F_BODY)
        return ctk.CTkButton(
            parent,
            text=text,
            command=command,
            fg_color=fg_color,
            hover_color=hover_color,
            height=height,
            width=width,
            corner_radius=10,
            font=font,
            anchor="center",
            **kwargs,
        )

    def _campo(
        self,
        parent: ctk.CTkFrame,
        placeholder: str = "",
        show: str = "",
        width: int = 300,
        **kwargs: Any,
    ) -> ctk.CTkEntry:
        """
        Crea un campo di input CTkEntry con parametri predefiniti, incluso un
        effetto di evidenziazione del bordo quando il campo riceve il focus.

        Args:
            parent: Widget genitore.
            placeholder: Testo segnaposto.
            show: Carattere da mostrare (es. '•' per password).
            width: Larghezza in pixel.
            **kwargs: Attributi aggiuntivi.

        Returns:
            ctk.CTkEntry: Il campo input creato.
        """
        entry = ctk.CTkEntry(
            parent,
            placeholder_text=placeholder,
            show=show,
            width=width,
            height=40,
            corner_radius=10,
            fg_color=CARD_ALT,
            border_width=1,
            border_color=BORDER,
            text_color=TEXT,
            placeholder_text_color=FAINT,
            **kwargs,
        )
        entry.bind("<FocusIn>", lambda e: entry.configure(border_color=ACCENT))
        entry.bind("<FocusOut>", lambda e: entry.configure(border_color=BORDER))
        return entry

    def _campo_con_icona(
        self,
        parent: ctk.CTkFrame,
        icon: str,
        placeholder: str = "",
        show: str = "",
        width: int = 300,
    ) -> tuple[ctk.CTkFrame, ctk.CTkEntry]:
        """
        Crea un campo di input con una piccola icona a sinistra, in stile
        form di autenticazione moderno. Il riquadro si illumina quando il
        campo interno riceve il focus.

        Args:
            parent: Widget genitore.
            icon: Emoji/icona da mostrare a sinistra del campo.
            placeholder: Testo segnaposto.
            show: Carattere da mostrare (es. '•' per password).
            width: Larghezza totale del campo, in pixel.

        Returns:
            tuple: (contenitore da impacchettare, campo CTkEntry per get()/bind()).
        """
        wrap = ctk.CTkFrame(
            parent, fg_color=CARD_ALT, corner_radius=10,
            border_width=1, border_color=BORDER, height=44, width=width,
        )
        wrap.pack_propagate(False)
        self._etichetta(wrap, icon, font=("Roboto", 15), color=MUTED).pack(
            side="left", padx=(14, 6)
        )
        entry = ctk.CTkEntry(
            wrap, placeholder_text=placeholder, show=show,
            fg_color="transparent", border_width=0, height=38,
            text_color=TEXT, placeholder_text_color=FAINT,
        )
        entry.pack(side="left", fill="both", expand=True, padx=(0, 12))
        entry.bind("<FocusIn>", lambda e: wrap.configure(border_color=ACCENT))
        entry.bind("<FocusOut>", lambda e: wrap.configure(border_color=BORDER))
        return wrap, entry

    def _separatore(self, parent: ctk.CTkFrame) -> None:
        """
        Crea una linea separatrice orizzontale.

        Args:
            parent: Widget genitore.
        """
        ctk.CTkFrame(parent, height=1, fg_color=BORDER).pack(
            fill="x", padx=16, pady=6
        )

    def _scheda(
        self, parent: ctk.CTkFrame, hover: bool = False, **kwargs: Any
    ) -> ctk.CTkFrame:
        """
        Crea un frame con stile "card" (sfondo scuro, bordi arrotondati).

        Args:
            parent: Widget genitore.
            hover: Se True, il bordo e lo sfondo si illuminano leggermente
                al passaggio del mouse (effetto interattivo per card
                selezionabili/cliccabili).
            **kwargs: Attributi aggiuntivi.

        Returns:
            ctk.CTkFrame: La card creata.
        """
        card = ctk.CTkFrame(
            parent,
            fg_color=CARD,
            corner_radius=16,
            border_width=1,
            border_color=BORDER,
            **kwargs,
        )
        if hover:
            card.bind("<Enter>", lambda e: card.configure(border_color=ACCENT, fg_color=CARD_ALT))
            card.bind("<Leave>", lambda e: card.configure(border_color=BORDER, fg_color=CARD))
        return card

    def _riquadro_icona(
        self,
        parent: ctk.CTkFrame,
        icon: str,
        color: str = ACCENT,
        size: int = 42,
        radius: int = 12,
        font_size: Optional[int] = None,
    ) -> ctk.CTkLabel:
        """
        Crea un piccolo riquadro colorato con un'icona centrata (icon-chip),
        in stile dashboard moderna: sfondo tenue coordinato al colore
        semantico, con l'icona/emoji in evidenza al centro.

        Args:
            parent: Widget genitore.
            icon: Emoji/icona da mostrare al centro del riquadro.
            color: Colore semantico del riquadro.
            size: Dimensione (larghezza/altezza) del riquadro in pixel.
            radius: Raggio degli angoli arrotondati.
            font_size: Dimensione del font dell'icona (default proporzionale a size).

        Returns:
            ctk.CTkLabel: Il riquadro-icona creato (da impacchettare dal chiamante).
        """
        chip = ctk.CTkLabel(
            parent,
            text=icon,
            width=size,
            height=size,
            corner_radius=radius,
            fg_color=self._tinta(color, 0.18),
            font=("Segoe UI Emoji", font_size or max(12, int(size * 0.42))),
            text_color=color,
            anchor="center",
            justify="center",
        )
        return chip

    def _pillola(
        self, parent: ctk.CTkFrame, text: str, color: str = MUTED, font: tuple = F_XS
    ) -> ctk.CTkFrame:
        """
        Crea un badge "a pillola" (sfondo tenue, bordo colorato, angoli molto
        arrotondati) per mostrare stati, ruoli o etichette in modo compatto.

        Args:
            parent: Widget genitore.
            text: Testo del badge (tipicamente in maiuscolo).
            color: Colore semantico del badge.
            font: Font del testo.

        Returns:
            ctk.CTkFrame: Il badge creato (da impacchettare dal chiamante).
        """
        pill = ctk.CTkFrame(
            parent, fg_color=self._tinta(color, 0.20), corner_radius=8,
            border_width=1, border_color=self._tinta(color, 0.5),
        )
        self._etichetta(pill, text, font=font, color=color).pack(padx=10, pady=3)
        return pill

    def _badge_targa(self, parent: ctk.CTkFrame, plate: str) -> ctk.CTkFrame:
        """
        Crea un badge che riproduce l'aspetto di una targa automobilistica
        (fondo chiaro, striscia blu laterale, testo monospace), per rendere
        più riconoscibili a colpo d'occhio i dati dei veicoli nell'interfaccia.

        Args:
            parent: Widget genitore.
            plate: Testo della targa.

        Returns:
            ctk.CTkFrame: Il badge targa creato (da impacchettare dal chiamante).
        """
        wrap = ctk.CTkFrame(
            parent, fg_color="#EEF1F6", corner_radius=6,
            border_width=1, border_color="#B7C1D1",
        )
        strip = ctk.CTkFrame(wrap, width=8, height=1, fg_color="#1652A8", corner_radius=0)
        strip.pack(side="left", fill="y")
        self._etichetta(
            wrap, plate, font=("Consolas", 12, "bold"), color="#10141C"
        ).pack(side="left", padx=(8, 10), pady=3)
        return wrap

    def _kpi(
        self,
        parent: ctk.CTkFrame,
        icon: str,
        value: str,
        label: str,
        color: str = ACCENT,
    ) -> None:
        """
        Crea un box KPI (Key Performance Indicator) nella dashboard, in stile
        "stat card" allineata a sinistra con icon-chip colorato in testa.

        Args:
            parent: Widget genitore (row KPI).
            icon: Emoji o testo dell'icona.
            value: Valore numerico da mostrare.
            label: Etichetta descrittiva.
            color: Colore del valore.
        """
        frame = self._scheda(parent, hover=True)
        frame.pack(side="left", fill="both", expand=True, padx=6, pady=4)
        self._riquadro_icona(frame, icon, color, size=38, radius=11, font_size=16).pack(
            anchor="w", padx=16, pady=(16, 8)
        )
        self._etichetta(frame, str(value), font=("Roboto", 26, "bold"), color=color).pack(
            anchor="w", padx=16
        )
        self._etichetta(frame, label, font=F_SM, color=MUTED).pack(
            anchor="w", padx=16, pady=(2, 16)
        )

    def _riga_kpi(
        self,
        parent: ctk.CTkFrame,
        configs: list[tuple[str, Any, str, str]],
        **pack_kwargs: Any,
    ) -> None:
        """
        Crea una riga orizzontale di box KPI, evitando di ripetere in ogni
        pagina la creazione del frame contenitore e del ciclo di stampa.

        Args:
            parent: Widget genitore.
            configs: Lista di tuple (icona, valore, etichetta, colore).
            **pack_kwargs: Argomenti extra per il pack della riga
                (default: fill='x', padx=24, pady=4).
        """
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(**{"fill": "x", "padx": 24, "pady": 4, **pack_kwargs})
        for icon, value, label, color in configs:
            self._kpi(row, icon, value, label, color)

    def _intestazione_scheda(
        self, card: ctk.CTkFrame, title: str, icon: Optional[str] = None, color: str = ACCENT
    ) -> None:
        """
        Aggiunge titolo (con eventuale icon-chip) e separatore in testa a
        una card già creata.

        Args:
            card: Card su cui inserire l'intestazione.
            title: Testo del titolo della sezione.
            icon: Emoji/icona opzionale mostrata in un riquadro colorato.
            color: Colore semantico dell'icona e dell'accento della sezione.
        """
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(14, 4))
        if icon:
            self._riquadro_icona(row, icon, color, size=30, radius=9, font_size=14).pack(
                side="left", padx=(0, 10)
            )
        self._etichetta(row, title, font=F_HEAD).pack(side="left")
        self._separatore(card)

    def _sezione(
        self,
        parent: ctk.CTkFrame,
        title: str,
        icon: Optional[str] = None,
        color: str = ACCENT,
        pady: Any = 8,
        **kwargs: Any,
    ) -> ctk.CTkFrame:
        """
        Crea una card "di sezione" (icon-chip + titolo + separatore) già
        impacchettata in orizzontale: accorpa in una riga il pattern
        ripetuto in tutte le pagine (card + pack + intestazione).

        Args:
            parent: Widget genitore.
            title: Titolo della sezione.
            icon: Emoji/icona opzionale per l'intestazione.
            color: Colore semantico della sezione.
            pady: Padding verticale del pack (int o tupla).
            **kwargs: Argomenti extra per _scheda (es. hover=True).

        Returns:
            ctk.CTkFrame: La card pronta, con intestazione già inserita.
        """
        card = self._scheda(parent, **kwargs)
        card.pack(fill="x", padx=30, pady=pady)
        self._intestazione_scheda(card, title, icon, color)
        return card

    def _stato_vuoto(
        self,
        parent: ctk.CTkFrame,
        text: str,
        icon: str = "ℹ️",
        color: str = WARN,
        pady: int = 20,
        text_pady: int = 28,
    ) -> None:
        """
        Mostra un messaggio di "stato vuoto" (es. nessun elemento disponibile).

        Args:
            parent: Widget genitore.
            text: Messaggio da mostrare.
            icon: Emoji/icona mostrata sopra il messaggio.
            color: Colore del testo e dell'icona.
            pady: Padding verticale della card.
            text_pady: Padding verticale del contenuto dentro la card.
        """
        card = self._scheda(parent)
        card.pack(fill="x", padx=30, pady=pady)
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(pady=text_pady)
        self._riquadro_icona(inner, icon, color, size=42, radius=13, font_size=18).pack(
            pady=(0, 10)
        )
        self._etichetta(inner, text, color=color, font=F_HEAD).pack()

    def _intestazione(self, icon: str, title: str, subtitle: str = "", color: str = ACCENT) -> None:
        """
        Crea l'intestazione standard di una pagina, con icon-chip colorato,
        titolo e sottotitolo.

        Args:
            icon: Emoji icona.
            title: Titolo della pagina.
            subtitle: Sottotitolo opzionale.
            color: Colore semantico associato alla pagina.
        """
        wrap = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        wrap.pack(fill="x", padx=30, pady=(26, 6))

        row = ctk.CTkFrame(wrap, fg_color="transparent")
        row.pack(fill="x")
        self._riquadro_icona(row, icon, color, size=46, radius=14, font_size=20).pack(
            side="left", padx=(0, 14)
        )
        text_col = ctk.CTkFrame(row, fg_color="transparent")
        text_col.pack(side="left", fill="x", expand=True)
        self._etichetta(text_col, title, font=F_TITLE).pack(anchor="w")
        if subtitle:
            self._etichetta(text_col, subtitle, color=MUTED, font=F_SM).pack(
                anchor="w", pady=(2, 0)
            )
        self._separatore(self.content_frame)
