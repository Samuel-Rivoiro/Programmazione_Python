#!/usr/bin/env bash
# ==============================================================
#  Smart Fleet IoT - Avvio (GNU/Linux e macOS)
#  ITS Academy ICT Piemonte - Product by Samuel Rivoiro
#
#  Se manca, installa Python in automatico (tramite il gestore
#  pacchetti della distribuzione), poi crea/ricrea il virtual
#  environment, installa le dipendenze da requirements.txt e avvia
#  l'app Flet.
#
#  Uso:
#      chmod +x avvia_app.sh   (solo la prima volta)
#      ./avvia_app.sh
# ==============================================================
set -e
cd "$(dirname "$0")"

echo "========================================"
echo "  Smart Fleet IoT - App Flet"
echo "  ITS Academy ICT Piemonte"
echo "  Product by Samuel Rivoiro"
echo "========================================"
echo

# 1. Verifica presenza di python3 (+ modulo venv) e, se manca, prova a
#    installarlo da solo con il gestore pacchetti della distribuzione
#    (richiede sudo: puo' chiedere la password). Copre le distribuzioni
#    piu' comuni; se nessuna viene riconosciuta, chiede di installarlo
#    manualmente.
install_python() {
    echo "[1/3] python3 non trovato: provo a installarlo automaticamente..."
    if command -v apt >/dev/null 2>&1; then
        sudo apt update && sudo apt install -y python3 python3-venv python3-pip
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y python3 python3-pip
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y python3 python3-pip
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -Sy --noconfirm python python-pip
    elif command -v zypper >/dev/null 2>&1; then
        sudo zypper install -y python3 python3-pip
    elif command -v brew >/dev/null 2>&1; then
        brew install python3
    else
        echo "[ERRORE] Gestore pacchetti non riconosciuto: nessuna installazione automatica possibile."
        return 1
    fi
}

if ! command -v python3 >/dev/null 2>&1; then
    install_python || true
fi
if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERRORE] Impossibile trovare o installare python3 automaticamente."
    echo "Installalo manualmente (versione 3.9 o superiore) e rilancia questo script."
    exit 1
fi
echo "[1/3] python3 pronto."

if ! python3 -c "import venv, ensurepip" >/dev/null 2>&1; then
    echo "[1/3] Modulo 'venv' o 'ensurepip' mancante: provo a installarlo..."
    if command -v apt >/dev/null 2>&1; then
        PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        sudo apt update && sudo apt install -y "python${PY_VER}-venv" || sudo apt install -y python3-venv
    fi
fi
if ! python3 -c "import venv, ensurepip" >/dev/null 2>&1; then
    echo "[ERRORE] Modulo 'venv' (con ensurepip) non disponibile."
    PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    echo "Installalo manualmente con: sudo apt install python${PY_VER}-venv"
    exit 1
fi

# 2. Crea/ricrea il virtual environment se manca o non funziona su questa
#    macchina. Un venv creato su un ALTRO computer (es. copiato insieme
#    alla cartella del progetto) puo' contenere percorsi assoluti
#    dell'altra macchina e non funzionare qui: in quel caso lo ricreiamo
#    da zero automaticamente, senza bisogno di cancellarlo a mano.
VENV_OK=0
if [ -x ".venv/bin/python" ] && [ -f ".venv/bin/activate" ] && .venv/bin/python --version >/dev/null 2>&1; then
    VENV_OK=1
fi

if [ "$VENV_OK" = "1" ]; then
    source .venv/bin/activate
    echo "[2/3] Venv pronto. Verifico dipendenze..."
    python -m pip install -r requirements.txt >/dev/null
else
    if [ -d ".venv" ]; then
        echo "[2/3] Virtual environment non compatibile con questa macchina (creato altrove). Ricreazione..."
        rm -rf .venv
    else
        echo "[2/3] Virtual environment non trovato. Creazione..."
    fi
    # Su filesystem Windows montati in WSL (/mnt/c/...) ensurepip fallisce
    # per problemi di permessi: creiamo il venv senza pip e poi lo installiamo
    # manualmente scaricando get-pip.py dall'ufficiale pypa.io.
    if python3 -m venv .venv 2>/dev/null; then
        true
    else
        python3 -m venv .venv --without-pip
    fi
    source .venv/bin/activate
    # Installa pip se non disponibile (caso --without-pip)
    if ! python -m pip --version >/dev/null 2>&1; then
        echo "[2/3] Installazione pip via get-pip.py..."
        curl -sS https://bootstrap.pypa.io/get-pip.py | python
    fi
    python -m pip install --upgrade pip >/dev/null
    python -m pip install -r requirements.txt
fi
echo "[2/3] Venv pronto."

# 3. Avvio app
#    - Su una postazione Linux con ambiente grafico (Wi-Fi/desktop) si apre
#      una finestra come su Windows.
#    - Su un server/ambiente Linux senza schermo (es. connessione SSH),
#      Flet rileva automaticamente l'assenza di display e passa in
#      modalita' web: apri nel browser l'indirizzo che compare nel
#      terminale (di solito http://localhost:8000).
echo "[3/3] Avvio Smart Fleet IoT..."
python main.py