"""
Modulo: main.py
================
Punto di ingresso dell'app Smart Fleet IoT (Flet).

Inizializza il database, crea lo stato applicativo condiviso
(state.SmartFleetApp) e mostra la schermata di accesso.

Per avviarla in locale durante lo sviluppo (anteprima desktop/web):
    pip install -r requirements.txt
    flet run main.py

Per compilarla come vera app installabile (va eseguito sulla TUA
macchina, non in questo ambiente sandbox — vedi README.md):
    flet build apk      # Android
    flet build ipa       # iOS (richiede macOS + Xcode)

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

from database.Setup_db import DB_NAME, inizializza_database
from database.db_manager import DatabaseManager
from state import SmartFleetApp
from theme import BG


def main(page: ft.Page) -> None:
    """Configura la pagina Flet principale e mostra la schermata di accesso."""
    page.title = "Smart Fleet IoT"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG
    page.padding = 0

    # Finestra desktop dimensionata come uno smartphone: l'interfaccia è
    # pensata per schermo verticale stretto (drawer di navigazione, card
    # impilate), quindi la apriamo con le proporzioni di un telefono
    # invece che a schermo intero. Non ha effetto in modalità web (dove
    # la pagina segue le dimensioni della finestra del browser).
    if not page.web:
        page.window.width = 450
        page.window.height = 844
        page.window.resizable = False
        page.update()
        page.run_task(page.window.center)

    # Inizializzazione database: idempotente, crea tabelle e dati di
    # default solo se mancanti.
    inizializza_database()
    db = DatabaseManager(DB_NAME)

    app = SmartFleetApp(page, db)

    from views.auth_view import mostra_accesso

    mostra_accesso(app)


if __name__ == "__main__":
    ft.run(main, assets_dir="assets")