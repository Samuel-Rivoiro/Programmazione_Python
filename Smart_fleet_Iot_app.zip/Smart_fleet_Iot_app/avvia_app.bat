@echo off
REM ==============================================================
REM  Smart Fleet IoT - Avvio (Windows)
REM  ITS Academy ICT Piemonte - Product by Samuel Rivoiro
REM
REM  Se manca, installa Python in automatico (via winget, o in
REM  alternativa scaricando ed eseguendo in silenzio l'installer
REM  ufficiale da python.org), poi crea/ricrea il virtual
REM  environment, installa le dipendenze da requirements.txt e
REM  avvia l'app Flet.
REM
REM  Va eseguito con un doppio click, oppure da terminale con:
REM      ./avvia_app.bat
REM
REM  Richiede una connessione a internet la prima volta (per
REM  scaricare Python, se manca, e le dipendenze del progetto).
REM ==============================================================
title Smart Fleet IoT - Avvio
cd /d "%~dp0"
echo ========================================
echo   Smart Fleet IoT - App Flet
echo   ITS Academy ICT Piemonte
echo   Product by Samuel Rivoiro
echo ========================================
echo.

REM 1. Trova un interprete Python funzionante su QUESTO PC; se non lo
REM    trova, prova a installarlo da solo (prima con winget, poi con
REM    l'installer ufficiale scaricato da python.org), senza bisogno di
REM    permessi da amministratore.
call :find_python
if not defined PY (
    echo [1/3] Python non trovato: provo a installarlo con winget...
    call :try_winget
    call :find_python
)
if not defined PY (
    echo [1/3] winget non disponibile o installazione non riuscita: scarico l'installer ufficiale da python.org...
    call :try_direct_download
    call :find_python
)
if not defined PY (
    echo.
    echo [ERRORE] Impossibile trovare o installare Python automaticamente
    echo ^(verifica di avere una connessione a internet^).
    echo Puoi installarlo manualmente da https://www.python.org/downloads/
    echo ^(versione 3.9 o superiore^), selezionando "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [1/3] Python pronto.

REM 2. Crea/ricrea il virtual environment se manca o non funziona su
REM    questo PC. Un venv creato su un ALTRO computer (es. copiato insieme
REM    alla cartella del progetto) contiene percorsi assoluti dell'altra
REM    macchina e non funziona qui: in quel caso lo ricreiamo da zero
REM    automaticamente, senza bisogno di cancellarlo a mano.
set "VENV_OK=0"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>nul && set "VENV_OK=1"
)

if "%VENV_OK%"=="1" (
    call .venv\Scripts\activate.bat
    echo [2/3] Venv pronto. Verifico dipendenze...
    python -m pip install -r requirements.txt >nul
) else (
    if exist ".venv" (
        echo [2/3] Virtual environment non compatibile con questo PC ^(creato su un'altra macchina^). Ricreazione...
        rmdir /s /q ".venv"
    ) else (
        echo [2/3] Virtual environment non trovato. Creazione...
    )
    %PY% -m venv .venv
    call .venv\Scripts\activate.bat
    python -m pip install --upgrade pip >nul
    pip install -r requirements.txt
)
echo [2/3] Venv pronto.

REM 3. Avvio app (si apre una finestra desktop con l'interfaccia Flet)
echo [3/3] Avvio Smart Fleet IoT...
python main.py

if errorlevel 1 (
    echo.
    echo [ERRORE] L'applicazione si e' chiusa con errori.
    pause
)
exit /b 0

REM ==============================================================
REM  Sottoprocedure
REM ==============================================================

:find_python
REM Cerca un interprete Python funzionante e lo salva in %PY%.
REM "where python" puo' "trovare" python.exe anche quando in realta'
REM punta solo all'alias del Microsoft Store (Python non installato
REM davvero): per questo verifichiamo che risponda per bene a --version,
REM provando anche il launcher "py" e, come ultima spiaggia, il percorso
REM tipico di un'installazione per-utente appena fatta in questa stessa
REM sessione (che "where"/PATH non vedrebbero ancora).
set "PY="
python --version >nul 2>nul
if not errorlevel 1 (
    set "PY=python"
    goto :eof
)
py -3 --version >nul 2>nul
if not errorlevel 1 (
    set "PY=py -3"
    goto :eof
)
for /d %%D in ("%LocalAppData%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" set PY="%%D\python.exe"
)
goto :eof

:try_winget
where winget >nul 2>nul
if errorlevel 1 (
    goto :eof
)
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
goto :eof

:try_direct_download
set "PYINSTALLER=%TEMP%\python-installer.exe"
if exist "%PYINSTALLER%" del "%PYINSTALLER%" >nul 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile '%PYINSTALLER%' -UseBasicParsing } catch { exit 1 }"
if not exist "%PYINSTALLER%" (
    echo       [ERRORE] Download di Python fallito ^(verifica la connessione a internet^).
    goto :eof
)
echo       Installazione silenziosa di Python in corso, attendere...
"%PYINSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
del "%PYINSTALLER%" >nul 2>nul
goto :eof