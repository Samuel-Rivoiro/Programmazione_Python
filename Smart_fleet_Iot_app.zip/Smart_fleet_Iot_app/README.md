# Smart Fleet IoT — app mobile (Flet)

App **Flet** che dallo stesso codice Python genera un'app installabile per
**Android**, **iOS**, oltre che web e desktop. Gestisce utenti, veicoli,
prenotazioni e recensioni/segnalazioni su un database SQLite locale.

Multipiattaforma: lo stesso codice gira senza modifiche su **Windows** e
**GNU/Linux** (oltre che macOS); solo Python 3.9+ è richiesto.

## Avvio rapido su un'altra macchina

Copia (o clona) l'intera cartella `Smart_fleet_Iot_app/` sulla macchina di
destinazione — contiene già tutto il necessario (`requirements.txt`,
codice sorgente, dati di default).

⚠️ **Non copiare la cartella `.venv/`** insieme al resto: un virtual
environment Python contiene percorsi assoluti legati alla macchina su cui
è stato creato e su un PC diverso non funziona (errori tipo `"pip" non è
riconosciuto` o `Python was not found`). Va ricreato su ogni macchina —
gli script `avvia_app.bat`/`avvia_app.sh` lo fanno da soli in automatico
al primo avvio (e se rilevano un `.venv` copiato da un'altra macchina lo
ricreano da zero senza bisogno di cancellarlo a mano).

Non serve installare Python a mano: se manca, gli script lo installano da
soli (serve solo una connessione a internet la prima volta).

**Windows:** doppio click su `avvia_app.bat` (oppure da terminale:
`avvia_app.bat`). Se Python non è installato lo scarica e lo installa in
automatico (prima prova con `winget`, se non disponibile scarica ed esegue
in silenzio l'installer ufficiale da python.org) — nessun permesso da
amministratore richiesto, non serve spuntare manualmente "Add to PATH".
Poi crea il virtual environment e installa le dipendenze da
`requirements.txt`. Alle esecuzioni successive parte direttamente.

Se l'installazione automatica non riesce (es. nessuna connessione a
internet, o un antivirus blocca lo script), lo script lo segnala e puoi
installare Python manualmente da
<https://www.python.org/downloads/> (versione 3.9 o superiore),
selezionando "Add python.exe to PATH" — se non lo fai, dopo digitare
`python` in un terminale può aprirsi la pagina del Microsoft Store invece
di eseguire Python: in tal caso reinstallalo spuntando quell'opzione,
oppure disattiva l'alias in Impostazioni di Windows → App → Impostazioni
avanzate app → Alias di esecuzione delle app.

**GNU/Linux (e macOS):**

```bash
chmod +x avvia_app.sh   # solo la prima volta
./avvia_app.sh
```

Se `python3` manca, lo script prova a installarlo da solo con il gestore
pacchetti della distribuzione (apt/dnf/yum/pacman/zypper/Homebrew),
chiedendo la password di amministratore (`sudo`) quando necessario. Poi
crea il virtual environment e installa le dipendenze, come su Windows.

**Ambiente Linux senza schermo (server/SSH):** Flet rileva in automatico
l'assenza di un display e passa da solo in modalità web, servendo l'app su
`http://localhost:8000` (indirizzo stampato nel terminale) invece di aprire
una finestra — nessuna configurazione manuale richiesta.

## Schermate

- Accesso / Registrazione
- Dashboard amministratore (KPI, telemetria, alert)
- Prenotazione veicolo
- Rilascio veicolo (admin vede tutti i dipendenti, utente vede le proprie)
- Recensioni/Segnalazioni (utente) + Segnalazioni Dipendenti (admin, con nome)
- Gestione Flotta (admin), con selezione foto tramite FilePicker nativo
- Reportistica PDF (admin), generata con ReportLab

**Nota sulla versione di Flet:** il codice è allineato all'API di Flet
0.86 (quella che si installa oggi con `pip install flet`), che rispetto
alle versioni precedenti ha rinominato diverse cose (es. `ft.app()` →
`ft.run()`, `ft.alignment.center` → `ft.Alignment.CENTER`,
`ft.ElevatedButton` → `ft.Button`, FilePicker ora asincrono, dialoghi
aperti con `page.show_dialog()`). Se in futuro installi una versione di
Flet ancora più recente e vedi di nuovo errori tipo `AttributeError:
module 'flet...' has no attribute ...`, è lo stesso tipo di problema:
controlla il cambiamento sul sito ufficiale flet.dev/docs.

## 1. Provarla in locale (anteprima desktop/web)

```bash
cd Smart_fleet_Iot_app
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
flet run main.py
```

Questo apre una finestra di anteprima (o il browser, con `flet run --web
main.py`) dove puoi navigare l'app esattamente come farebbe un telefono.
È il modo più veloce per trovare e correggere eventuali problemi prima di
generare l'app vera.

### 1bis. Anteprima live sul tuo iPhone reale (senza Mac, senza build)

Il modo più rapido per vederla su un iPhone vero, direttamente dal tuo PC
Windows, senza Xcode e senza account Apple Developer:

1. Installa l'app **"Flet"** dall'App Store sul tuo iPhone
   (<https://apps.apple.com/app/flet/id1624979699>).
2. PC e iPhone devono essere sulla **stessa rete Wi-Fi**.
3. Dal PC, dentro `Smart_fleet_Iot_app/`:
   ```bash
   flet run --ios main.py
   ```
4. Nel terminale compare un **QR code**. Apri l'app **Fotocamera**
   sull'iPhone, inquadralo e tocca il link che appare: si apre dentro
   l'app Flet.
5. Da quel momento hai il **hot reload**: ogni volta che salvi una
   modifica a `main.py` (o agli altri file, con `flet run --ios -r
   main.py` per guardare ricorsivamente tutta la cartella), l'app sul
   telefono si aggiorna da sola.

Questo NON è ancora un'app installata in modo indipendente (serve l'app
"Flet" aperta e il PC raggiungibile in rete): per quello serve il passo
successivo.

Credenziali di test:

| Username | Password | Ruolo    |
|----------|----------|----------|
| admin    | admin123 | admin    |
| utente1  | user123  | standard |
| utente2  | user456  | standard |

## 2. Generare l'app Android (.apk / .aab)

Va eseguito sulla tua macchina (Windows/Mac/Linux), non in questo ambiente:

```bash
cd Smart_fleet_Iot_app
flet build apk
```

La prima build scarica in automatico Flutter e l'SDK Android (serve una
connessione internet buona e un po' di spazio disco, anche diversi GB).
Il file `.apk` risultante lo trovi in `build/apk/` e puoi installarlo
direttamente su un telefono Android (o distribuirlo/pubblicarlo).

## 3. Generare l'app iOS installabile (.ipa)

Questo è il passo per avere una vera app installata sul telefono, che
funziona anche senza il PC acceso e senza l'app "Flet" — ma **richiede un
Mac con Xcode 15+** (vincolo di Apple, non di Flet: da Windows/Linux non è
possibile in nessun modo) e un **abbonamento Apple Developer Program**
(99$/anno) per firmare il pacchetto e installarlo su un dispositivo reale.

Sul Mac:

```bash
cd Smart_fleet_Iot_app
flet build ipa
```

Poi, per installare il file `.ipa` generato sul tuo iPhone senza passare
dall'App Store: apri **Apple Configurator** (gratis, dal Mac App Store),
collega l'iPhone via USB, trascina il file `.ipa` sul dispositivo. La
prima volta dovrai anche "autorizzare" lo sviluppatore sul telefono, in
Impostazioni → Generali → Gestione VPN e dispositivo.

Se non hai un Mac a disposizione, le alternative sono: chiederne uno in
prestito, usare un Mac di scuola/lavoro, oppure affittare un Mac nel
cloud (es. MacStadium, MacinCloud) solo per questo passaggio.

## Note tecniche per chi continua il lavoro

- **Database**: alla prima esecuzione viene creato/popolato automaticamente
  con i dati di default. Il file `fleet_iot.db` viene salvato nella
  cartella dati scrivibile dell'app; in sviluppo (`flet run`) finisce
  semplicemente dentro `Smart_fleet_Iot_app/database/`.
- **Foto veicoli di default**: sono in `Smart_fleet_Iot_app/assets/documents/`,
  incluse nel pacchetto dell'app (`assets_dir="assets"` in `main.py`).
- **Foto aggiunte da mobile** (form "Aggiungi Veicolo"): l'app non ha una
  cartella "documents/" scrivibile e prevedibile, quindi la foto scelta
  con il selettore file viene codificata in base64 e salvata direttamente
  nella colonna `photo_path` del database (prefisso `b64:`). Funziona, ma
  rende il database più pesante nel tempo: se il progetto cresce, conviene
  sostituirlo con un vero storage file su disco o su un backend remoto.
- **FilePicker**: su build native (`flet build apk/ipa`) `file.path`
  dovrebbe restituire un percorso leggibile direttamente; su target *web*
  potrebbe non essere disponibile. Se vedi "Impossibile leggere il file
  scelto" durante i test, è il primo punto da controllare.
- **ReportLab** (generazione PDF): libreria Python pura, dovrebbe
  funzionare anche nella build mobile, ma è un altro punto da verificare
  con un test reale su dispositivo.
- Struttura del codice: `database/` (schema e accesso dati), una vista
  per file in `views/`, `theme.py` (palette colori), helper condivisi in
  `widgets.py`.

## Pattern di interfaccia

- Navigazione tramite **drawer** (menu ☰ in alto a sinistra), pattern
  standard su mobile.
- Tabelle larghe (Gestione Flotta, Reportistica) come liste di card
  verticali, più leggibili su schermo stretto.
- L'eliminazione di un veicolo chiede conferma con un dialogo, più sicuro
  su touchscreen dove i tap accidentali sono più frequenti.
