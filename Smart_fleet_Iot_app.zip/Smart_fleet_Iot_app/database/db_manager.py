"""
Modulo: database/db_manager.py
=================================
Accesso al database per l'applicazione Smart Fleet IoT (app mobile Flet).

Incapsula tutte le query SQLite usate dalle viste dell'interfaccia
(pattern Repository), separando la logica di accesso ai dati dalla GUI.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import sqlite3
from datetime import datetime
from typing import Any, Optional


class DatabaseManager:
    """
    Gestore centralizzato per tutte le operazioni di database.

    Attributes:
        db_path (str): Percorso assoluto del file database.
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path

    def _connetti(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    # ── Autenticazione ───────────────────────────────────────────────────

    def accedi(self, username: str, password: str) -> Optional[tuple[int, str, str]]:
        """Verifica le credenziali di un utente. Ritorna (id, role, username) o None."""
        conn = self._connetti()
        row = conn.execute(
            "SELECT id, role, username FROM utenti WHERE username=? AND password=?",
            (username, password),
        ).fetchone()
        conn.close()
        return row

    def registra(self, username: str, password: str) -> None:
        """Registra un nuovo utente con ruolo 'standard'."""
        conn = self._connetti()
        conn.execute(
            "INSERT INTO utenti(username, password, role) VALUES(?, ?, 'standard')",
            (username, password),
        )
        conn.commit()
        conn.close()

    # ── Dashboard / KPI ──────────────────────────────────────────────────

    def ottieni_dati_kpi(self) -> dict[str, int]:
        """Recupera i dati KPI per la dashboard amministratore."""
        conn = self._connetti()
        data = {
            "total_vehicles": conn.execute("SELECT COUNT(*) FROM veicoli").fetchone()[0],
            "available_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli WHERE status='disponibile'"
            ).fetchone()[0],
            "active_reservations": conn.execute(
                "SELECT COUNT(*) FROM prenotazioni WHERE status='attiva'"
            ).fetchone()[0],
            "total_reviews": conn.execute("SELECT COUNT(*) FROM recensioni").fetchone()[0],
            "total_users": conn.execute("SELECT COUNT(*) FROM utenti").fetchone()[0],
        }
        conn.close()
        return data

    def ottieni_dati_telemetria(self, limit: int = 6) -> list[tuple]:
        """Recupera i dati di telemetria dei veicoli."""
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, fuel_level, brake_wear, status FROM veicoli LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_avvisi_carburante(self, threshold: float = 30.0) -> list[tuple]:
        """Recupera i veicoli con carburante sotto soglia."""
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, fuel_level FROM veicoli WHERE fuel_level < ?",
            (threshold,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_avvisi_freni(self, threshold: float = 30.0) -> list[tuple]:
        """Recupera i veicoli con freni sotto soglia."""
        conn = self._connetti()
        data = conn.execute(
            "SELECT model, plate, brake_wear FROM veicoli WHERE brake_wear < ?",
            (threshold,),
        ).fetchall()
        conn.close()
        return data

    # ── Prenotazioni ─────────────────────────────────────────────────────

    def ottieni_veicoli_disponibili(self) -> list[tuple]:
        """Recupera tutti i veicoli disponibili per la prenotazione."""
        conn = self._connetti()
        data = conn.execute(
            "SELECT id, model, plate, fuel_level, brake_wear, photo_path "
            "FROM veicoli WHERE status='disponibile'"
        ).fetchall()
        conn.close()
        return data

    def prenota_veicolo(
        self, user_id: int, vehicle_id: int, start_date: str, end_date: str
    ) -> None:
        """Prenota un veicolo per un utente."""
        conn = self._connetti()
        conn.execute("UPDATE veicoli SET status='occupato' WHERE id=?", (vehicle_id,))
        conn.execute(
            "INSERT INTO prenotazioni(user_id, vehicle_id, start_date, end_date, status) "
            "VALUES(?, ?, ?, ?, 'attiva')",
            (user_id, vehicle_id, start_date, end_date),
        )
        conn.commit()
        conn.close()

    # ── Rilascio ─────────────────────────────────────────────────────────

    def ottieni_prenotazioni_attive(self, user_id: int) -> list[tuple]:
        """Recupera le prenotazioni attive di un utente."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT r.id, v.model, v.plate, r.start_date, r.end_date, v.photo_path
               FROM prenotazioni r
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.user_id = ? AND r.status = 'attiva'""",
            (user_id,),
        ).fetchall()
        conn.close()
        return data

    def ottieni_storico_prenotazioni(self, user_id: int, limit: int = 8) -> list[tuple]:
        """Recupera lo storico delle prenotazioni concluse di un utente."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT v.model, v.plate, r.start_date, r.end_date, r.status, v.photo_path
               FROM prenotazioni r
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.user_id = ? AND r.status = 'conclusa'
               ORDER BY r.id DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutte_prenotazioni_attive(self) -> list[tuple]:
        """Recupera le prenotazioni attive di TUTTI gli utenti (vista amministratore)."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT r.id, u.username, v.model, v.plate, r.start_date,
                      r.end_date, v.photo_path
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.status = 'attiva'
               ORDER BY r.id DESC""",
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutto_storico_prenotazioni(self, limit: int = 15) -> list[tuple]:
        """Recupera lo storico delle prenotazioni concluse di TUTTI gli utenti (vista admin)."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT u.username, v.model, v.plate, r.start_date, r.end_date,
                      r.status, v.photo_path
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               WHERE r.status = 'conclusa'
               ORDER BY r.id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    def rilascia_veicolo(self, reservation_id: int) -> None:
        """Rilascia un veicolo chiudendo la prenotazione."""
        conn = self._connetti()
        vehicle_id = conn.execute(
            "SELECT vehicle_id FROM prenotazioni WHERE id=?", (reservation_id,)
        ).fetchone()[0]
        conn.execute(
            "UPDATE prenotazioni SET status='conclusa' WHERE id=?", (reservation_id,)
        )
        conn.execute("UPDATE veicoli SET status='disponibile' WHERE id=?", (vehicle_id,))
        conn.commit()
        conn.close()

    # ── Recensioni / Segnalazioni ────────────────────────────────────────

    def ottieni_elenco_veicoli(self) -> list[tuple]:
        """Recupera la lista completa dei veicoli (per dropdown recensioni)."""
        conn = self._connetti()
        data = conn.execute("SELECT id, model, plate FROM veicoli").fetchall()
        conn.close()
        return data

    def ottieni_id_veicolo_per_targa(self, plate: str) -> Optional[int]:
        """Recupera l'ID di un veicolo dalla targa."""
        conn = self._connetti()
        row = conn.execute("SELECT id FROM veicoli WHERE plate=?", (plate,)).fetchone()
        conn.close()
        return row[0] if row else None

    def invia_recensione(
        self, user_id: int, vehicle_id: int, notes: str, score: int
    ) -> None:
        """Invia una recensione/segnalazione per un veicolo."""
        conn = self._connetti()
        conn.execute(
            "INSERT INTO recensioni(user_id, vehicle_id, notes, score, review_date) "
            "VALUES(?, ?, ?, ?, ?)",
            (user_id, vehicle_id, notes, score, datetime.now().strftime("%Y-%m-%d")),
        )
        conn.commit()
        conn.close()

    def ottieni_recensioni_utente(self, user_id: int, limit: int = 5) -> list[tuple]:
        """Recupera le ultime recensioni di un utente."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT rev.score, rev.notes, rev.review_date, v.model
               FROM recensioni rev
               JOIN veicoli v ON rev.vehicle_id = v.id
               WHERE rev.user_id = ?
               ORDER BY rev.id DESC LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        conn.close()
        return data

    def ottieni_tutte_segnalazioni(self, limit: int = 200) -> list[tuple]:
        """Recupera tutte le segnalazioni inviate dai dipendenti (vista amministratore)."""
        conn = self._connetti()
        data = conn.execute(
            """SELECT u.username, rev.score, rev.notes, rev.review_date,
                      v.model, v.plate
               FROM recensioni rev
               JOIN utenti u ON rev.user_id = u.id
               JOIN veicoli v ON rev.vehicle_id = v.id
               ORDER BY rev.id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        conn.close()
        return data

    # ── Gestione Flotta ──────────────────────────────────────────────────

    def ottieni_tutti_veicoli(self) -> list[tuple]:
        """Recupera tutti i veicoli con dati completi."""
        conn = self._connetti()
        data = conn.execute(
            "SELECT id, model, plate, status, fuel_level, brake_wear, "
            "last_maintenance, photo_path FROM veicoli"
        ).fetchall()
        conn.close()
        return data

    def aggiungi_veicolo(
        self, model: str, plate: str, fuel: float, brake: float, photo_path: str
    ) -> None:
        """Aggiunge un nuovo veicolo alla flotta."""
        conn = self._connetti()
        conn.execute(
            "INSERT INTO veicoli(model, plate, status, fuel_level, brake_wear, "
            "last_maintenance, photo_path) "
            "VALUES(?, ?, 'disponibile', ?, ?, ?, ?)",
            (model, plate, fuel, brake, datetime.now().strftime("%d-%m-%Y"), photo_path),
        )
        conn.commit()
        conn.close()

    def elimina_veicolo(self, vehicle_id: int) -> None:
        """Elimina un veicolo, le sue prenotazioni e le sue recensioni associate."""
        conn = self._connetti()
        conn.execute("DELETE FROM veicoli WHERE id=?", (vehicle_id,))
        conn.execute("DELETE FROM prenotazioni WHERE vehicle_id=?", (vehicle_id,))
        conn.execute("DELETE FROM recensioni WHERE vehicle_id=?", (vehicle_id,))
        conn.commit()
        conn.close()

    def ottieni_veicolo_per_id(self, vehicle_id: int) -> Optional[tuple]:
        """Recupera i dati di un singolo veicolo."""
        conn = self._connetti()
        row = conn.execute(
            "SELECT model, plate, fuel_level, brake_wear FROM veicoli WHERE id=?",
            (vehicle_id,),
        ).fetchone()
        conn.close()
        return row

    def aggiorna_livello_carburante(self, vehicle_id: int, level: float) -> None:
        """Aggiorna il livello carburante di un veicolo."""
        conn = self._connetti()
        conn.execute("UPDATE veicoli SET fuel_level=? WHERE id=?", (level, vehicle_id))
        conn.commit()
        conn.close()

    def aggiorna_manutenzione_freni(
        self, vehicle_id: int, level: float, notes: str
    ) -> None:
        """Registra un intervento di manutenzione freni."""
        conn = self._connetti()
        conn.execute(
            "UPDATE veicoli SET brake_wear=?, last_maintenance=?, maint_notes=? WHERE id=?",
            (level, datetime.now().strftime("%d-%m-%Y"), notes, vehicle_id),
        )
        conn.commit()
        conn.close()

    # ── Report ───────────────────────────────────────────────────────────

    def ottieni_dati_report(self) -> dict[str, Any]:
        """Recupera tutti i dati necessari per il report PDF."""
        conn = self._connetti()

        stats = {
            "total_vehicles": conn.execute("SELECT COUNT(*) FROM veicoli").fetchone()[0],
            "available_vehicles": conn.execute(
                "SELECT COUNT(*) FROM veicoli WHERE status='disponibile'"
            ).fetchone()[0],
            "total_reservations": conn.execute(
                "SELECT COUNT(*) FROM prenotazioni"
            ).fetchone()[0],
            "total_reviews": conn.execute("SELECT COUNT(*) FROM recensioni").fetchone()[0],
            "total_users": conn.execute("SELECT COUNT(*) FROM utenti").fetchone()[0],
        }

        vehicles = conn.execute(
            "SELECT model, plate, status, fuel_level, brake_wear, last_maintenance "
            "FROM veicoli"
        ).fetchall()

        reservations = conn.execute(
            """SELECT u.username, v.model, r.start_date, r.end_date, r.status
               FROM prenotazioni r
               JOIN utenti u ON r.user_id = u.id
               JOIN veicoli v ON r.vehicle_id = v.id
               ORDER BY r.id DESC LIMIT 15"""
        ).fetchall()

        conn.close()
        return {"stats": stats, "vehicles": vehicles, "reservations": reservations}

    # ── Profilo Utente ────────────────────────────────────────────────────

    def ottieni_dati_utente(self, user_id: int) -> Optional[tuple[str, str, str, str, str]]:
        """Recupera tutti i dati di un utente (username, role, email, phone, password)."""
        # Connessione al database locale SQLite
        conn = self._connetti()
        # Esegue la SELECT per estrarre le info dell'utente tramite ID
        row = conn.execute(
            "SELECT username, role, email, phone, password FROM utenti WHERE id=?",
            (user_id,),
        ).fetchone()
        # Chiude la connessione al database
        conn.close()
        # Ritorna la riga contenente i dati
        return row

    def aggiorna_dati_utente(
        self, user_id: int, username: str, email: str, phone: str, password: str
    ) -> None:
        """Aggiorna i dati del profilo utente inclusa l'username."""
        # Connessione al database locale SQLite
        conn = self._connetti()
        # Esegue l'UPDATE per salvare i dati modificati dell'utente nel DB
        conn.execute(
            "UPDATE utenti SET username=?, email=?, phone=?, password=? WHERE id=?",
            (username, email, phone, password, user_id),
        )
        # Esegue il commit per salvare le modifiche in modo permanente
        conn.commit()
        # Chiude la connessione al database
        conn.close()
