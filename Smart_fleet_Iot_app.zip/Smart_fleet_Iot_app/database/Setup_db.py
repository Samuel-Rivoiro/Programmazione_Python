"""
Modulo: database/Setup_db.py
==============================
Responsabile della creazione e inizializzazione del database SQLite3
per il sistema Smart Fleet IoT (app mobile Flet).

Il percorso del file database punta a una cartella scrivibile sul
dispositivo quando l'app è impacchettata con `flet build` (Android/iOS),
invece che dentro i sorgenti.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

import os
import sqlite3

# ── Percorso del database ─────────────────────────────────────────────────
#
# In esecuzione "di sviluppo" (flet run) usiamo semplicemente la cartella
# di questo file. Una volta impacchettata come app mobile (flet build apk/
# ipa), i sorgenti possono risiedere in un percorso di sola lettura: in tal
# caso usiamo la cartella dati scrivibile fornita da Flet
# (flet.app_data_path), disponibile solo a runtime nell'app installata.
try:
    import flet as ft

    DB_DIR: str = ft.app_data_path or os.path.dirname(os.path.abspath(__file__))
except Exception:
    DB_DIR = os.path.dirname(os.path.abspath(__file__))

os.makedirs(DB_DIR, exist_ok=True)
DB_NAME: str = os.path.join(DB_DIR, "fleet_iot.db")

# ── Dati predefiniti ────────────────────────────────────────────────────

DEFAULT_USERS: list[tuple[str, str, str]] = [
    ("admin", "admin123", "admin"),
    ("utente1", "user123", "standard"),
    ("utente2", "user456", "standard"),
]
"""Lista di utenti di default: (username, password, role)."""

DEFAULT_VEHICLES: list[tuple[str, str, str, float, float, str, str]] = [
    ("Fiat Panda", "CM340MX", "disponibile", 98.0, 95.0, "01-06-2026", "documents/panda.png"),
    ("Fiat 500X", "FA123XY", "disponibile", 85.0, 28.0, "15-03-2026", "documents/500x.jpeg"),
    ("Jeep Renegade", "GH789AB", "disponibile", 72.0, 60.0, "20-05-2026", "documents/jeep_ranegade.jpg"),
    ("Toyota Yaris", "TY456CD", "disponibile", 100.0, 90.0, "10-06-2026", "documents/toyota_yaris.jpg"),
    ("Volkswagen Golf", "VW321EF", "disponibile", 91.0, 75.0, "05-05-2026", "documents/golf.jpg"),
    ("Ford Focus", "FD012GH", "disponibile", 65.0, 85.0, "22-04-2026", "documents/ford_focus.jpg"),
    ("BMW Serie 1", "BM345IJ", "disponibile", 88.0, 95.0, "30-06-2026", "documents/bmw_serie1.jpg"),
    ("Renault Clio", "RN678KL", "disponibile", 55.0, 40.0, "01-04-2026", "documents/clio.jpg"),
    ("Peugeot 208", "PG901MN", "disponibile", 79.0, 70.0, "15-06-2026", "documents/peugeot208.jpg"),
    ("Mercedes Classe A", "MB234OP", "disponibile", 93.0, 88.0, "25-06-2026", "documents/mercedes_classe_a.jpg"),
]
"""Lista di veicoli di default: (modello, targa, stato, carburante%, freni%, ultima_manutenzione, photo_path)."""


# ── Funzioni di setup ────────────────────────────────────────────────────────


def crea_tabelle(cursor: sqlite3.Cursor) -> None:
    """
    Crea tutte le tabelle del database se non esistono già.

    Tabelle create:
        - utenti: utenti del sistema (username, password, role).
        - veicoli: veicoli della flotta (modello, targa, stato, telemetria, foto).
        - prenotazioni: prenotazioni dei veicoli da parte degli utenti.
        - recensioni: recensioni e segnalazioni sui veicoli.

    Args:
        cursor: Cursore attivo su connessione SQLite.
    """
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS utenti (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role     TEXT NOT NULL CHECK(role IN ('standard', 'admin')),
            email    TEXT DEFAULT '',
            phone    TEXT DEFAULT ''
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS veicoli (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            model             TEXT    NOT NULL,
            plate             TEXT    UNIQUE NOT NULL,
            status            TEXT    NOT NULL DEFAULT 'disponibile',
            fuel_level        REAL    DEFAULT 100.0,
            brake_wear        REAL    DEFAULT 100.0,
            last_maintenance  TEXT    DEFAULT 'N/D',
            maint_notes       TEXT    DEFAULT '',
            photo_path        TEXT    DEFAULT ''
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS prenotazioni (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER,
            vehicle_id INTEGER,
            start_date TEXT,
            end_date   TEXT,
            status     TEXT DEFAULT 'attiva',
            FOREIGN KEY(user_id)    REFERENCES utenti(id),
            FOREIGN KEY(vehicle_id) REFERENCES veicoli(id)
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS recensioni (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            vehicle_id  INTEGER,
            notes       TEXT,
            score       INTEGER,
            review_date TEXT,
            FOREIGN KEY(user_id)    REFERENCES utenti(id),
            FOREIGN KEY(vehicle_id) REFERENCES veicoli(id)
        )
        """
    )


def migra_colonne(cursor: sqlite3.Cursor) -> None:
    """
    Aggiunge colonne mancanti alle tabelle veicoli e utenti in modo sicuro,
    senza errori se le colonne esistono già (migrazione incrementale).

    Args:
        cursor: Cursore attivo su connessione SQLite.
    """
    columns_veicoli = [
        ("last_maintenance", "TEXT DEFAULT 'N/D'"),
        ("maint_notes", "TEXT DEFAULT ''"),
        ("photo_path", "TEXT DEFAULT ''"),
    ]

    for col_name, col_definition in columns_veicoli:
        try:
            cursor.execute(
                f"ALTER TABLE veicoli ADD COLUMN {col_name} {col_definition}"
            )
        except sqlite3.OperationalError:
            pass

    columns_utenti = [
        ("email", "TEXT DEFAULT ''"),
        ("phone", "TEXT DEFAULT ''"),
    ]

    for col_name, col_definition in columns_utenti:
        try:
            cursor.execute(
                f"ALTER TABLE utenti ADD COLUMN {col_name} {col_definition}"
            )
        except sqlite3.OperationalError:
            pass


def inserisci_utenti_default(cursor: sqlite3.Cursor) -> None:
    """
    Inserisce gli utenti predefiniti nel database, ignorando i duplicati.

    Args:
        cursor: Cursore attivo su connessione SQLite.
    """
    for username, password, role in DEFAULT_USERS:
        try:
            cursor.execute(
                "INSERT INTO utenti (username, password, role) VALUES (?, ?, ?)",
                (username, password, role),
            )
            cursor.connection.commit()
        except sqlite3.IntegrityError:
            pass


def inserisci_veicoli_default(cursor: sqlite3.Cursor) -> None:
    """
    Inserisce i veicoli predefiniti nel database, ignorando i duplicati.

    Args:
        cursor: Cursore attivo su connessione SQLite.
    """
    for model, plate, status, fuel, brake, maint, photo_path in DEFAULT_VEHICLES:
        try:
            cursor.execute(
                "INSERT INTO veicoli "
                "(model, plate, status, fuel_level, brake_wear, last_maintenance, photo_path) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (model, plate, status, fuel, brake, maint, photo_path),
            )
            cursor.connection.commit()
        except sqlite3.IntegrityError:
            pass


def inizializza_database() -> None:
    """
    Inizializza completamente il database Smart Fleet IoT.

    Crea/aggiorna lo schema, esegue le migrazioni incrementali e popola
    i dati di default. È idempotente: può essere eseguita più volte
    senza causare errori.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    crea_tabelle(cursor)
    migra_colonne(cursor)
    conn.commit()

    inserisci_utenti_default(cursor)
    inserisci_veicoli_default(cursor)

    conn.close()

    print(f"[DB] Setup completato. Database: {DB_NAME}")


if __name__ == "__main__":
    inizializza_database()
