"""
Modulo: widgets.py
==================
Helper grafici generici dell'app mobile Smart Fleet IoT (Flet).

Insieme di funzioni che costruiscono i "mattoncini" di interfaccia
riutilizzati in tutte le schermate (card, badge, pillole, KPI,
intestazioni, stato vuoto, stelle), per non ripetere lo stesso codice
di stile in ogni vista.

Nota di compatibilità: per ridurre il rischio di incompatibilità tra
versioni diverse di Flet (alcune API, es. `ft.icons`/`ft.Icons`, sono
cambiate nel tempo), qui non viene usato NESSUN'icona a font: tutte le
icone sono semplici emoji di testo. Colori sempre come stringhe
esadecimali.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import base64
import os
from typing import Any, Callable, Optional

import flet as ft

from theme import (
    ACCENT,
    BG_ALT,
    BORDER,
    BORDER_LIGHT,
    CARD,
    CARD_ALT,
    ERR,
    FAINT,
    MUTED,
    TEXT,
    WARN,
    tinta,
)

# Prefisso usato per riconoscere una foto salvata come base64 in-database
# (foto scattate/scelte dall'utente su mobile tramite FilePicker), rispetto
# a un percorso relativo alla cartella assets/ (foto di default bundlate
# con l'app, es. 'documents/panda.png').
B64_PREFIX = "b64:"


# ── Helper colore/immagine ─────────────────────────────────────────────

def codifica_immagine_base64(src_path: str) -> str:
    """
    Legge un file immagine dal disco e lo codifica come stringa 'b64:...'
    pronta per essere salvata nella colonna photo_path del database.

    Usato quando l'utente sceglie una foto tramite FilePicker su mobile:
    a differenza del desktop, l'app mobile non ha una cartella "documents/"
    scrivibile e prevedibile in cui copiare il file, quindi la foto viene
    incorporata direttamente nel database come dato codificato.

    Args:
        src_path: Percorso del file scelto (fornito da FilePicker).

    Returns:
        str: Stringa 'b64:<dati_base64>', oppure stringa vuota in caso
             di errore di lettura.
    """
    try:
        with open(src_path, "rb") as f:
            raw = f.read()
        return B64_PREFIX + base64.b64encode(raw).decode("ascii")
    except OSError:
        return ""


def _immagine_veicolo(
    photo_path: Optional[str], width: int, height: int, border_radius: int = 10
) -> Optional[ft.Image]:
    """Costruisce un ft.Image da un photo_path (asset relativo o base64)."""
    if not photo_path:
        return None
    if photo_path.startswith(B64_PREFIX):
        return ft.Image(
            src=photo_path[len(B64_PREFIX):],
            width=width,
            height=height,
            fit=ft.BoxFit.COVER,
            border_radius=border_radius,
        )
    src_path = photo_path
    if photo_path and not (photo_path.startswith("http://") or photo_path.startswith("https://") or photo_path.startswith("/") or photo_path.startswith("data:")):
        src_path = f"/{photo_path}"
    return ft.Image(
        src=src_path,
        width=width,
        height=height,
        fit=ft.BoxFit.COVER,
        border_radius=border_radius,
    )


def miniatura_veicolo(
    photo_path: Optional[str],
    width: int = 60,
    height: int = 60,
    border_radius: int = 12,
    fallback_icon: str = "🚗",
    fallback_color: str = MUTED,
) -> ft.Container:
    """
    Riquadro con la foto del veicolo (o icona generica di fallback se il
    veicolo non ha ancora una foto associata).
    """
    img = _immagine_veicolo(photo_path, width, height, border_radius)
    content = img or ft.Text(fallback_icon, size=min(width, height) * 0.4, color=fallback_color)
    return ft.Container(
        content=content,
        width=width,
        height=height,
        bgcolor=BG_ALT,
        border_radius=border_radius,
        alignment=ft.Alignment.CENTER,
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
    )


# ── Testo, bottoni, campi ──────────────────────────────────────────────

def etichetta(
    text: str,
    size: int = 14,
    weight: Optional[str] = None,
    color: str = TEXT,
    italic: bool = False,
    **kwargs: Any,
) -> ft.Text:
    """Crea un ft.Text con stile predefinito coerente col resto dell'app."""
    return ft.Text(text, size=size, weight=weight, color=color, italic=italic, **kwargs)


def pulsante(
    text: str,
    on_click: Callable[..., None],
    bgcolor: str = ACCENT,
    color: str = "#090D1A", # Colore scuro di contrasto (Navy) per sfondi fluo
    width: Optional[int] = None,
    height: int = 46,
    **kwargs: Any,
) -> ft.ElevatedButton:
    """Crea un pulsante pieno con stile predefinito (testo scuro per alta leggibilità su sfondi fluo)."""
    return ft.ElevatedButton(
        content=ft.Text(text, color=color, weight=ft.FontWeight.BOLD, size=14),
        on_click=on_click,
        width=width,
        height=height,
        style=ft.ButtonStyle(
            bgcolor=bgcolor,
            shape=ft.RoundedRectangleBorder(radius=10),
        ),
        **kwargs,
    )


def pulsante_outline(
    text: str, on_click: Callable[..., None], color: str = MUTED, width: Optional[int] = None
) -> ft.OutlinedButton:
    """Crea un pulsante con solo bordo (azioni secondarie)."""
    return ft.OutlinedButton(
        content=text,
        on_click=on_click,
        width=width,
        style=ft.ButtonStyle(
            color=color,
            side=ft.BorderSide(1, BORDER),
            shape=ft.RoundedRectangleBorder(radius=10),
        ),
    )


def campo(
    label: str = "",
    password: bool = False,
    width: Optional[int] = None,
    value: str = "",
    **kwargs: Any,
) -> ft.TextField:
    """Crea un campo di testo con stile predefinito."""
    return ft.TextField(
        label=label,
        password=password,
        can_reveal_password=password,
        value=value,
        width=width,
        border_color=BORDER,
        focused_border_color=ACCENT,
        border_radius=10,
        color=TEXT,
        label_style=ft.TextStyle(color=MUTED),
        **kwargs,
    )


def separatore() -> ft.Divider:
    """Linea separatrice orizzontale."""
    return ft.Divider(color=BORDER, height=1, thickness=1)


# ── Card, badge, pillole ────────────────────────────────────────────────

def scheda(content: ft.Control, padding: int = 16, **kwargs: Any) -> ft.Container:
    """Container con stile 'card' (sfondo scuro, bordo arrotondato)."""
    return ft.Container(
        content=content,
        bgcolor=CARD,
        border=ft.Border.all(1, BORDER),
        border_radius=16,
        padding=padding,
        **kwargs,
    )


def riquadro_icona(icon: str, color: str = ACCENT, size: int = 42, font_size: Optional[int] = None) -> ft.Container:
    """Riquadro colorato con un'emoji al centro (icon-chip)."""
    return ft.Container(
        content=ft.Text(icon, size=font_size or max(12, int(size * 0.42))),
        width=size,
        height=size,
        bgcolor=tinta(color, 0.18),
        border_radius=int(size * 0.3),
        alignment=ft.Alignment.CENTER,
    )


def pillola(text: str, color: str = MUTED, size: int = 10) -> ft.Container:
    """Badge 'a pillola' per stati/etichette compatte."""
    return ft.Container(
        content=ft.Text(text, size=size, color=color, weight=ft.FontWeight.BOLD),
        bgcolor=tinta(color, 0.20),
        border=ft.Border.all(1, tinta(color, 0.5)),
        border_radius=8,
        padding=ft.Padding.symmetric(vertical=3, horizontal=10),
    )


def badge_targa(plate: str) -> ft.Container:
    """Badge in stile targa automobilistica."""
    return ft.Container(
        content=ft.Row(
            [
                ft.Container(width=6, bgcolor="#1652A8", border_radius=ft.BorderRadius.only(top_left=6, bottom_left=6)),
                ft.Text(plate, size=12, weight=ft.FontWeight.BOLD, color="#10141C", font_family="Consolas"),
            ],
            spacing=8,
            tight=True,
        ),
        bgcolor="#EEF1F6",
        border=ft.Border.all(1, "#B7C1D1"),
        border_radius=6,
        padding=ft.Padding.only(left=0, right=10, top=3, bottom=3),
    )


def stato_vuoto(text: str, icon: str = "ℹ️", color: str = WARN) -> ft.Container:
    """Messaggio di 'stato vuoto' (nessun elemento disponibile)."""
    return scheda(
        ft.Column(
            [
                riquadro_icona(icon, color, size=46, font_size=20),
                etichetta(text, size=15, weight=ft.FontWeight.BOLD, color=color),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=10,
        ),
        alignment=ft.Alignment.CENTER,
        padding=28,
    )


def intestazione(icon: str, title: str, subtitle: str = "", color: str = ACCENT) -> ft.Column:
    """Intestazione standard di una schermata (icon-chip + titolo + sottotitolo)."""
    return ft.Column(
        [
            ft.Row(
                [
                    riquadro_icona(icon, color, size=44, font_size=19),
                    ft.Column(
                        [
                            etichetta(title, size=20, weight=ft.FontWeight.BOLD),
                            etichetta(subtitle, size=12, color=MUTED) if subtitle else ft.Container(),
                        ],
                        spacing=2,
                        tight=True,
                    ),
                ],
                spacing=12,
            ),
            separatore(),
        ],
        spacing=10,
    )


# ── KPI ──────────────────────────────────────────────────────────────────

def kpi_card(icon: str, value: Any, label: str, color: str = ACCENT) -> ft.Container:
    """Box KPI singolo (icona, valore grande, etichetta)."""
    return scheda(
        ft.Column(
            [
                riquadro_icona(icon, color, size=34, font_size=15),
                etichetta(str(value), size=22, weight=ft.FontWeight.BOLD, color=color),
                etichetta(label, size=11, color=MUTED),
            ],
            spacing=6,
        ),
        padding=14,
    )


def riga_kpi(configs: list[tuple[str, Any, str, str]]) -> ft.ResponsiveRow:
    """
    Riga responsive di box KPI: 2 colonne su schermi stretti (mobile),
    più colonne su schermi larghi (tablet/desktop/web).

    Args:
        configs: lista di tuple (icona, valore, etichetta, colore).
    """
    cards = []
    for icon, value, label, color in configs:
        cards.append(
            ft.Container(kpi_card(icon, value, label, color), col={"xs": 6, "sm": 4, "md": 3})
        )
    return ft.ResponsiveRow(cards, spacing=10, run_spacing=10)


# ── Stelle (valutazione) ──────────────────────────────────────────────────

def stelle_sola_lettura(score: int, max_stars: int = 5, size: int = 16) -> ft.Row:
    """Riga di stelle piene/vuote non interattiva (visualizzazione punteggio)."""
    stars = []
    for i in range(1, max_stars + 1):
        stars.append(
            ft.Text("★" if i <= score else "☆", size=size, color=WARN if i <= score else FAINT)
        )
    return ft.Row(stars, spacing=2, tight=True)


def stelle_selezionabili(
    initial: int = 5, max_stars: int = 5, size: int = 30, on_change: Optional[Callable[[int], None]] = None
) -> tuple[ft.Row, Callable[[], int]]:
    """
    Riga di stelle cliccabili per l'input di una valutazione.

    Returns:
        tuple: (controllo Row da inserire in pagina, funzione get_value()
            che restituisce il punteggio corrente selezionato).
    """
    state = {"value": initial}
    star_controls: list[ft.Container] = []

    def _ridisegna() -> None:
        for idx, star in enumerate(star_controls, start=1):
            star.content.value = "★" if idx <= state["value"] else "☆"
            star.content.color = WARN if idx <= state["value"] else FAINT
            star.update()

    def _fai_click(n: int) -> Callable[[ft.ControlEvent], None]:
        def _handler(e: ft.ControlEvent) -> None:
            state["value"] = n
            _ridisegna()
            if on_change:
                on_change(n)

        return _handler

    for i in range(1, max_stars + 1):
        star = ft.Container(
            content=ft.Text("★" if i <= initial else "☆", size=size, color=WARN if i <= initial else FAINT),
            on_click=_fai_click(i),
            padding=2,
        )
        star_controls.append(star)

    row = ft.Row(star_controls, spacing=2, tight=True)
    return row, (lambda: state["value"])


# ── Snackbar messaggi ───────────────────────────────────────────────────

def mostra_messaggio(page: ft.Page, text: str, color: str = ACCENT) -> None:
    """Mostra un messaggio rapido (snackbar) in fondo alla schermata."""
    page.show_dialog(
        ft.SnackBar(
            content=ft.Text(text, color="#FFFFFF"),
            bgcolor=color,
        )
    )
