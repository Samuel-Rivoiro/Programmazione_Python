"""
Modulo: theme.py
=================
Tema e palette colori dell'app mobile Smart Fleet IoT.

Palette scura "Fleet Navy", definita come semplici stringhe esadecimali:
Flet accetta colori in formato '#RRGGBB' ovunque sia richiesto un colore.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

# ── Palette colori ──────────────────────────────────────────────────────

BG: str = "#090D1A"
BG_ALT: str = "#0F1626"
SIDEBAR: str = "#0C101F"
CARD: str = "#121A2E"
CARD_ALT: str = "#1A253F"
BORDER: str = "#223154"
BORDER_LIGHT: str = "#2E3F6B"
TEXT: str = "#F1F5F9"
MUTED: str = "#94A3B8"
FAINT: str = "#64748B"

ACCENT: str = "#28BBC5"      
ACCENT_HOVER: str = "#80F8FF"
OK: str = "#13A561"         
OK_HOVER: str = "#80FFAA"
WARN: str = "#FFB300"
WARN_HOVER: str = "#FFC43D"
ERR: str = "#FF3366"
ERR_HOVER: str = "#FF668F"
PURPLE: str = "#A084E8"    
PURPLE_HOVER: str = "#B9A3F3"


def _hex_a_rgb(value: str) -> tuple[int, int, int]:
    """Converte un colore esadecimale (#RRGGBB) in una tupla RGB (0-255)."""
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def tinta(hex_color: str, alpha: float = 0.16, base: str = CARD) -> str:
    """
    Calcola una variante "tenue" (tinta) di un colore, miscelandolo con
    uno sfondo di riferimento — usato per badge, pillole e riquadri icona.

    Args:
        hex_color: Colore sorgente in formato '#RRGGBB'.
        alpha: Intensità della miscela (0 = solo sfondo, 1 = colore puro).
        base: Colore di sfondo di riferimento.

    Returns:
        str: Colore risultante in formato '#RRGGBB'.
    """
    c, b = _hex_a_rgb(hex_color), _hex_a_rgb(base)
    mixed = tuple(round(b[i] + (c[i] - b[i]) * alpha) for i in range(3))
    return "#%02X%02X%02X" % mixed


# ── Tipografia ──────────────────────────────────────────────────────────
# Font di sistema (multipiattaforma): niente "Roboto" fisso come su desktop,
# lasciamo il font di default della piattaforma (più naturale su mobile).

def f_title() -> ft.TextStyle:
    return ft.TextStyle(size=23, weight=ft.FontWeight.BOLD, color=TEXT)


def f_head() -> ft.TextStyle:
    return ft.TextStyle(size=16, weight=ft.FontWeight.BOLD, color=TEXT)


def f_body() -> ft.TextStyle:
    return ft.TextStyle(size=14, color=TEXT)


def f_sm() -> ft.TextStyle:
    return ft.TextStyle(size=12, color=MUTED)


def f_xs() -> ft.TextStyle:
    return ft.TextStyle(size=10, color=MUTED)