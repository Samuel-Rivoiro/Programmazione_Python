@echo off
REM ==============================================================
REM  Smart Fleet IoT - Compilazione APK Android
REM  ITS Academy ICT Piemonte - Product by Samuel Rivoiro
REM ==============================================================
title Smart Fleet IoT - Compilazione APK
cd /d "%~dp0"

echo ========================================
echo   Smart Fleet IoT - Build APK Android
echo   ITS Academy ICT Piemonte
echo   Product by Samuel Rivoiro
echo ========================================
echo.

REM Controlla se l'ambiente virtuale esiste
if not exist ".venv\Scripts\activate.bat" (
    echo [ERRORE] Virtual environment non trovato.
    echo Avvia prima lo script 'avvia_app.bat' per configurare l'ambiente.
    pause
    exit /b 1
)

echo [1/2] Attivazione ambiente virtuale...
call .venv\Scripts\activate.bat

echo [2/2] Avvio compilazione APK con Flet...
flet build apk .

if errorlevel 1 (
    echo.
    echo [ERRORE] La compilazione dell'APK ha riscontrato un problema.
    echo Assicurati di avere installato il Java Development Kit (JDK) versione 17.
    pause
    exit /b 1
)

echo.
echo ==============================================================
echo [SUCCESSO] Compilazione completata!
echo Trovi il file APK in: build\apk\app-release.apk
echo ==============================================================
pause
exit /b 0