"""
Modulo: views/auth_view.py
===========================
Schermate di autenticazione (accesso e registrazione) dell'app mobile
Smart Fleet IoT.

Chiama db.accedi/db.registra e mostra i moduli di login e registrazione
con layout adattato a schermo verticale stretto.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import sqlite3
import os

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, BG, CARD_ALT, ERR, MUTED, OK, OK_HOVER, SIDEBAR, TEXT
from widgets import campo, etichetta, pillola, pulsante, riquadro_icona, scheda, separatore


def mostra_accesso(app: SmartFleetApp) -> None:
    """Mostra la schermata di accesso (login)."""
    app.pulisci_tutto()
    page = app.page

    entry_user = campo("Username", width=320)
    entry_pass = campo("Password", password=True, width=320)
    error_label = etichetta("", size=12, color=ERR)

    def _esegui_accesso(e: ft.ControlEvent) -> None:
        username = (entry_user.value or "").strip()
        password = (entry_pass.value or "").strip()

        result = app.db.accedi(username, password)
        if result:
            app.uid, app.role, app.uname = result
            from views.navigation import mostra_menu

            mostra_menu(app)
        else:
            error_label.value = "⚠  Credenziali non valide. Riprova."
            error_label.update()

    entry_pass.on_submit = _esegui_accesso

    # Carica logo.png dalla cartella assets/images se presente, altrimenti emoji fallback
    _logo_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "assets", "images", "logo.png"))
    if os.path.exists(_logo_path):
        logo_ctrl = ft.Image(src="/images/logo.png", width=64, height=64)
    else:
        logo_ctrl = riquadro_icona("🚚", ACCENT, size=64, font_size=30)

    branding = ft.Column(
        [
            logo_ctrl,
            etichetta("Smart Fleet IoT", size=26, weight=ft.FontWeight.BOLD),
            etichetta("Gestione Flotta Aziendale Connessa", size=12, color=MUTED),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8,
    )

    form = scheda(
        ft.Column(
            [
                etichetta("Accedi al Sistema", size=19, weight=ft.FontWeight.BOLD),
                etichetta("Inserisci le tue credenziali aziendali", size=12, color=MUTED),
                ft.Container(height=10),
                entry_user,
                entry_pass,
                error_label,
                ft.Container(height=4),
                pulsante("Accedi  →", _esegui_accesso, width=320, height=46),
                ft.TextButton(
                    "Nuovo dipendente? Registrati qui",
                    on_click=lambda e: mostra_registrazione(app),
                    style=ft.ButtonStyle(color=MUTED),
                ),
            ],
            spacing=10,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=360,
    )

    page.controls.append(
        ft.Container(
            content=ft.Column(
                [
                    ft.Container(height=40),
                    branding,
                    ft.Container(height=28),
                    form,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                scroll=ft.ScrollMode.AUTO,
            ),
            bgcolor=BG,
            expand=True,
            alignment=ft.Alignment.TOP_CENTER,
            padding=20,
        )
    )
    page.update()


def mostra_registrazione(app: SmartFleetApp) -> None:
    """Mostra la schermata di registrazione nuovo dipendente."""
    app.pulisci_tutto()
    page = app.page

    entry_user = campo("Username", width=320)
    entry_pass = campo("Password", password=True, width=320)
    msg_label = etichetta("", size=12)

    def _registra(e: ft.ControlEvent) -> None:
        username = (entry_user.value or "").strip()
        password = (entry_pass.value or "").strip()

        if not username or not password:
            msg_label.value = "Tutti i campi obbligatori!"
            msg_label.color = ERR
            msg_label.update()
            return

        try:
            app.db.registra(username, password)
            msg_label.value = "✓  Registrazione completata!"
            msg_label.color = OK
            msg_label.update()
            page.run_task(_torna_al_login_ritardato)
        except sqlite3.IntegrityError:
            msg_label.value = "Username già in uso!"
            msg_label.color = ERR
            msg_label.update()

    async def _torna_al_login_ritardato() -> None:
        import asyncio

        await asyncio.sleep(1.4)
        mostra_accesso(app)

    # Carica logo.png dalla cartella assets/images se presente, altrimenti emoji fallback
    _logo_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "assets", "images", "logo.png"))
    if os.path.exists(_logo_path):
        logo_ctrl = ft.Image(src="/images/logo.png", width=64, height=64)
    else:
        logo_ctrl = riquadro_icona("🧾", OK, size=64, font_size=30)

    branding = ft.Column(
        [
            logo_ctrl,
            etichetta("Smart Fleet IoT", size=26, weight=ft.FontWeight.BOLD),
            etichetta("Unisciti alla flotta connessa", size=12, color=MUTED),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=8,
    )

    form = scheda(
        ft.Column(
            [
                etichetta("Crea il tuo Account", size=19, weight=ft.FontWeight.BOLD),
                pillola("PROFILO STANDARD", OK),
                ft.Container(height=10),
                entry_user,
                entry_pass,
                msg_label,
                ft.Container(height=4),
                pulsante("Crea Account", _registra, bgcolor=OK, width=320, height=46),
                ft.TextButton(
                    "Torna al Login",
                    on_click=lambda e: mostra_accesso(app),
                    style=ft.ButtonStyle(color=MUTED),
                ),
            ],
            spacing=10,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=360,
    )

    page.controls.append(
        ft.Container(
            content=ft.Column(
                [
                    ft.Container(height=40),
                    branding,
                    ft.Container(height=28),
                    form,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                scroll=ft.ScrollMode.AUTO,
            ),
            bgcolor=BG,
            expand=True,
            alignment=ft.Alignment.TOP_CENTER,
            padding=20,
        )
    )
    page.update()
