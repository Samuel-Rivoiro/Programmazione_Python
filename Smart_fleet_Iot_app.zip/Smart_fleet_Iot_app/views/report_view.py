"""
Modulo: views/report_view.py
==============================
Pagina di reportistica PDF (solo admin) dell'app mobile Smart Fleet IoT.

Genera il PDF con ReportLab (libreria Python pura) e lo salva nella
cartella dati scrivibile dell'app (flet.app_data_path se disponibile,
altrimenti la cartella corrente in modalità sviluppo).

Nota: ReportLab non è mai stato testato in questo ambiente dentro un
pacchetto Flet per Android/iOS reale — è una libreria pura Python quindi
dovrebbe funzionare, ma va verificato con `flet run`/`flet build` sul tuo
dispositivo.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import os
from datetime import datetime

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, MUTED, OK, PURPLE, PURPLE_HOVER, WARN, _hex_a_rgb
from widgets import etichetta, intestazione, mostra_messaggio, pulsante, riga_kpi, scheda


def _cartella_dati_scrivibile() -> str:
    """Restituisce una cartella scrivibile per salvare i PDF generati."""
    try:
        import flet as _ft

        if getattr(_ft, "app_data_path", None):
            path = os.path.join(_ft.app_data_path, "REPORT_STATISTICHE_FLOTTA")
            os.makedirs(path, exist_ok=True)
            return path
    except Exception:
        pass
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "REPORT_STATISTICHE_FLOTTA")
    path = os.path.abspath(path)
    os.makedirs(path, exist_ok=True)
    return path


def pagina_report(app: SmartFleetApp) -> None:
    """Mostra la pagina di reportistica con anteprima KPI e generazione PDF."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione("📄", "Reportistica PDF", "Genera il report completo delle attività flotta", color=PURPLE)
    )

    report_data = app.db.ottieni_dati_report()
    stats = report_data["stats"]
    vehicles_data = report_data["vehicles"]
    reservations_data = report_data["reservations"]

    content.controls.append(
        riga_kpi(
            [
                ("🚗", stats["total_vehicles"], "Veicoli", ACCENT),
                ("✅", stats["available_vehicles"], "Disponibili", OK),
                ("📅", stats["total_reservations"], "Prenotazioni", WARN),
                ("📢", stats["total_reviews"], "Segnalazioni", PURPLE),
                ("👥", stats["total_users"], "Utenti", MUTED),
            ]
        )
    )

    msg_label = etichetta("", size=12)

    def _genera_pdf(e: ft.ControlEvent) -> None:
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import cm
            from reportlab.pdfgen import canvas as pdf_canvas
            from reportlab.platypus import Table, TableStyle
        except ImportError:
            msg_label.value = "✗ ReportLab non installato in questo ambiente."
            msg_label.color = WARN
            msg_label.update()
            return

        def _rgb01(hex_color: str) -> tuple[float, float, float]:
            r, g, b = _hex_a_rgb(hex_color)
            return (r / 255, g / 255, b / 255)

        reports_dir = _cartella_dati_scrivibile()
        filename = os.path.join(reports_dir, "report_utilizzo_flotta.pdf")
        cv = pdf_canvas.Canvas(filename, pagesize=A4)
        width, height = A4

        SIDEBAR_HEX = "#0D1220"
        cv.setFillColorRGB(*_rgb01(SIDEBAR_HEX))
        cv.rect(0, height - 75, width, 75, fill=1, stroke=0)
        cv.setFillColorRGB(*_rgb01(ACCENT))
        cv.rect(0, height - 78, width, 3, fill=1, stroke=0)
        cv.setFillColorRGB(1, 1, 1)
        cv.setFont("Helvetica-Bold", 18)
        cv.drawString(36, height - 38, "SMART FLEET IoT — Report Statistiche Flotta")
        cv.setFillColorRGB(*_rgb01(MUTED))
        cv.setFont("Helvetica", 9)
        now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        cv.drawString(36, height - 56, f"Generato il {now_str}  |  ITS Academy ICT Piemonte")

        y_pos = height - 100
        kpi_labels = ["Veicoli Totali", "Disponibili", "Prenotazioni", "Segnalazioni", "Utenti"]
        kpi_values = [
            stats["total_vehicles"], stats["available_vehicles"],
            stats["total_reservations"], stats["total_reviews"], stats["total_users"],
        ]
        for i, (lbl, val) in enumerate(zip(kpi_labels, kpi_values)):
            x_offset = 36 + i * 100
            cv.setFillColorRGB(*_rgb01(ACCENT))
            cv.setFont("Helvetica-Bold", 14)
            cv.drawString(x_offset, y_pos, str(val))
            cv.setFillColorRGB(*_rgb01(MUTED))
            cv.setFont("Helvetica", 8)
            cv.drawString(x_offset, y_pos - 14, lbl)

        y_pos -= 40

        CARD_HEX = "#131A2C"
        TEXT_HEX = "#EEF2F8"
        BORDER_HEX = "#232C42"
        table_style = TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(SIDEBAR_HEX)),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor(CARD_HEX)),
            ("TEXTCOLOR", (0, 1), (-1, -1), colors.HexColor(TEXT_HEX)),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 1), (-1, -1), 7),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor(BORDER_HEX)),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("PADDING", (0, 0), (-1, -1), 4),
        ])

        vehicle_table_data = [
            ["Modello", "Targa", "Stato", "Carb%", "Freni%", "Ult.Manut."],
            *[[v[0], v[1], v[2].upper(), f"{v[3]:.0f}%", f"{v[4]:.0f}%", v[5] or "N/D"] for v in vehicles_data],
        ]
        reservation_table_data = [
            ["Utente", "Veicolo", "Dal", "Al", "Stato"],
            *[[r[0], r[1], r[2], r[3], r[4].upper()] for r in reservations_data],
        ]

        sections = [
            ("PARCO VEICOLI", vehicle_table_data, [4 * cm, 2.5 * cm, 2.8 * cm, 1.5 * cm, 1.5 * cm, 3 * cm]),
            ("ULTIME PRENOTAZIONI", reservation_table_data, [3.5 * cm, 4 * cm, 3 * cm, 3 * cm, 3 * cm]),
        ]

        for title, data, col_widths in sections:
            if y_pos < 120:
                cv.showPage()
                y_pos = height - 50

            cv.setFillColorRGB(*_rgb01(ACCENT))
            cv.setFont("Helvetica-Bold", 12)
            cv.drawString(36, y_pos, f"▶  {title}")
            y_pos -= 14

            table = Table(data, colWidths=col_widths)
            table.setStyle(table_style)
            table.wrapOn(cv, width, height)
            _, table_height = table.wrap(0, 0)

            if y_pos - table_height < 60:
                cv.showPage()
                y_pos = height - 50

            table.drawOn(cv, 36, y_pos - table_height)
            y_pos -= table_height + 20

        cv.setFillColorRGB(*_rgb01(SIDEBAR_HEX))
        cv.rect(0, 0, width, 30, fill=1, stroke=0)
        cv.setFillColorRGB(*_rgb01(MUTED))
        cv.setFont("Helvetica-Oblique", 7)
        cv.drawString(36, 11, "Smart Fleet IoT — ITS Academy ICT Piemonte")
        cv.drawRightString(width - 36, 11, datetime.now().strftime("%d/%m/%Y"))

        cv.save()

        msg_label.value = "✓ PDF generato con successo!"
        msg_label.color = OK
        msg_label.update()
        mostra_messaggio(app.page, "✓ Report PDF generato!", OK)

    content.controls.append(
        scheda(
            ft.Column(
                [
                    etichetta("📊  Anteprima Statistiche", size=15, weight=ft.FontWeight.BOLD),
                    msg_label,
                    pulsante("⬇  Genera Report PDF", _genera_pdf, bgcolor=PURPLE, width=260),
                ],
                spacing=10,
            )
        )
    )

    app.page.update()
