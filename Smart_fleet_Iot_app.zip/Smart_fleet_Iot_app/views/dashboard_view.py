"""
Modulo: views/dashboard_view.py
=================================
Dashboard amministratore dell'app mobile Smart Fleet IoT (KPI, telemetria,
alert predittivi).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, BG_ALT, ERR, MUTED, OK, PURPLE, WARN, tinta
from widgets import etichetta, intestazione, riga_kpi, scheda, separatore


def pagina_dashboard(app: SmartFleetApp) -> None:
    """Mostra la dashboard amministratore con KPI, telemetria e alert."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione("📊", "Dashboard Amministratore", "Panoramica flotta e telemetria IoT", color=ACCENT)
    )

    # Inserimento del banner grafico sotto l'intestazione
    content.controls.append(
        ft.Container(
            content=ft.Image(
                src="/images/banner.jpg",
                height=150,
                fit=ft.BoxFit.COVER,
                border_radius=12,
            ),
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        )
    )
    content.controls.append(ft.Container(height=10))

    kpi = app.db.ottieni_dati_kpi()
    telemetry = app.db.ottieni_dati_telemetria()
    fuel_alerts = app.db.ottieni_avvisi_carburante()
    brake_alerts = app.db.ottieni_avvisi_freni()

    occupied = kpi["total_vehicles"] - kpi["available_vehicles"]

    content.controls.append(
        riga_kpi(
            [
                ("🚗", kpi["total_vehicles"], "Veicoli", ACCENT),
                ("✅", kpi["available_vehicles"], "Disponibili", OK),
                ("🔴", occupied, "Occupati", ERR),
                ("📅", kpi["active_reservations"], "Prenotazioni", WARN),
                ("📢", kpi["total_reviews"], "Segnalazioni", PURPLE),
                ("👥", kpi["total_users"], "Utenti", MUTED),
            ]
        )
    )

    # ── Telemetria ────────────────────────────────────────────────────────
    telemetry_rows: list[ft.Control] = [
        etichetta("🔬  Telemetria", size=15, weight=ft.FontWeight.BOLD)
    ]
    for model, plate, fuel, brake, status in telemetry:
        status_color = OK if status == "disponibile" else ERR
        fuel_color = OK if fuel > 30 else ERR
        brake_color = ACCENT if brake > 30 else WARN

        telemetry_rows.append(
            ft.Column(
                [
                    ft.Row(
                        [
                            ft.Text("●", color=status_color, size=13),
                            etichetta(f"{model} ({plate})", size=12),
                        ],
                        spacing=6,
                    ),
                    ft.ProgressBar(value=fuel / 100, color=fuel_color, bgcolor=BG_ALT, height=6),
                    ft.ProgressBar(value=brake / 100, color=brake_color, bgcolor=BG_ALT, height=6),
                ],
                spacing=4,
            )
        )
    content.controls.append(scheda(ft.Column(telemetry_rows, spacing=12)))

    # ── Alert predittivi ─────────────────────────────────────────────────
    alert_rows: list[ft.Control] = [
        etichetta("⚠️  Alert Predittivi", size=15, weight=ft.FontWeight.BOLD)
    ]
    if not fuel_alerts and not brake_alerts:
        alert_rows.append(
            ft.Container(
                content=etichetta("✅  Nessuna anomalia — tutti i veicoli OK", color=OK, size=13),
                bgcolor=tinta(OK, 0.16),
                border_radius=10,
                padding=12,
            )
        )
    for model, plate, fuel in fuel_alerts:
        alert_rows.append(
            ft.Container(
                content=etichetta(f"⛽  {model} ({plate}) — Carburante: {fuel:.0f}%", color=WARN, size=13),
                bgcolor=tinta(WARN, 0.16),
                border_radius=10,
                padding=12,
            )
        )
    for model, plate, brake in brake_alerts:
        alert_rows.append(
            ft.Container(
                content=etichetta(f"🔧  {model} ({plate}) — Freni critici: {brake:.0f}%", color=ERR, size=13),
                bgcolor=tinta(ERR, 0.16),
                border_radius=10,
                padding=12,
            )
        )
    content.controls.append(scheda(ft.Column(alert_rows, spacing=8)))

    app.page.update()
