"""
Modulo: views/release_view.py
===============================
Pagina di rilascio veicoli dell'app mobile Smart Fleet IoT.

L'amministratore vede le prenotazioni attive/storico di TUTTI i
dipendenti (con nome utente su ogni pratica), un utente standard vede
solo le proprie.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, ERR, MUTED, OK, WARN
from widgets import badge_targa, etichetta, intestazione, miniatura_veicolo, mostra_messaggio, pillola, pulsante, scheda, stato_vuoto, riga_kpi


def pagina_rilascio(app: SmartFleetApp) -> None:
    """
    Mostra la pagina di rilascio veicoli (o monitoraggio noleggi per l'admin).

    Per l'amministratore la vista è estesa a tutti i dipendenti (nome
    utente su ogni pratica): l'admin non prenota mai veicoli, quindi
    altrimenti la pagina risulterebbe sempre vuota anche con veicoli
    occupati dagli utenti standard.
    """
    app.pulisci_contenuto()
    content = app.content_area

    is_admin = app.role == "admin"

    if is_admin:
        content.controls.append(
            intestazione("📈", "Monitoraggio Noleggi", "Gestione e chiusura dei noleggi attivi nella flotta", color=ACCENT)
        )
    else:
        content.controls.append(
            intestazione("🔄", "Rilascio Veicolo", "Riconsegna la vettura e chiudi la pratica", color=WARN)
        )

    if is_admin:
        active = app.db.ottieni_tutte_prenotazioni_attive()
        history = app.db.ottieni_tutto_storico_prenotazioni()
    else:
        active = app.db.ottieni_prenotazioni_attive(app.uid or 0)
        history = app.db.ottieni_storico_prenotazioni(app.uid or 0)

    if is_admin:
        # Mostra riepilogo KPI per l'amministratore
        content.controls.append(
            riga_kpi(
                [
                    ("🔄", len(active), "Noleggi Attivi", ACCENT),
                    ("📜", len(history), "Totale Storico", MUTED),
                ]
            )
        )
        content.controls.append(ft.Container(height=8))

    if not active:
        empty_msg = "Nessun noleggio attivo in corso" if is_admin else "Nessuna prenotazione attiva"
        empty_icon = "ℹ️" if is_admin else "✅"
        empty_color = MUTED if is_admin else OK
        content.controls.append(stato_vuoto(empty_msg, icon=empty_icon, color=empty_color))

    for reservation in active:
        if is_admin:
            res_id, username, model, plate, start, end, photo_path = reservation
        else:
            res_id, model, plate, start, end, photo_path = reservation

        def _rilascia(e: ft.ControlEvent, rid: int = res_id) -> None:
            app.db.rilascia_veicolo(rid)
            msg = "✓ Noleggio terminato!" if is_admin else "✓ Veicolo rilasciato!"
            mostra_messaggio(app.page, msg, OK)
            pagina_rilascio(app)

        header_controls: list[ft.Control] = [
            etichetta(f"Pratica #{res_id} — {model}", size=14, weight=ft.FontWeight.BOLD),
            badge_targa(plate),
        ]
        if is_admin:
            header_controls.append(pillola(f"👤 {username}", ACCENT))

        btn_text = "❌  Termina Noleggio" if is_admin else "✓  Rilascia e Chiudi"
        btn_color = ERR if is_admin else OK

        content.controls.append(
            scheda(
                ft.Column(
                    [
                        ft.Row(
                            [
                                miniatura_veicolo(photo_path, width=48, height=48, border_radius=12),
                                ft.Column(
                                    [
                                        ft.Row(header_controls, spacing=8, wrap=True),
                                        etichetta(f"📆  Dal {start}   →   {end}", size=12, color=MUTED),
                                    ],
                                    spacing=4,
                                    expand=True,
                                ),
                            ],
                            spacing=12,
                        ),
                        pulsante(btn_text, _rilascia, bgcolor=btn_color, width=200, height=40),
                    ],
                    spacing=12,
                )
            )
        )

    # ── Storico ──────────────────────────────────────────────────────────
    if history:
        content.controls.append(etichetta("Storico Prenotazioni", size=14, weight=ft.FontWeight.BOLD, color=MUTED))

        rows: list[ft.Control] = []
        for entry in history:
            if is_admin:
                username, model, plate, start, end, status, photo_path = entry
            else:
                model, plate, start, end, status, photo_path = entry
            status_color = OK if status == "conclusa" else WARN

            left_controls: list[ft.Control] = [
                miniatura_veicolo(photo_path, width=32, height=32, border_radius=8),
            ]
            if is_admin:
                left_controls.append(etichetta(f"👤 {username}", size=11, color=ACCENT))
            left_controls.append(etichetta(model, size=12))
            left_controls.append(badge_targa(plate))
            left_controls.append(etichetta(f"{start} → {end}", size=11, color=MUTED))

            rows.append(
                ft.Row(
                    [
                        ft.Row(left_controls, spacing=8, wrap=True, expand=True),
                        pillola(status.upper(), status_color),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                )
            )
        content.controls.append(scheda(ft.Column(rows, spacing=10)))

    app.page.update()
