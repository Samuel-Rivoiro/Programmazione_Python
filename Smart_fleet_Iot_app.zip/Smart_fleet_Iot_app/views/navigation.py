"""
Modulo: views/navigation.py
============================
Shell principale (app bar + drawer di navigazione + area contenuti)
dell'app mobile Smart Fleet IoT.

La navigazione è un NavigationDrawer (menu "a cassetto") aperto dal
pulsante ☰ nella AppBar, pattern standard delle app Android/iOS.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

from typing import Callable
import os

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, BG, BORDER, CARD, ERR, FAINT, MUTED, OK, SIDEBAR, TEXT, tinta
from widgets import etichetta, pillola, riquadro_icona, separatore


def _voce_menu(icon: str, label: str, on_click: Callable[[ft.ControlEvent], None]) -> ft.Container:
    """Crea una singola voce cliccabile del drawer di navigazione."""
    row = ft.Row(
        [
            ft.Text(icon, size=18),
            etichetta(label, size=14, color=TEXT),
        ],
        spacing=14,
    )
    return ft.Container(
        content=row,
        on_click=on_click,
        padding=ft.Padding.symmetric(horizontal=18, vertical=14),
        border_radius=10,
        ink=True,
    )


def _titolo_sezione(text: str) -> ft.Container:
    """Etichetta piccola di intestazione sezione nel drawer (es. 'AMMINISTRAZIONE')."""
    return ft.Container(
        content=etichetta(text, size=10, weight=ft.FontWeight.BOLD, color=FAINT),
        padding=ft.Padding.only(left=18, top=14, bottom=4),
    )


def _chiudi_drawer_e_vai(app: SmartFleetApp, destinazione: Callable[[SmartFleetApp], None]) -> Callable[[ft.ControlEvent], None]:
    """Restituisce un handler che chiude il drawer e naviga alla pagina indicata."""

    async def _handler(e: ft.ControlEvent) -> None:
        await app.page.close_drawer()
        destinazione(app)

    return _handler


def _costruisci_drawer(app: SmartFleetApp) -> ft.NavigationDrawer:
    """Costruisce il NavigationDrawer con le voci in base al ruolo utente."""
    # Import qui (non in cima al file) per evitare import circolari: questi
    # moduli non importano navigation.py a livello di modulo.
    from views.dashboard_view import pagina_dashboard
    from views.booking_view import pagina_prenotazione
    from views.release_view import pagina_rilascio
    from views.review_view import pagina_recensioni, pagina_segnalazioni_admin
    from views.fleet_view import pagina_flotta
    from views.report_view import pagina_report
    from views.auth_view import mostra_accesso

    is_admin = app.role == "admin"
    items: list[ft.Control] = []

    # ── Header branding ──────────────────────────────────────────────────
    # Usa logo.png da assets/images se presente, altrimenti fallback emoji
    _logo_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "assets", "images", "logo.png"))
    if os.path.exists(_logo_path):
        logo_ctrl = ft.Image(src="/images/logo.png", width=48, height=48)
    else:
        logo_ctrl = riquadro_icona("🚚", ACCENT, size=48, font_size=22)

    items.append(
        ft.Container(
            content=ft.Column(
                [
                    logo_ctrl,
                    etichetta("Smart Fleet", size=16, weight=ft.FontWeight.BOLD),
                    etichetta("IoT Fleet Manager", size=11, color=MUTED),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=6,
            ),
            padding=ft.Padding.symmetric(vertical=22),
            alignment=ft.Alignment.CENTER,
        )
    )
    items.append(separatore())

    # ── Menu principale ──────────────────────────────────────────────────
    items.append(_titolo_sezione("MENU PRINCIPALE"))
    if is_admin:
        items.append(_voce_menu("📊", "Dashboard", _chiudi_drawer_e_vai(app, pagina_dashboard)))
        items.append(_voce_menu("🔄", "Monitoraggio Noleggi", _chiudi_drawer_e_vai(app, pagina_rilascio)))
    else:
        items.append(_voce_menu("📅", "Prenotazione", _chiudi_drawer_e_vai(app, pagina_prenotazione)))
        items.append(_voce_menu("🔄", "Rilascio Veicolo", _chiudi_drawer_e_vai(app, pagina_rilascio)))
        items.append(_voce_menu("⭐", "Recensione", _chiudi_drawer_e_vai(app, pagina_recensioni)))

    # ── Amministrazione ──────────────────────────────────────────────────
    if is_admin:
        items.append(separatore())
        items.append(_titolo_sezione("AMMINISTRAZIONE"))
        items.append(_voce_menu("🚗", "Gestione Flotta", _chiudi_drawer_e_vai(app, pagina_flotta)))
        items.append(_voce_menu("📋", "Segnalazioni", _chiudi_drawer_e_vai(app, pagina_segnalazioni_admin)))
        items.append(_voce_menu("📄", "Reportistica PDF", _chiudi_drawer_e_vai(app, pagina_report)))

    # ── Box utente + logout ──────────────────────────────────────────────
    items.append(separatore())
    role_color = ACCENT if is_admin else OK

    # Carica Logo_Utente.png dalla cartella assets/images se presente, altrimenti icona fallback
    _user_logo_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "assets", "images", "Logo_Utente.png"))
    if os.path.exists(_user_logo_path):
        avatar_ctrl = ft.Image(src="/images/Logo_Utente.png", width=36, height=36, border_radius=18, fit=ft.BoxFit.COVER)
    else:
        avatar_ctrl = ft.Icon(ft.Icons.ACCOUNT_CIRCLE, color=MUTED, size=36)

    from views.profile_view import pagina_profilo

    async def _vai_a_profilo(e: ft.ControlEvent) -> None:
        await app.page.close_drawer()
        pagina_profilo(app)

    items.append(
        ft.Container(
            content=ft.Column(
                [
                    ft.Container(
                        content=ft.Column(
                            [
                                etichetta("PROFILO", size=11, weight=ft.FontWeight.BOLD, color=FAINT),
                                ft.Row(
                                    [
                                        avatar_ctrl,
                                        ft.Column(
                                            [
                                                etichetta(app.uname or "", size=14, weight=ft.FontWeight.BOLD),
                                                pillola((app.role or "").upper(), role_color),
                                            ],
                                            spacing=2,
                                            horizontal_alignment=ft.CrossAxisAlignment.START,
                                        )
                                    ],
                                    alignment=ft.MainAxisAlignment.START,
                                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                                    spacing=10,
                                ),
                            ],
                            spacing=6,
                        ),
                        on_click=_vai_a_profilo,
                        padding=10,
                        border_radius=10,
                        ink=True,
                    ),
                    ft.Container(height=6),
                    ft.OutlinedButton(
                        "⎋  Disconnetti",
                        on_click=_crea_handler_disconnetti(app, mostra_accesso),
                        style=ft.ButtonStyle(color=ERR, side=ft.BorderSide(1, ERR)),
                    ),
                ],
                spacing=6,
            ),
            padding=16,
        )
    )

    return ft.NavigationDrawer(controls=items, bgcolor=SIDEBAR)


def _crea_handler_disconnetti(
    app: SmartFleetApp, mostra_accesso: Callable[[SmartFleetApp], None]
) -> Callable[[ft.ControlEvent], None]:
    """Restituisce un handler che chiude il drawer, la sessione e torna al login."""

    async def _handler(e: ft.ControlEvent) -> None:
        await app.page.close_drawer()
        app.logout()
        mostra_accesso(app)

    return _handler


def mostra_menu(app: SmartFleetApp) -> None:
    """
    Costruisce la shell principale post-login (app bar + drawer + area
    contenuti) e naviga alla prima pagina in base al ruolo.
    """
    from views.dashboard_view import pagina_dashboard
    from views.booking_view import pagina_prenotazione

    page = app.page
    page.controls.clear()

    page.drawer = _costruisci_drawer(app)

    page.appbar = ft.AppBar(
        leading=ft.IconButton(icon=ft.Icons.MENU, icon_color=TEXT, on_click=_crea_handler_apri_drawer(app)),
        title=etichetta("Smart Fleet IoT", size=16, weight=ft.FontWeight.BOLD),
        bgcolor=SIDEBAR,
        center_title=False,
    )

    app.pulisci_contenuto()
    page.controls.append(
        ft.Container(content=app.content_area, padding=16, expand=True, bgcolor=BG)
    )

    if app.role == "admin":
        pagina_dashboard(app)
    else:
        pagina_prenotazione(app)

    page.update()


def _crea_handler_apri_drawer(app: SmartFleetApp) -> Callable[[ft.ControlEvent], None]:
    """Restituisce un handler che apre il drawer di navigazione."""

    async def _handler(e: ft.ControlEvent) -> None:
        await app.page.show_drawer()

    return _handler
