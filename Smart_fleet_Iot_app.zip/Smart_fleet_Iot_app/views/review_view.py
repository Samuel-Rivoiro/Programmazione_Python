"""
Modulo: views/review_view.py
==============================
Pagina di recensioni/segnalazioni dell'app mobile Smart Fleet IoT.

Contiene due schermate:
    - pagina_recensioni: form nuova segnalazione + storico personale
      (utenti standard).
    - pagina_segnalazioni_admin: storico di TUTTE le segnalazioni di
      TUTTI i dipendenti, con nome utente (solo admin).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, FAINT, MUTED, OK, PURPLE, WARN
from widgets import etichetta, intestazione, mostra_messaggio, scheda, separatore, stato_vuoto, stelle_selezionabili, stelle_sola_lettura


def pagina_recensioni(app: SmartFleetApp) -> None:
    """Mostra form nuova segnalazione + storico personale dell'utente."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione("📋", "Recensione e Segnalazioni", "Feedback e anomalie sull'utilizzo del veicolo", color=PURPLE)
    )

    vehicles = app.db.ottieni_elenco_veicoli()
    if not vehicles:
        content.controls.append(stato_vuoto("Nessun veicolo in flotta", icon="🚗"))
        app.page.update()
        return

    vehicle_options = [ft.DropdownOption(key=str(v[0]), text=f"{v[1]} ({v[2]})") for v in vehicles]
    dropdown_vehicle = ft.Dropdown(
        label="Veicolo",
        options=vehicle_options,
        value=vehicle_options[0].key,
        border_color="#232C42",
        border_radius=10,
    )

    stars_row, get_score = stelle_selezionabili(initial=5, size=30)

    text_notes = ft.TextField(
        label="Note",
        multiline=True,
        min_lines=3,
        max_lines=5,
        border_color="#232C42",
        focused_border_color=ACCENT,
        border_radius=10,
    )

    msg_label = etichetta("", size=12)

    def _invia_recensione(e: ft.ControlEvent) -> None:
        vehicle_id = int(dropdown_vehicle.value)
        notes = (text_notes.value or "").strip()
        app.db.invia_recensione(app.uid or 0, vehicle_id, notes, get_score())
        mostra_messaggio(app.page, "✓ Segnalazione inviata!", OK)
        pagina_recensioni(app)

    content.controls.append(
        scheda(
            ft.Column(
                [
                    etichetta("📋  Nuova Segnalazione", size=15, weight=ft.FontWeight.BOLD),
                    dropdown_vehicle,
                    etichetta("Valutazione", size=12, color=MUTED),
                    stars_row,
                    text_notes,
                    msg_label,
                    ft.Button(
                        "📨  Invia Segnalazione",
                        on_click=_invia_recensione,
                        bgcolor=PURPLE,
                        color="#FFFFFF",
                        height=42,
                        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10)),
                    ),
                ],
                spacing=10,
            )
        )
    )

    # ── Storico personale ────────────────────────────────────────────────
    reviews = app.db.ottieni_recensioni_utente(app.uid or 0)
    if reviews:
        content.controls.append(etichetta("Ultime Segnalazioni effettuate", size=14, weight=ft.FontWeight.BOLD, color=MUTED))
        for score, notes, review_date, model in reviews:
            body: list[ft.Control] = [
                ft.Row(
                    [stelle_sola_lettura(score), etichetta(model, size=13, weight=ft.FontWeight.BOLD), etichetta(review_date, size=11, color=MUTED)],
                    spacing=10,
                )
            ]
            if notes:
                body.append(etichetta(notes, size=12, color=MUTED))
            content.controls.append(scheda(ft.Column(body, spacing=8)))

    app.page.update()


def pagina_segnalazioni_admin(app: SmartFleetApp) -> None:
    """Mostra lo storico completo delle segnalazioni di tutti i dipendenti (solo admin)."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione("📋", "Segnalazioni Dipendenti", "Storico delle segnalazioni inviate da tutti i dipendenti", color=PURPLE)
    )

    reports = app.db.ottieni_tutte_segnalazioni()

    if not reports:
        content.controls.append(stato_vuoto("Nessuna segnalazione inviata dai dipendenti", icon="📋"))
        app.page.update()
        return

    content.controls.append(etichetta(f"Tutte le Segnalazioni ({len(reports)})", size=14, weight=ft.FontWeight.BOLD, color=MUTED))

    for username, score, notes, review_date, model, plate in reports:
        body: list[ft.Control] = [
            ft.Row(
                [
                    etichetta(f"👤 {username}", size=13, weight=ft.FontWeight.BOLD),
                    etichetta(f"{model} ({plate})", size=12, color=MUTED),
                ],
                spacing=10,
            ),
            etichetta(review_date, size=11, color=FAINT),
            stelle_sola_lettura(score),
        ]
        if notes:
            body.append(etichetta(notes, size=12, color=MUTED))
        content.controls.append(scheda(ft.Column(body, spacing=6)))

    app.page.update()
