"""
Modulo: views/booking_view.py
===============================
Pagina di prenotazione veicoli dell'app mobile Smart Fleet IoT.

Griglia di veicoli disponibili selezionabile (2 colonne su schermo
stretto), form date, conferma.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, BORDER, CARD, ERR, MUTED, OK, WARN, tinta
from widgets import (
    badge_targa,
    campo,
    etichetta,
    intestazione,
    miniatura_veicolo,
    mostra_messaggio,
    pillola,
    pulsante,
    scheda,
    stato_vuoto,
)


def pagina_prenotazione(app: SmartFleetApp) -> None:
    """Mostra la pagina di prenotazione veicoli."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione(
            "📅",
            "Prenotazione Veicolo",
            "Seleziona un mezzo e inserisci le date della tua prenotazione.",
            color=OK,
        )
    )

    available = app.db.ottieni_veicoli_disponibili()

    # Veicolo del mese (Fiat Panda, CM340MX), mostrato in evidenza se
    # ancora disponibile.
    veicolo_del_mese = next((v for v in available if v[2] == "CM340MX"), None)
    if veicolo_del_mese:
        _, model, plate, _, _, photo_path = veicolo_del_mese
        content.controls.append(
            scheda(
                ft.Row(
                    [
                        miniatura_veicolo(photo_path, width=76, height=76, border_radius=12),
                        ft.Column(
                            [
                                pillola("🏆 VEICOLO DEL MESE", WARN),
                                ft.Row(
                                    [etichetta(model, size=15, weight=ft.FontWeight.BOLD), badge_targa(plate)],
                                    spacing=10,
                                ),
                                etichetta(
                                    "Efficienza ottima · Monitoraggio IoT pastiglie freni attivo",
                                    size=11,
                                    color=MUTED,
                                ),
                            ],
                            spacing=6,
                            expand=True,
                        ),
                    ],
                    spacing=14,
                )
            )
        )

    if not available:
        content.controls.append(stato_vuoto("Nessun veicolo disponibile al momento", icon="🚧"))
        app.page.update()
        return

    content.controls.append(
        etichetta(f"Veicoli Disponibili · {len(available)}", size=14, weight=ft.FontWeight.BOLD, color=MUTED)
    )

    selected = {"id": available[0][0]}
    vehicle_cards: dict[int, ft.Container] = {}

    def _seleziona(vid: int) -> None:
        selected["id"] = vid
        for cvid, card in vehicle_cards.items():
            active = cvid == vid
            card.border = ft.Border.all(2 if active else 1, ACCENT if active else BORDER)
            card.bgcolor = tinta(ACCENT, 0.10) if active else CARD
            card.update()

    grid_controls: list[ft.Control] = []
    for vehicle in available:
        vid, model, plate, fuel, brake, photo_path = vehicle
        fuel_color = OK if fuel > 40 else (WARN if fuel > 20 else ERR)
        brake_color = OK if brake > 40 else (WARN if brake > 20 else ERR)
        active = vid == selected["id"]

        card = ft.Container(
            content=ft.Column(
                [
                    miniatura_veicolo(photo_path, width=140, height=90, border_radius=10),
                    etichetta(model, size=13, weight=ft.FontWeight.BOLD),
                    badge_targa(plate),
                    ft.Row(
                        [pillola(f"⛽ {fuel:.0f}%", fuel_color), pillola(f"🔧 {brake:.0f}%", brake_color)],
                        spacing=4,
                    ),
                ],
                spacing=6,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor=tinta(ACCENT, 0.10) if active else CARD,
            border=ft.Border.all(2 if active else 1, ACCENT if active else BORDER),
            border_radius=14,
            padding=10,
            on_click=lambda e, v=vid: _seleziona(v),
        )
        vehicle_cards[vid] = card
        grid_controls.append(ft.Container(card, col={"xs": 6, "sm": 4, "md": 3}))

    content.controls.append(ft.ResponsiveRow(grid_controls, spacing=8, run_spacing=8))
    # Stato iniziale già impostato sopra in fase di costruzione delle card
    # (niente chiamata a _seleziona()/card.update() qui: le card non sono
    # ancora state aggiunte alla pagina reale finché non viene chiamato
    # app.page.update() più sotto — chiamare .update() prima causerebbe
    # "Control must be added to the page first").

    # ── Form date ────────────────────────────────────────────────────────
    entry_start = campo("Dal (GG/MM/AAAA)", width=200)
    entry_end = campo("Al (GG/MM/AAAA)", width=200)
    msg_label = etichetta("", size=12)

    def _conferma_prenotazione(e: ft.ControlEvent) -> None:
        start = (entry_start.value or "").strip()
        end = (entry_end.value or "").strip()

        if not start or not end:
            msg_label.value = "Inserire entrambe le date!"
            msg_label.color = ERR
            msg_label.update()
            return

        # Importiamo la libreria standard datetime all'interno della funzione per evitare overhead all'avvio dell'app
        from datetime import datetime

        # Blocco try-except per verificare la validità sintattica e semantica delle date digitate dall'utente
        try:
            # La funzione datetime.strptime tenta di decodificare le stringhe in base al formato giorno/mese/anno (%d/%m/%Y).
            # Questa operazione valida automaticamente la consistenza del calendario (es. bloccando il 31 Febbraio o mesi > 12).
            # Se il formato è errato o la data non esiste nel calendario reale, viene sollevata un'eccezione ValueError.
            start_dt = datetime.strptime(start, "%d/%m/%Y")
            end_dt = datetime.strptime(end, "%d/%m/%Y")
        except ValueError:
            # Mostriamo un messaggio di errore all'utente a schermo colorato di rosso
            msg_label.value = "Data non esistente o formato non valido! Usa GG/MM/AAAA."
            msg_label.color = ERR
            msg_label.update()
            return # Interrompiamo l'esecuzione impedendo l'inserimento di dati errati nel DB

        # Validazione logico-temporale: verifica che il noleggio non finisca prima di essere iniziato
        if end_dt < start_dt:
            # Se la data finale precede quella d'inizio, mostriamo l'errore ed interrompiamo l'azione
            msg_label.value = "Errore: la data di fine precede quella di inizio!"
            msg_label.color = ERR
            msg_label.update()
            return # Interrompiamo l'esecuzione

        # Chiamata al gestore database per salvare la prenotazione ed impostare il veicolo come occupato
        app.db.prenota_veicolo(app.uid or 0, selected["id"], start, end)
        mostra_messaggio(app.page, "✓ Prenotazione confermata!", OK)
        pagina_prenotazione(app)

    content.controls.append(
        scheda(
            ft.Column(
                [
                    etichetta("📅  Dettagli Prenotazione", size=15, weight=ft.FontWeight.BOLD),
                    ft.Row([entry_start, entry_end], spacing=10, wrap=True),
                    msg_label,
                    pulsante("✓  Conferma Prenotazione", _conferma_prenotazione, bgcolor=OK, width=260),
                ],
                spacing=10,
            )
        )
    )

    app.page.update()
