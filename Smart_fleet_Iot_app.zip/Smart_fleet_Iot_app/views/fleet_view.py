"""
Modulo: views/fleet_view.py
=============================
Pagina di gestione parco veicoli dell'app mobile Smart Fleet IoT (solo
amministratore).

Su schermo stretto il parco veicoli è un elenco di card (foto, dati,
azioni); la selezione foto usa il FilePicker nativo di Flet (che su
Android/iOS apre la galleria/file manager del dispositivo).

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import sqlite3

import flet as ft

from state import SmartFleetApp
from theme import ACCENT, BORDER, ERR, MUTED, OK, OK_HOVER, WARN, WARN_HOVER, tinta
from widgets import (
    badge_targa,
    campo,
    codifica_immagine_base64,
    etichetta,
    intestazione,
    miniatura_veicolo,
    mostra_messaggio,
    pillola,
    pulsante,
    scheda,
)


def pagina_flotta(app: SmartFleetApp) -> None:
    """Mostra la pagina di gestione parco veicoli (solo admin)."""
    app.pulisci_contenuto()
    content = app.content_area

    content.controls.append(
        intestazione("🚗", "Gestione Parco Veicoli", "Aggiungi, rimuovi, rifornisci e manutieni i mezzi", color=ACCENT)
    )



    all_vehicles = app.db.ottieni_tutti_veicoli()

    content.controls.append(etichetta(f"Flotta Completa · {len(all_vehicles)}", size=14, weight=ft.FontWeight.BOLD, color=MUTED))

    for vehicle in all_vehicles:
        vid, model, plate, status, fuel, brake, maint, photo_path = vehicle
        status_color = OK if status == "disponibile" else ERR
        fuel_color = OK if fuel > 30 else ERR
        brake_color = OK if brake > 30 else WARN

        content.controls.append(
            scheda(
                ft.Column(
                    [
                        ft.Row(
                            [
                                miniatura_veicolo(photo_path, width=54, height=44, border_radius=10),
                                ft.Column(
                                    [
                                        ft.Row([etichetta(model, size=13, weight=ft.FontWeight.BOLD), badge_targa(plate)], spacing=8, wrap=True),
                                        ft.Row(
                                            [
                                                pillola(status.upper(), status_color),
                                                etichetta(f"⛽ {fuel:.0f}%", size=11, color=fuel_color),
                                                etichetta(f"🔧 {brake:.0f}%", size=11, color=brake_color),
                                            ],
                                            spacing=8,
                                        ),
                                        etichetta(f"Ultima manutenzione: {maint or 'N/D'}", size=11, color=MUTED),
                                    ],
                                    spacing=4,
                                    expand=True,
                                ),
                            ],
                            spacing=12,
                        ),
                        ft.Row(
                            [
                                ft.OutlinedButton(
                                    "⛽ Rifornimento",
                                    on_click=lambda e, v=vid, m=model, p=plate, f=fuel, b=brake: _apri_dialogo_azione(app, v, m, p, f, b, "rifornimento"),
                                    style=ft.ButtonStyle(color=OK),
                                ),
                                ft.OutlinedButton(
                                    "🔧 Manutenzione",
                                    on_click=lambda e, v=vid, m=model, p=plate, f=fuel, b=brake: _apri_dialogo_azione(app, v, m, p, f, b, "manutenzione"),
                                    style=ft.ButtonStyle(color=WARN),
                                ),
                                ft.OutlinedButton(
                                    "🗑 Elimina",
                                    on_click=lambda e, v=vid, m=model: _conferma_elimina(app, v, m),
                                    style=ft.ButtonStyle(color=ERR),
                                ),
                            ],
                            spacing=8,
                            wrap=True,
                        ),
                    ],
                    spacing=10,
                )
            )
        )

    # ── Form aggiunta veicolo ────────────────────────────────────────────
    content.controls.append(_costruisci_form_aggiunta(app))

    app.page.update()


def _conferma_elimina(app: SmartFleetApp, vehicle_id: int, model: str) -> None:
    """Chiede conferma prima di eliminare un veicolo (azione irreversibile)."""

    def _chiudi(e: ft.ControlEvent) -> None:
        app.page.pop_dialog()

    def _elimina(e: ft.ControlEvent) -> None:
        app.db.elimina_veicolo(vehicle_id)
        app.page.pop_dialog()
        mostra_messaggio(app.page, f"Veicolo {model} eliminato", ERR)
        pagina_flotta(app)

    dialog = ft.AlertDialog(
        modal=True,
        title=etichetta("Elimina veicolo", size=16, weight=ft.FontWeight.BOLD),
        content=etichetta(f"Eliminare definitivamente '{model}'? Verranno rimosse anche prenotazioni e segnalazioni collegate."),
        actions=[
            ft.TextButton("Annulla", on_click=_chiudi),
            ft.TextButton("Elimina", on_click=_elimina, style=ft.ButtonStyle(color=ERR)),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    app.page.show_dialog(dialog)


def _apri_dialogo_azione(
    app: SmartFleetApp, vehicle_id: int, model: str, plate: str, fuel_level: float, brake_level: float, mode: str
) -> None:
    """Apre un dialogo per registrare rifornimento o manutenzione."""
    is_refuel = mode == "rifornimento"
    accent_color = OK if is_refuel else WARN
    icon = "⛽" if is_refuel else "🔧"
    initial_value = fuel_level if is_refuel else brake_level

    value_label = etichetta(f"{initial_value:.0f}%", size=24, weight=ft.FontWeight.BOLD, color=accent_color)
    slider = ft.Slider(
        min=0,
        max=100,
        value=initial_value,
        active_color=accent_color,
        on_change=lambda e: (_aggiorna_valore_label(value_label, e.control.value)),
    )
    notes_field = campo("Note intervento") if not is_refuel else None

    def _aggiorna_valore_label(label: ft.Text, value: float) -> None:
        label.value = f"{value:.0f}%"
        label.update()

    def _chiudi(e: ft.ControlEvent) -> None:
        app.page.pop_dialog()

    def _salva(e: ft.ControlEvent) -> None:
        if is_refuel:
            app.db.aggiorna_livello_carburante(vehicle_id, slider.value)
        else:
            app.db.aggiorna_manutenzione_freni(vehicle_id, slider.value, (notes_field.value or "") if notes_field else "")
        app.page.pop_dialog()
        mostra_messaggio(app.page, "✓ Aggiornato con successo", accent_color)
        pagina_flotta(app)

    content_controls: list[ft.Control] = [
        ft.Row([etichetta(model, size=13, color=MUTED), badge_targa(plate)], spacing=8),
        value_label,
        slider,
    ]
    if notes_field:
        content_controls.append(notes_field)

    dialog = ft.AlertDialog(
        modal=True,
        title=ft.Row([etichetta(icon, size=20), etichetta("Rifornimento" if is_refuel else "Manutenzione", size=16, weight=ft.FontWeight.BOLD)], spacing=8),
        content=ft.Column(content_controls, tight=True, spacing=10, width=280),
        actions=[
            ft.TextButton("Annulla", on_click=_chiudi),
            ft.TextButton("✓ Salva", on_click=_salva, style=ft.ButtonStyle(color=accent_color)),
        ],
        actions_alignment=ft.MainAxisAlignment.END,
    )
    app.page.show_dialog(dialog)


def _costruisci_form_aggiunta(app: SmartFleetApp) -> ft.Container:
    """Costruisce la card del form 'Aggiungi Nuovo Veicolo' con selezione foto."""
    entry_model = campo("Modello (es. Fiat Tipo)", width=300)
    entry_plate = campo("Targa (es. AB123CD)", width=300)
    entry_fuel = campo("Carburante % (0-100)", width=300)
    entry_brake = campo("Usura Freni % (0-100)", width=300)

    photo_state = {"encoded": ""}
    photo_status_label = etichetta("Nessuna foto selezionata", size=12, color=MUTED)
    add_msg = etichetta("", size=12)

    async def _scegli_foto(e: ft.ControlEvent) -> None:
        files = await ft.FilePicker().pick_files(
            allow_multiple=False, file_type=ft.FilePickerFileType.IMAGE
        )
        if not files:
            return
        picked = files[0]
        encoded = codifica_immagine_base64(picked.path) if picked.path else ""
        if encoded:
            photo_state["encoded"] = encoded
            photo_status_label.value = f"✓ {picked.name}"
            photo_status_label.color = OK
        else:
            photo_status_label.value = "Impossibile leggere il file scelto"
            photo_status_label.color = ERR
        photo_status_label.update()

    saving = {"attivo": False}

    def _aggiungi_veicolo(e: ft.ControlEvent) -> None:
        if saving["attivo"]:
            return

        model = (entry_model.value or "").strip()
        plate = (entry_plate.value or "").strip().upper()

        try:
            fuel_val = float(entry_fuel.value or 100)
            brake_val = float(entry_brake.value or 100)
        except ValueError:
            add_msg.value = "Carburante % e Usura Freni % devono essere numeri!"
            add_msg.color = ERR
            add_msg.update()
            return

        if not model or not plate:
            add_msg.value = "Modello e Targa obbligatori!"
            add_msg.color = ERR
            add_msg.update()
            return

        if app.db.ottieni_id_veicolo_per_targa(plate) is not None:
            add_msg.value = "Targa già presente!"
            add_msg.color = ERR
            add_msg.update()
            return

        saving["attivo"] = True
        add_btn.disabled = True
        add_btn.update()

        try:
            app.db.aggiungi_veicolo(model, plate, fuel_val, brake_val, photo_state["encoded"])
            mostra_messaggio(app.page, "✓ Veicolo aggiunto!", OK)
            pagina_flotta(app)
        except sqlite3.IntegrityError:
            add_msg.value = "Targa già presente!"
            add_msg.color = ERR
            add_msg.update()
            saving["attivo"] = False
            add_btn.disabled = False
            add_btn.update()

    add_btn = pulsante("+  Aggiungi Veicolo", _aggiungi_veicolo, bgcolor=OK, width=260)

    return scheda(
        ft.Column(
            [
                etichetta("➕  Aggiungi Nuovo Veicolo", size=15, weight=ft.FontWeight.BOLD),
                entry_model,
                entry_plate,
                entry_fuel,
                entry_brake,
                ft.Row(
                    [
                        ft.OutlinedButton(
                            "📷  Scegli Foto",
                            on_click=_scegli_foto,
                        ),
                        photo_status_label,
                    ],
                    spacing=10,
                ),
                add_msg,
                add_btn,
            ],
            spacing=10,
        )
    )
