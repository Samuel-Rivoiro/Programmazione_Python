"""
Modulo: views/profile_view.py
=============================
Vista del profilo utente dell'app mobile Smart Fleet IoT.
Integrazione come sezione standard dell'applicazione (analoga a Gestione Flotta),
in tema scuro con editing di nome utente, password, email, telefono e sito web.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

import os
import sqlite3
import flet as ft

from state import SmartFleetApp
from theme import BORDER, MUTED, PURPLE, ERR, OK
from widgets import (
    campo,
    etichetta,
    intestazione,
    mostra_messaggio,
    pillola,
    pulsante,
    scheda,
)


def pagina_profilo(app: SmartFleetApp) -> None:
    """Mostra il modulo del profilo utente integrato nella shell scura dell'app."""
    app.pulisci_contenuto()
    content = app.content_area
    page = app.page

    # Recupera i dati correnti del profilo
    dati = app.db.ottieni_dati_utente(app.uid)
    if not dati:
        username_val = app.uname or ""
        role_val = app.role or "standard"
        email_val = ""
        phone_val = ""
        password_val = ""
    else:
        username_val, role_val, email_val, phone_val, password_val = dati

    # Intestazione coerente con "Gestione Flotta"
    content.controls.append(
        intestazione("👤", "Profilo Utente", "Visualizza e modifica le tue credenziali e informazioni personali", color=PURPLE)
    )

    # Campi di input scuri (usando l'helper campo da widgets.py)
    input_username = campo("Username / Nome Utente", value=username_val, width=360)
    input_email = campo("Email", value=email_val, width=360)
    input_telefono = campo("Numero di Telefono", value=phone_val, width=360)
    input_password = campo("Password", value=password_val, password=True, width=360)

    msg_label = etichetta("", size=13, weight=ft.FontWeight.BOLD)

    # Determina l'avatar da mostrare
    _user_logo_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "assets", "images", "Logo_Utente.png"))
    if os.path.exists(_user_logo_path):
        avatar_ctrl = ft.Image(src="/images/Logo_Utente.png", width=64, height=64, border_radius=32, fit=ft.BoxFit.COVER)
    else:
        avatar_ctrl = ft.Icon(ft.Icons.ACCOUNT_CIRCLE, color=MUTED, size=64)

    def _salva_profilo(e: ft.ControlEvent) -> None:
        username = input_username.value.strip()
        email = input_email.value.strip()
        telefono = input_telefono.value.strip()
        sito = ""
        password = input_password.value.strip()

        if not username or not password:
            msg_label.value = "⚠ Username e Password sono obbligatori."
            msg_label.color = ERR
            msg_label.update()
            return

        try:
            # Eseguiamo l'operazione di UPDATE sul database locale usando la connessione SQLite incapsulata
            app.db.aggiorna_dati_utente(app.uid, username, email, telefono, password)
            # Aggiorniamo la variabile dello stato dell'app per memorizzare il nuovo username dell'utente connesso
            app.uname = username
            
            # Per rendere immediata la modifica nell'interfaccia utente (UI), rinfreschiamo l'header del drawer di navigazione.
            # Importiamo la funzione di costruzione della navigation bar per ricostruirla al volo con le nuove informazioni dell'utente.
            from views.navigation import _costruisci_drawer
            page.drawer = _costruisci_drawer(app)
            
            # Mostriamo un messaggio statico sotto il form e un Toast (messaggio popup) animato per dare un feedback immediato
            msg_label.value = "✓  Profilo aggiornato con successo!"
            msg_label.color = OK
            msg_label.update()
            mostra_messaggio(page, "✓ Profilo aggiornato con successo!", OK)
        except sqlite3.IntegrityError:
            # SQLite solleva IntegrityError se l'username viola il vincolo UNIQUE definito sul database
            msg_label.value = "⚠ Errore: questo Username è già in uso."
            msg_label.color = ERR
            msg_label.update()

    # Form organizzato dentro una scheda scura
    form_profilo = scheda(
        ft.Column(
            [
                ft.Row(
                    [
                        avatar_ctrl,
                        ft.Column(
                            [
                                etichetta(username_val.capitalize(), size=16, weight=ft.FontWeight.BOLD),
                                pillola((role_val).upper(), PURPLE),
                            ],
                            spacing=3,
                        )
                    ],
                    alignment=ft.MainAxisAlignment.START,
                    spacing=12,
                ),
                ft.Container(height=8),
                input_username,
                input_email,
                input_telefono,
                input_password,
                msg_label,
                ft.Container(height=6),
                pulsante("Salva Modifiche", _salva_profilo, bgcolor=PURPLE, width=360),
            ],
            spacing=12,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=20,
        width=400,
    )

    # Allinea il form al centro dell'area di lavoro
    content.controls.append(
        ft.Container(
            content=form_profilo,
            alignment=ft.Alignment.CENTER,
            padding=ft.Padding.only(top=10, bottom=20),
        )
    )
    page.update()
