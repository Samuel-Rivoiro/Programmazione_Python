"""
Modulo: state.py
================
Stato applicativo centrale dell'app mobile Smart Fleet IoT.

Oggetto SmartFleetApp "leggero" che viene passato a ciascuna funzione
pagina_*() delle viste (views/), insieme al riferimento alla ft.Page di
Flet e al DatabaseManager condiviso.

Autore: Samuel Rivoiro
Corso: ITS Academy ICT Piemonte — 2025/2026
"""

from __future__ import annotations

from typing import Optional

import flet as ft

from database.db_manager import DatabaseManager
from theme import BG


class SmartFleetApp:
    """
    Contenitore dello stato di sessione e dei riferimenti condivisi tra
    tutte le schermate dell'app mobile.

    Attributes:
        page: Pagina Flet principale.
        db: Gestore del database (query SQLite).
        uid: ID dell'utente autenticato (None se non loggato).
        role: Ruolo dell'utente ('admin' o 'standard').
        uname: Username dell'utente autenticato.
        content_area: Colonna scrollabile che contiene il corpo della
            schermata corrente (dopo il login), ricostruita ad ogni
            navigazione.
    """

    def __init__(self, page: ft.Page, db: DatabaseManager) -> None:
        self.page = page
        self.db = db

        self.uid: Optional[int] = None
        self.role: Optional[str] = None
        self.uname: Optional[str] = None

        self.content_area = ft.Column(
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            spacing=14,
        )

        self.page.bgcolor = BG
        self.page.padding = 0

    # ── Helper di sessione ──────────────────────────────────────────────

    def pulisci_contenuto(self) -> None:
        """Svuota l'area contenuti (equivalente a _pulisci_contenuto)."""
        self.content_area.controls.clear()

    def pulisci_tutto(self) -> None:
        """Rimuove app bar, drawer e contenuti (per login/registrazione)."""
        self.page.appbar = None
        self.page.drawer = None
        self.page.end_drawer = None
        self.page.controls.clear()

    def logout(self) -> None:
        """Chiude la sessione corrente."""
        self.uid = None
        self.role = None
        self.uname = None
