#Librerie Client(Giocatore 2)
import socket  # Per la comunicazione tramite socket
import threading  # Per eseguire funzioni in parallelo
import tkinter as tk  # Per creare l'interfaccia grafica
from tkinter import ttk, messagebox  # Per componenti grafici(EX:messagebox)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


# Dichiarazione Variabili globali client
griglia_client = [[" " for _ in range(10)] for _ in range(10)]  # Griglia del client
nave = []  # Lista delle navi posizionate dal client
stato_nave = {}  # Stato delle navi: (celle colpite per ciascuna nave)
celle_selezionate_nave = []  # Celle selezionate per posizionare una nave
fase_gioco = 1  # Fase del gioco: 1 = posizionamento navi, 2 = attacco
numero_navi_posizionate = 0  # Numero di navi posizionate
dimensione_fissa_nave = 3  # Dimensione delle navi (fissa a 3 per ora)


# Funzione per connettersi al server
def connect_to_server():
    
    global server_connection
    server_connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP
    server_connection.connect(('localhost', 2000))  # Connessione al server locale sulla porta 2000
    log_text.insert(tk.END, "Connesso al server.\n")  # Messaggio di conferma nella chat
    log_text.insert(tk.END, "Tocca prima al server, attendi il tuo turno.\n")  # Istruzione iniziale
    threading.Thread(target=messagia_al_server, args=(server_connection,)).start()  # Avvia il thread per ricevere messaggi


# Funzione per gestire i messaggi dal server
def messagia_al_server(server_connection):
    global fase_gioco, nave
    while True:
        try:
            dati = server_connection.recv(1024).decode()  # Riceve un messaggio dal server
            if dati:
                log_text.insert(tk.END, f"Messaggio dal server: {dati}\n")  # Visualizza il messaggio nella chat
                coordinate = interpreta_coordinate(dati)  # Interpreta le coordinate ricevute
                if coordinate:
                    row, column = coordinate
                    if griglia_client[row][column] == "N":  # Se la cella contiene una nave
                        griglia_client[row][column] = "X"  # Marca la cella come colpita
                        aggiorna_stato_nave(row, column)  # Aggiorna lo stato della nave
                        if controllo_singola_nave_affondata(row, column):  # Controlla se la nave è affondata
                            server_connection.sendall(f"Colpito e Affondato su {dati}!".encode())  # Risponde al server
                            log_text.insert(tk.END, f"Attacco su ({dati}): Colpito e Affondato!\n")
                        else:
                            server_connection.sendall("Colpito!".encode())  # Risponde al server
                            log_text.insert(tk.END, f"Attacco su ({dati}): Colpito!\n")
                        if controllo_tutte_navi_affondate():  # Controlla se tutte le navi sono affondate
                            fine_gioco("Ha vinto il Server! Tutte le navi del Client sono state affondate!!!")
                    else:
                        server_connection.sendall("Mancato.".encode())  # Risponde al server
                        log_text.insert(tk.END, f"Attacco su ({dati}): Mancato.\n")
                    aggiorna_griglia()  # Aggiorna la griglia visiva
        except Exception as e:
            log_text.insert(tk.END, f"Errore: {e}\n")  # Mostra eventuali errori
            break


# Funzione per aggiornare lo stato di una nave
def aggiorna_stato_nave(row, column):
    global hits
    for nave, hits in stato_nave.items():  # Itera su tutte le navi e i loro stati
        if (row, column) in nave:# Se la cella colpita fa parte della nave
            stato_nave[nave] += 1  # Incrementa il conteggio delle celle colpite
            break


# Funzione per controllare se una nave è stata affondata
def controllo_singola_nave_affondata(row, column):
    for nave, hits in stato_nave.items():  # Itera su tutte le navi e i loro stati
        if (row, column) in nave and hits == dimensione_fissa_nave:  # Se tutte le celle della nave sono state colpite
            return True  # La nave è affondata
    return False  # La nave non è ancora affondata


# Funzione per controllare se tutte le navi sono state affondate
def controllo_tutte_navi_affondate():
    return all(hits == dimensione_fissa_nave for hits in stato_nave.values())  # Controlla ogni nave


# Funzione per terminare il gioco
def fine_gioco(message):
    global win
    messagebox.showinfo("Fine del Gioco.", message)  # Mostra un messaggio a comparsa di fine gioco
    win.destroy()  # Chiude la finestra del gioco
   

# Funzione per selezionare le celle di una nave
def seleziona_celle_nave(row, column):
    global celle_selezionate_nave, numero_navi_posizionate, fase_gioco
    if fase_gioco == 1 and numero_navi_posizionate < 5:  # Se siamo nella fase di posizionamento
        if len(celle_selezionate_nave) < 3 and griglia_client[row][column] == " ":  # Se la nave non è completa
            celle_selezionate_nave.append([row, column])  # Aggiunge la cella alla nave corrente
            griglia_client[row][column] = "N"  # Marca la cella come parte di una nave
            aggiorna_griglia()  # Aggiorna la griglia visiva
        if len(celle_selezionate_nave) == 3:  # Se la nave è completa
            if valida_nave(celle_selezionate_nave):  # Valida la nave
                nave.append(celle_selezionate_nave.copy())  # Salva la nave
                stato_nave[tuple(map(tuple, celle_selezionate_nave))] = 0  # Inizializza lo stato della nave
                celle_selezionate_nave = []  # Resetta la nave corrente
                numero_navi_posizionate += 1  # Incrementa il numero di navi posizionate
                log_text.insert(tk.END, f"Nave {numero_navi_posizionate} posizionata!\n")  # Messaggio di conferma
                if numero_navi_posizionate == 5:  # Se tutte le navi sono posizionate
                    fase_gioco = 2  # Passa alla fase di attacco
                    log_text.insert(tk.END, "Tutte le navi posizionate. Inizia prima il server ad attaccare!\n")
                    server_connection.sendall("Ho posizionato le mie navi, Inizia pure tu ad attaccare!".encode())
            else:  # Se la nave non è valida
                log_text.insert(tk.END, "Posizionamento non valido. Riprovare.\n")
                for row, column in celle_selezionate_nave:  # Resetta le celle selezionate
                    griglia_client[row][column] = " "
                celle_selezionate_nave = []
                aggiorna_griglia()  # Aggiorna la griglia visiva


# Funzione per validare la nave selezionata
def valida_nave(nave):
    if len(nave) != dimensione_fissa_nave:  # Controlla se la nave ha la dimensione corretta
        return False
    nave.sort()  # Ordina le celle per verificare la contiguità
    rows = [row for row, column in nave]  # Estrae le righe
    columns = [column for row, column in nave]  # Estrae le colonne

    if len(set(rows)) == 1:  # Controllo orizzontale (tutte le righe uguali)
        return all(columns[i] + 1 == columns[i + 1] for i in range(len(columns) - 1))  # Controlla che le colonne siano consecutive
    elif len(set(columns)) == 1:  # Controllo verticale (tutte le colonne uguali)
        return all(rows[i] + 1 == rows[i + 1] for i in range(len(rows) - 1))  # Controlla che le righe siano consecutive
    return False  # Se non è né orizzontale né verticale, la nave non è valida

# Funzione per inviare un attacco
def invio_attacco():
    global fase_gioco
    if fase_gioco == 2:  #  Verifica che il gioco sia nella fase di attacco
        coordinate = attack_entry.get()  # Legge le coordinate inserite dall'utente
        interpreta = interpreta_coordinate(coordinate)  # Interpreta le coordinate
        if interpreta:  # Se le coordinate sono valide
            log_text.insert(tk.END, f"Inviando attacco a {coordinate}\n")  # Mostra il messaggio nella chat
            server_connection.sendall(coordinate.encode())  # Invia il messaggio al server
        else:
            log_text.insert(tk.END, "Coordinate non valide!\n")  # Mostra un messaggio di errore
        attack_entry.delete(0, tk.END)  # Pulisce la casella di input

# Funzione per interpretare le coordinate
def interpreta_coordinate(coordinate):
    if len(coordinate) >= 2 and coordinate[0].isalpha() and coordinate[1:].isdigit():  # Controlla il formato (es: A1)
        ascii_value = ord(coordinate[0])  # Ottiene il valore ASCII della lettera
        if 65 <= ascii_value <= 90:  # Lettere maiuscole (A-Z)
            column = ascii_value - 65
        elif 97 <= ascii_value <= 122:  # Lettere minuscole (a-z)
            column = ascii_value - 97
        else:
            return None  # Non è una lettera valida
        row = int(coordinate[1:]) - 1  # Converte il numero in un indice (1 -> 0, 2 -> 1, ...)
        if 0 <= row < 10 and 0 <= column < 10:  # Controlla se le coordinate sono valide
            return row, column
    return None  # Se il formato non è valido, restituisce None


# Funzione per aggiornare la griglia
def aggiorna_griglia():
    for i in range(10):
        for j in range(10):
            button = grid_buttons[i][j]  # Ottiene il pulsante corrispondente
            button.config(text=griglia_client[i][j])  # Aggiorna il testo del pulsante con il valore della griglia


def applica_sfondo(win, image_path="war_battle.jpg"):
    if Image is None or ImageTk is None:
        win.configure(background="#aabbcc")
        return

    paths = []
    if image_path:
        paths.append(image_path)
    base_name = image_path.rsplit(".", 1)[0] if "." in image_path else image_path
    paths.extend([f"{base_name}.png", f"{base_name}.jpg", f"{base_name}.jpeg"])

    for path in paths:
        try:
            img = Image.open(path)
            img = img.resize((950, 800), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            bg_label = tk.Label(win, image=photo)
            bg_label.place(x=0, y=0, relwidth=1, relheight=1)
            bg_label.lower()
            win.bg_image = photo
            return
        except FileNotFoundError:
            continue
        except Exception:
            continue

    win.configure(background="#aabbcc")


def main():
    global server_connection, attack_entry, log_text, griglia_client, grid_buttons, win

    # Creazione della finestra del client
    win = tk.Tk()  # Inizializza la finestra principale
    win.title("Battaglia Navale - Client - Giocatore 2")  # Imposta il titolo della finestra
    win.configure(background="#aabbcc")  # Colore di sfondo della finestra impostato su celeste
    win.geometry("950x800+960+100")  # Dimensioni e posizione della finestra
    applica_sfondo(win)

    # Creazione della griglia grafica
    grid_frame = ttk.Frame(win)  # Crea un frame per la griglia
    grid_frame.grid(row=1, column=0, padx=20, pady=20)  # Posiziona il frame nella finestra
    grid_buttons = []  # Lista per memorizzare i pulsanti della griglia

    # Creazione delle etichette per l'asse orizzontale (lettere)
    for j in range(10):
        label = ttk.Label(grid_frame, text=chr(65 + j), font=("Arial", 12))  # A-J (65 = A in ASCII)
        label.grid(row=0, column=j + 1, padx=2, pady=2)  # Posiziona l'etichetta nella prima riga (asse orizzontale)

    # Creazione dei pulsanti della griglia
    for i in range(10):
        row = []  # Lista temporanea per memorizzare i pulsanti di una riga
        for j in range(10):
            button = tk.Button(grid_frame, text=" ", font=("Arial", 12), width=2, height=1,
                command=lambda r=i, c=j: seleziona_celle_nave(r, c)
            )  # Associa il pulsante alla funzione select_cell
            button.grid(row=i + 1, column=j + 1, padx=2, pady=2)  # Posiziona il pulsante nella griglia
            row.append(button)  # Aggiunge il pulsante alla riga
        grid_buttons.append(row)  # Aggiunge la riga alla lista dei pulsanti

    # Creazione delle etichette per l'asse verticale (numeri)
    for i in range(10):
        label = ttk.Label(grid_frame, text=str(i + 1), font=("Arial", 12))  # 1-10
        label.grid(row=i + 1, column=0, padx=2, pady=2)  # Posiziona l'etichetta nella prima colonna (asse verticale)

    # Log per visualizzare i messaggi
    log_frame = ttk.Frame(win)  # Crea un frame per il log
    log_frame.grid(row=1, column=1, padx=20, pady=20)  # Posiziona il frame nella finestra
    log_label = ttk.Label(log_frame, text="Chat di gioco", font=("Arial", 14))  # Etichetta per il log
    log_label.pack()  # Posiziona l'etichetta
    log_text = tk.Text(log_frame, font=("Arial", 10), width=50, height=30)  # Casella di testo per i messaggi
    log_text.pack()  # Posiziona la casella di testo

    # Casella per l'attacco
    attack_frame = ttk.Frame(win)  # Crea un frame per l'attacco
    attack_frame.grid(row=2, column=0, padx=20, pady=20)  # Posiziona il frame nella finestra
    attack_label = ttk.Label(attack_frame, text="Inserisci coordinate (es: A1):", font=("Arial", 12))  # Etichetta per l'attacco
    attack_label.pack()  # Posiziona l'etichetta
    attack_entry = ttk.Entry(attack_frame, font=("Arial", 12))  # Casella di input per le coordinate
    attack_entry.pack()  # Posiziona la casella di input
    attack_button = ttk.Button(attack_frame, text="Attacca", command=invio_attacco)  # Pulsante per inviare l'attacco
    attack_button.pack()  # Posiziona il pulsante

    # Connessione automatica al server
    threading.Thread(target=connect_to_server, daemon=True).start()  # Avvia il thread per connettersi al server

    # Avvia l'interfaccia grafica
    win.mainloop()  # Avvia il ciclo principale di Tkinter


if __name__ == "__main__":
    main()