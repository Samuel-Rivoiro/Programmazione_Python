#Librerie Server(Giocatore 1)
import socket # Per la comunicazione tramite socket
import threading  # Per eseguire funzioni in parallelo
import tkinter as tk # Per creare l'interfaccia grafica
from tkinter import ttk, messagebox # Per componenti grafici(EX:messagebox)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


# Dichiarazione Variabili globali server
griglia_server = [[" " for _ in range(10)] for _ in range(10)]  # Griglia del server
nave = []  # Lista delle navi posizionate dal server
stato_nave = {}  # Stato delle navi: (celle colpite per ciascuna nave)
celle_selezionate_nave = []   # Celle selezionate per posizionare una nave
fase_gioco = 1   # Fase del gioco: 1 = posizionamento navi, 2 = attacco
numero_navi_posizionate = 0  # Numero di navi posizionate
dimensione_fissa_nave = 3  # Dimensione delle navi (fissa a 3 per ora)



# Funzione per avviare il server
def start_server():
   
    global client_connection #Variabile globale per la connessione con il client in modo che possa essere utilizzata anche al di fuori della funzione.
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # Crea un socket TCP, usando IPv4
    server_address = ('localhost', 2000)# Imposta l'indirizzo e la porta del server
    server_socket.bind(server_address)# Associa il socket all'indirizzo e alla porta specificati in server_address
    server_socket.listen(1)# Configura il socket in modalità di ascolto, permettendo di accettare connessioni. Il parametro 1 indica che verrà accettata una sola connessione alla volta.
    log_text.insert(tk.END, "Server in ascolto su localhost:2000...\n")#Inserisce un messaggio nel widget log_text (ipoteticamente una finestra di log in un'interfaccia Tkinter), informando che il server è in ascolto.


    client_connection, client_address = server_socket.accept()#Il server attende e accetta una connessione in ingresso. Quando un client si connette, restituisce due valori: client_connection (il socket per comunicare con il client) e client_address (l'indirizzo del client).
    log_text.insert(tk.END, f"Connessione stabilita con {client_address}\n")#Inserisce un messaggio nel widget log_text per indicare che la connessione con il client è stata stabilita, mostrando il suo indirizzo.
    log_text.insert(tk.END, "Tocca a te posizionare le tue 5 navi!\n")#Inserisce un altro messaggio nel log per notificare all'utente che è il suo turno di posizionare le navi (probabilmente in un gioco).
    threading.Thread(target=messagia_al_client, daemon=True).start()# Avvia un thread per gestire i messaggi dal client


# Funzione per gestire i messaggi dal client
def messagia_al_client():
    global fase_gioco
    while True:
        try:
            dati = client_connection.recv(1024).decode() # Riceve un messaggio dal client
            if dati:
                log_text.insert(tk.END, f"Messaggio dal client: {dati}\n")
                coordinate = interpreta_coordinate(dati)  # Converte le coordinate in riga e colonna
                if coordinate:
                    row, column = coordinate
                    if griglia_server[row][column] == "N":  # Se la cella contiene una nave
                        griglia_server[row][column] = "X"  # Segna la cella come colpita
                        aggiorna_stato_nave(row, column)  # Aggiorna lo stato della nave
                        if controllo_singola_nave_affondata(row, column): # Controlla se la nave è affondata
                            client_connection.sendall(f"Colpito e Affondato su {dati}!".encode())
                            log_text.insert(tk.END, f"Attacco su ({dati}): Colpito e Affondato!\n")
                        else:
                            client_connection.sendall("Colpito!".encode())
                            log_text.insert(tk.END, f"Attacco su ({dati}): Colpito!\n")

                        if controllo_tutte_navi_affondate(): # Controlla se tutte le navi sono state affondate
                            fine_gioco("Ha vinto il Client! Tutte le navi del Server sono state affondate!!!")
                    else:
                        client_connection.sendall("Mancato.".encode()) # Messaggio per un attacco mancato
                        log_text.insert(tk.END, f"Attacco su ({dati}): Mancato.\n")
                    aggiorna_griglia() # Aggiorna la griglia grafica tramite funzione collegata
        except Exception as e:
            log_text.insert(tk.END, f"Errore: {e}\n") # Logga eventuali errori
            break


# Funzione per aggiornare lo stato di una nave
def aggiorna_stato_nave(row, column):
    global hits
    for nave, hits in stato_nave.items():  # Itera su tutte le navi e i loro stati
        if (row, column) in nave:  # Se la cella colpita fa parte della nave
            stato_nave[nave] += 1  # Incrementa il conteggio delle celle colpite
            break


# Funzione per controllare se una nave è stata affondata
def controllo_singola_nave_affondata(row, column):
    for nave, hits in stato_nave.items():  # Itera su tutte le navi e i loro stati
        if (row, column) in nave and hits == dimensione_fissa_nave:  # Se tutte le celle della nave sono state colpite
            return True  # La nave è affondata
    return False  # La nave non è ancora affondata


# Funzione per controllare se tutte le navi sono state affondate
def controllo_tutte_navi_affondate():
    return all(hits == dimensione_fissa_nave for hits in stato_nave.values())# Verifica se tutte le navi sono affondate


# Funzione per terminare il gioco
def fine_gioco(message):
    global win
    messagebox.showinfo("Fine del Gioco.", message)# Mostra un messaggio di fine gioco
    win.destroy() # Chiude la finestra dell'applicazione


# Funzione per selezionare le celle di una nave
def seleziona_celle_nave(row, column):
    global celle_selezionate_nave, numero_navi_posizionate, fase_gioco
    if fase_gioco == 1 and numero_navi_posizionate < 5:  # Verifica che il posizionamento sia in corso e non superi il limite di navi
        if len(celle_selezionate_nave) < 3 and griglia_server[row][column] == " ":  # Questo controllo verifica che il numero di celle selezionate per la nave corrente non abbia già raggiunto il massimo consentito, che in questo caso è 3.Se il numero di celle è minore di 3, allora è possibile aggiungere un'altra cella alla nave.
            celle_selezionate_nave.append([row, column])  # Aggiunge la cella alla nave corrente
            griglia_server[row][column] = "N"  # Segna la cella come parte della nave
            aggiorna_griglia()  # Aggiorna la griglia grafica


        if len(celle_selezionate_nave) == 3:  # Se la nave ha raggiunto la dimensione desiderata, len è una funzione integrata di Python che restituisce la lunghezza di un oggetto, come liste, stringhe, tuple o altri contenitori.
            if valida_nave(celle_selezionate_nave):  # Valida la disposizione della nave
                nave.append(celle_selezionate_nave.copy())  # Aggiunge la nave alla lista delle navi
                stato_nave[tuple(map(tuple, celle_selezionate_nave))] = 0  # Inizializza lo stato iniziale della nave a 0 "non attaccato ancora",Converte la lista di liste celle_selezionate_nave in una tupla di tuple (necessario perché le chiavi di un dizionario devono essere immutabili) e la utilizza come chiave nel dizionario stato_nave.Imposta il valore associato a questa chiave a 0, probabilmente per indicare che la nave non è stata ancora colpita.
                celle_selezionate_nave = []  # Resetta la nave corrente
                numero_navi_posizionate += 1  # Incrementa il conteggio delle navi posizionate
                log_text.insert(tk.END, f"Nave {numero_navi_posizionate} posizionata!\n")


                if numero_navi_posizionate == 5:  # Se tutte le navi sono state posizionate
                    fase_gioco = 2  # Passa alla fase di attacco
                    log_text.insert(tk.END, "Tutte le navi posizionate. Procedi con il client!\n")
                    client_connection.sendall("Ho posizionato le mie navi, Tocca a te posizionare le tue 5 navi!".encode())
            else:
                log_text.insert(tk.END, "Posizionamento non valido. Riprovare.\n")
                for row, column in celle_selezionate_nave:  # Rimuove le celle della nave non valida
                    griglia_server[row][column] = " "
                celle_selezionate_nave = []  # Resetta la nave corrente
                aggiorna_griglia()  # Aggiorna la griglia grafica



# Valida che le celle selezionate siano adiacenti e in linea
def valida_nave(nave):
    if len(nave) != dimensione_fissa_nave:  # Controlla che la nave abbia la dimensione corretta
        return False
    nave.sort()  # Ordina le celle della nave in ordine crescente per riga e, in caso di parità, per colonna. Questo rende più semplice verificare la contiguità delle celle.
    rows = [row for row, column in nave]  # Crea una lista rows contenente solo le righe delle celle nella nave.
    columns = [column for row, column in nave]  #Crea una lista columns contenente solo le colonne delle celle nella nave.


    if len(set(rows)) == 1:  # Verifica se tutte le celle si trovano sulla stessa riga (la lunghezza dell'insieme delle righe è 1).
        return all(columns[i] + 1 == columns[i + 1] for i in range(len(columns) - 1)) #Usa un'espressione all() che restituisce True solo se tutte le coppie di colonne consecutive soddisfano la condizione columns[i] + 1 == columns[i + 1].
    elif len(set(columns)) == 1:  #Verifica se tutte le celle si trovano sulla stessa colonna (la lunghezza dell'insieme delle colonne è 1).
        return all(rows[i] + 1 == rows[i + 1] for i in range(len(rows) - 1))#Controlla che ogni riga sia consecutiva alla precedente.Usa un'espressione all() simile a quella orizzontale, ma applicata alle righe.
    return False  # Non valida se non è né orizzontale né verticale



# Funzione per inviare un attacco
def invio_attacco():
    global fase_gioco
    if fase_gioco == 2:  # Verifica che il gioco sia nella fase di attacco
        coordinate = attack_entry.get()  # Ottiene le coordinate dall'input
        interpreta = interpreta_coordinate(coordinate)  # Converte le coordinate
        if interpreta:
            log_text.insert(tk.END, f"Inviato attacco a {coordinate}\n")
            client_connection.sendall(coordinate.encode())  # Invia l'attacco al client
        else:
            log_text.insert(tk.END, "Coordinate non valide!\n")
        attack_entry.delete(0, tk.END)  # Resetta il campo di input



# Funzione che interpreta e converte una stringa di coordinate in un formato utilizzabile (riga e colonna).
def interpreta_coordinate(coordinate):
    if len(coordinate) >= 2 and coordinate[0].isalpha() and coordinate[1:].isdigit():  # Controlla il formato (es: A1)
        ascii_value = ord(coordinate[0])  # Ottiene il valore ASCII della lettera
        if 65 <= ascii_value <= 90:  # Lettere maiuscole (A-Z)
            column = ascii_value - 65
        elif 97 <= ascii_value <= 122:  # Lettere minuscole (a-z)
            column = ascii_value - 97
        else:
            return None  # Non è una lettera valida
        row = int(coordinate[1:]) - 1  # Converte il numero in un indice (1 -> 0, 2 -> 1, ...)
        if 0 <= row < 10 and 0 <= column < 10:  # Controlla se le coordinate sono valide
            return row, column
    return None  # Se il formato non è valido, restituisce None


# Funzione per aggiornare la griglia
def aggiorna_griglia():
    for i in range(10): #Itera su tutte le righe della griglia (da 0 a 9, per un totale di 10 righe).
        for j in range(10): #Per ogni riga, itera su tutte le colonne della griglia (da 0 a 9, per un totale di 10 colonne). In questo modo, si attraversano tutte le celle della griglia 10x10.
            button = grid_buttons[i][j]  # Recupera il pulsante corrispondente alla cella (i, j) dalla matrice grid_buttons.
            button.config(text=griglia_server[i][j])  # Modifica il testo del pulsante per riflettere il valore corrispondente nella cella (i, j) della matrice griglia_server.Se griglia_server[i][j] è "N", il pulsante mostrerà "N".Se griglia_server[i][j] è " ", il pulsante sarà vuoto.


def applica_sfondo(win, image_path="war_battle.jpg"):
    if Image is None or ImageTk is None:
        win.configure(background="#aabbcc")
        return

    paths = []
    if image_path:
        paths.append(image_path)
    base_name = image_path.rsplit(".", 1)[0] if "." in image_path else image_path
    paths.extend([f"{base_name}.png", f"{base_name}.jpg", f"{base_name}.jpeg"])

    for path in paths:
        try:
            img = Image.open(path)
            img = img.resize((950, 800), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            bg_label = tk.Label(win, image=photo)
            bg_label.place(x=0, y=0, relwidth=1, relheight=1)
            bg_label.lower()
            win.bg_image = photo
            return
        except FileNotFoundError:
            continue
        except Exception:
            continue

    win.configure(background="#aabbcc")


def main():
    global fase_gioco, griglia_server, grid_buttons, attack_entry, log_text, win

    # Creazione della finestra del server
    win = tk.Tk()  # Inizializza la finestra principale
    win.title("Battaglia Navale - Server - Giocatore 1")  # Imposta il titolo della finestra
    win.configure(background="#aabbcc")  # Colore di sfondo della finestra impostato su celeste
    win.geometry("950x800+0+100")  # Dimensioni finestra ("DimX x DimY + SpostX + SpostY")
    applica_sfondo(win)

    # Creazione della griglia grafica
    grid_frame = ttk.Frame(win)  # Frame per contenere la griglia
    grid_frame.grid(row=1, column=0, padx=20, pady=20)  # Posiziona il frame nella finestra principale

    # Creazione delle etichette per l'asse orizzontale (lettere)
    for j in range(10):
        label = ttk.Label(grid_frame, text=chr(65 + j), font=("Arial", 12))  # A-J (65 = A in ASCII)
        label.grid(row=0, column=j + 1, padx=2, pady=2)  # Posiziona l'etichetta nella prima riga (asse orizzontale)

    # Creazione dei pulsanti della griglia
    grid_buttons = []  # Lista per memorizzare i pulsanti della griglia
    for i in range(10):
        row = []  # Lista temporanea per ogni riga
        for j in range(10):
            button = tk.Button(
                grid_frame, text=" ", font=("Arial", 12), width=2, height=1,  # Stile e dimensione del pulsante
                command=lambda r=i, c=j: seleziona_celle_nave(r, c)  # Assegna la funzione `select_cell` al pulsante
            )
            button.grid(row=i + 1, column=j + 1, padx=2, pady=2)  # Posiziona il pulsante nella griglia
            row.append(button)  # Aggiunge il pulsante alla riga
        grid_buttons.append(row)  # Aggiunge la riga alla lista complessiva

    # Creazione delle etichette per l'asse verticale (numeri)
    for i in range(10):
        label = ttk.Label(grid_frame, text=str(i + 1), font=("Arial", 12))  # 1-10
        label.grid(row=i + 1, column=0, padx=2, pady=2)  # Posiziona l'etichetta nella prima colonna (asse verticale)

    # Log per visualizzare i messaggi
    log_frame = ttk.Frame(win)  # Frame per contenere il log
    log_frame.grid(row=1, column=1, padx=20, pady=20)  # Posiziona il frame nella finestra principale
    log_label = ttk.Label(log_frame, text="Chat di gioco", font=("Arial", 14))  # Etichetta per il log
    log_label.pack()  # Mostra l'etichetta
    log_text = tk.Text(log_frame, font=("Arial", 10), width=50, height=30)  # Casella di testo per il log
    log_text.pack()  # Mostra la casella di testo

    # Casella per l'attacco
    attack_frame = ttk.Frame(win)  # Frame per contenere la sezione degli attacchi
    attack_frame.grid(row=2, column=0, padx=20, pady=20)  # Posiziona il frame nella finestra principale
    attack_label = ttk.Label(attack_frame, text="Inserisci coordinate (es: A1):", font=("Arial", 12))  # Etichetta per l'input
    attack_label.pack()  # Mostra l'etichetta
    attack_entry = ttk.Entry(attack_frame, font=("Arial", 12))  # Campo di input per le coordinate
    attack_entry.pack()  # Mostra il campo di input
    attack_button = ttk.Button(attack_frame, text="Attacca", command=invio_attacco)  # Pulsante per inviare l'attacco
    attack_button.pack()  # Mostra il pulsante

    # Avvio automatico del server
    threading.Thread(target=start_server, daemon=True).start()  # Avvia il server in un thread separato

    # Avvia l'interfaccia grafica
    win.mainloop()  # Avvia il ciclo principale della GUI


if __name__ == "__main__":
    main()